package SampleCheckers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverNavigations {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		 
	    //Navigating to the desired website
	    driver.get("https://artoftesting.com/sampleSiteForSelenium");
	 
	    //Used for demo purpose only, not required
	    Thread.sleep(4000);
	 
	    //Clicking a link
	    WebElement artOfTestingLogo = driver.findElement(By.xpath("//a[text()='This is a link']"));
	    artOfTestingLogo.click();
	 
	    //Navigating back in browser 
	    driver.navigate().back();
	 
	    //Used for demo purpose only, not required
	    Thread.sleep(4000);
	 
	    //Navigating forward in browser 
	    driver.navigate().forward();
	}

}
