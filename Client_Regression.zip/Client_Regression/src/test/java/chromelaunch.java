import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.support.PageFactory;


public class chromelaunch {
	public WebDriver driver;	
	
	public static void main(String[] args) {
		System.out.println("one");		
			
		ChromeOptions option = new ChromeOptions();
		
		Proxy proxy = new Proxy();		
		proxy.setHttpProxy("dddfcs1at01.preprod.des");		
		option.setCapability(CapabilityType.PROXY, proxy);
		//option.addArguments("--incognito");
		
		
		String chromeProfilePath = "C:\\Users\\C049604\\AppData\\Local\\Google\\Chrome\\User Data\\Profile 2\\";
		//ChromeOptions chromeProfile = new ChromeOptions();
		option.addArguments("chrome.switches", "--disable-extensions");
		option.addArguments("user-data-dir=" + chromeProfilePath);
		
		
		System.setProperty("webdriver.chrome.driver",
				"C://driver//chromedriver//chromedriver.exe");
	
		
		// Initialize browser
		WebDriver driver=new ChromeDriver(option);		 
		// Open Google
		driver.get("http://www.google.com");
	
		
	}

}
