package tests;

import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Sleeper;
import org.testng.ITestContext;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import dataProviders.DataProvider_IN_OUT;
import drivers.SetupDriver;
import pages.AddNewService;
import pages.CRCommon;
import pages.ClientApplicationPage;
import pages.CreateAuthorization;
import pages.DemographicsPage;
import pages.LoginPage;
import pages.ResponsiblePartyPage;

@Listeners(ExtentReports.Listeners.class)
public class CA_Web1_EndToEndLinksValidation extends BaseTest {
	// public static WebDriver driver;
	
	public DataProvider_IN_OUT dp1 = new DataProvider_IN_OUT();
	public String clientID;
	public int DataSet1 = -1;

	@Test(priority = 1, dataProvider = "ExcelRead", dataProviderClass = BaseTest.class)

	public void CR1(Map<String, String> data) throws Exception {
		DataSet++;
		DataSet1++;
		driver.get(reader.getApplicationUrl());
		ExtentReports.Listeners.info("Navigated to WEB1 URL : " + reader.getApplicationUrl());
		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep(data);

		RPPage = CAPage.doAddConsumersStep(data);
		String AssitID = RPPage.getAssitID(data);
		dp.WriteVariant(SheetFilePath, "CR1", AssitID, "Assist_ID", DataSet + 1);
		driver = RPPage.doAddRPStep(data);
		// RPPage = new ResponsiblePartyPage(driver);
		// driver = RPPage.navToMedicalPage(data);
		DGPage = new DemographicsPage(driver);
		DIPage = DGPage.doDemographicsSteps(data);
		driver = DIPage.doDiagnosisSteps(data);

		CAPage = new ClientApplicationPage(driver);
		clientID = CAPage.getClientID(AssitID);
		System.out.println("Client ID: " + clientID);
		dp.WriteVariant(SheetFilePath, "CR1", clientID, "Client_ID", DataSet + 1);

		System.out.println("CR Driver:" + driver);
		System.out.println(" CR driver url :" + driver.getCurrentUrl());

		driver = Supervisor_Steps(driver, clientID);
		driver = ISPPlanCreation(driver, clientID, data);
		AddNewService addNewService = new AddNewService(driver);
		driver = addNewService.doNewServiceStep(data); //Approved

		if (CRCommon.getStatusFromTableService().equalsIgnoreCase("ENTERED")) {
			driver = addNewService.navToLoginPage();
			loginPage = new LoginPage(driver);
			CAPage = loginPage.doLoginStep("SUPERVISOR");
			driver = CAPage.clickOn_Supervisor_ForService(data, clientID);
			loginPage = new LoginPage(driver);
			driver = loginPage.doSCLoginStep();
		}

		// -*****************************************************//
		CAPage = new ClientApplicationPage(driver);
		CAPage.doCAWeb1EndToEndLinks(clientID, data, dp1, SheetFilePath, "CRLinks", "WorkingStatus", DataSet1+1);
		// ***************************************************//
		
		
		CAPage = new ClientApplicationPage(driver);
		driver = CAPage.doclientIDForCreateAuthSteps(clientID, data);

		CreateAuthorization CA = new CreateAuthorization(driver);
		CA.doCreateAuthorizationStep(data);
		String trackingNumber = CA.getTrackingNumberFromAssistID(data);
		CRCommon.setTrackingNumber(trackingNumber);
		dp.WriteVariant(SheetFilePath, "CR1", trackingNumber, "TRACKINGNUMBER", DataSet + 1);
		// Web1EndtoEndSteps(data);
		// driver=supervisor_ServiceSteps(driver, "SUPERVISOR",clientID, data);
		// driver=supervisor_ServiceSteps(driver, "APM",clientID, data);
		// supervisor_ServiceSteps(driver, "DGMT",clientID, data);
		// return clientID;
	}

	public String Web1EndtoEndSteps(Map<String, String> data) throws Exception {
		driver.get(reader.getApplicationUrl());
		ExtentReports.Listeners.info("Navigated to WEB1 URL : " + reader.getApplicationUrl());
		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep(data);

		RPPage = CAPage.doAddConsumersStep(data);
		String assitID = RPPage.getAssitID(data);
		dp.WriteVariant(SheetFilePath, "CR1", assitID, "Assist_ID", DataSet + 1);
		driver = RPPage.doAddRPStep(data);
		RPPage = new ResponsiblePartyPage(driver);
		driver = RPPage.navToMedicalPage(data);
		DGPage = new DemographicsPage(driver);
		DIPage = DGPage.doDemographicsSteps(data);
		driver = DIPage.doDiagnosisSteps(data);

		CAPage = new ClientApplicationPage(driver);
		clientID = CAPage.getClientID(assitID);
		System.out.println("Client ID: " + clientID);
		dp.WriteVariant(SheetFilePath, "CR1", clientID, "Client_ID", DataSet + 1);

		System.out.println("CR Driver:" + driver);
		System.out.println(" CR driver url :" + driver.getCurrentUrl());

		driver = Supervisor_Steps(driver, clientID);
		driver = ISPPlanCreation(driver, clientID, data);
		AddNewService addNewService = new AddNewService(driver);
		driver = addNewService.doNewServiceStep(data);
		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep("SUPERVISOR");
		driver = CAPage.clickOn_Supervisor_ForService(data, clientID);
		loginPage = new LoginPage(driver);
		driver = loginPage.doSCLoginStep();
		CAPage = new ClientApplicationPage(driver);
		driver = CAPage.doclientIDForCreateAuthSteps(clientID, data);

		CreateAuthorization CA = new CreateAuthorization(driver);
		CA.doCreateAuthorizationStep(data);
		String trackingNumber = CA.getTrackingNumberFromAssistID(data);
		CRCommon.setTrackingNumber(trackingNumber);
		dp.WriteVariant(SheetFilePath, "CR1", trackingNumber, "TRACKINGNUMBER", DataSet + 1);
		return clientID;
	}

	public WebDriver Supervisor_Steps(WebDriver driver, String clientId) {

		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep("SUPERVISOR");
		driver = CAPage.clickOn_Supervisor_CA(clientId);
		return driver;
	}

	public WebDriver ISPPlanCreation(WebDriver driver, String clientId, Map<String, String> fileData) {
		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep("SC");
		driver = CAPage.ISPPlanCreation(clientId, fileData);
		return driver;
	}

	public WebDriver supervisor_ServiceSteps(WebDriver driver, String serviceType, String clientId,
			Map<String, String> fileData) {
		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep(serviceType);
		CAPage.supervisor_ServiceSteps(clientId, fileData);
		return driver;
	}

}
