package tests;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import drivers.SetupDriver;
import pages.LoginPage;
import pages.VendorApprovalDeniedFinalAcknoledge;

public class VendorFinalAcknowledgeAuthorize extends BaseTest {
	//@Test(priority = 1,dataProvider = "ReadVariant", dataProviderClass = DataProvider_IN_OUT.class)
	//@Test(priority = 2)
	public WebDriver driver;
	@Test(dataProvider = "ExcelRead")
	public void CR2(Map<String, String> data) throws Exception {
		//DataSet++;
		SetupDriver setupDriver = new SetupDriver(driver);
		driver = setupDriver.getDriver(reader.getBroswerName());
		driver.navigate().to(reader.getApplicationUrl2());
		Thread.sleep(5000);
		loginPage = new LoginPage(driver);
		driver = loginPage.doVendorLoginStep();
		VendorApprovalDeniedFinalAcknoledge mainMenuPanel = new VendorApprovalDeniedFinalAcknoledge(driver);
		driver =  mainMenuPanel.doVendorApprovalStep(data);
		driver.navigate().to(reader.getApplicationUrl());
		
		loginPage = new LoginPage(driver);
		driver = loginPage.doSCLoginStep();
		mainMenuPanel = new  VendorApprovalDeniedFinalAcknoledge(driver);
		driver =mainMenuPanel.getVendorResponseStatus(data);
		driver.navigate().to(reader.getApplicationUrl2());
		Thread.sleep(5000);
		loginPage = new LoginPage(driver);
		driver = loginPage.doVendorLoginStep();
		mainMenuPanel = new  VendorApprovalDeniedFinalAcknoledge(driver);
		driver = mainMenuPanel.doVendorFinalAcknoAuthStep(data);
		
	}
}
