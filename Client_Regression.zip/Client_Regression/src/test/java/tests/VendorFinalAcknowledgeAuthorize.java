package tests;

import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Sleeper;
import org.testng.annotations.Test;

import dataProviders.DataProvider_IN_OUT;
import drivers.SetupDriver;
import pages.AddNewService;
import pages.ClientApplicationPage;
import pages.CreateAuthorization;
import pages.LoginPage;

public class VendorFinalAcknowledgeAuthorize extends BaseTest {


	@Test(dataProvider = "ReadVariant", dataProviderClass = DataProvider_IN_OUT.class)
	public void CR(Map<String, String> data) throws Exception {
		DataSet++;

		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep(data);	
		driver = CAPage.doSCApprovalFinalAuthPages(data);
		driver = CAPage.doVendorFinalAcknoAuthStep(data);	     
	}
	

	public WebDriver SCApprovalFinalAuthPages(WebDriver driver,String clientId,Map<String,String> fileData) {
		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep("SC");				
		driver=CAPage.doSCApprovalFinalAuthPages(fileData);		
		
		return  driver;		
	}
	
	
	
	public WebDriver VendorAcknowFinalAuthsPages(WebDriver driver,String clientId,Map<String,String> fileData) {
		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep("SC");
		driver = CAPage.doVendorApprovalStep(fileData);
		driver=CAPage.doSCApprovalFinalAuthPages(fileData);		
		driver=CAPage.doVendorFinalAcknoAuthStep(fileData);
		
		return  driver;		
	}
	
	
	
	
	
}
