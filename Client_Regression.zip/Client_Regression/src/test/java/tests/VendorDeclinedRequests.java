package tests;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import dataProviders.DataProvider_IN_OUT;
import drivers.SetupDriver;
import pages.LoginPage;
import pages.VendorApprovalDeniedFinalAcknoledge;

public class VendorDeclinedRequests extends BaseTest {

	public WebDriver driver;

	@Test(dataProvider = "ExcelRead")
	public void CR(Map<String, String> data) throws Exception {

		DataSet++;
		SetupDriver setupDriver = new SetupDriver(driver);
		driver = setupDriver.getDriver(reader.getBroswerName());
		driver.navigate().to(reader.getApplicationUrl2());
		Thread.sleep(5000);
		loginPage = new LoginPage(driver);
		driver = loginPage.doVendorLoginStep();
		VendorApprovalDeniedFinalAcknoledge mainMenuPanel = new VendorApprovalDeniedFinalAcknoledge(driver);
		mainMenuPanel.doVendorDeclinedStep(data);
	}

}
