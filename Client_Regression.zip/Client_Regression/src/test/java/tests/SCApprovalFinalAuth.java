package tests;

import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Sleeper;
import org.testng.annotations.Test;

import dataProviders.DataProvider_IN_OUT;
import drivers.SetupDriver;
import pages.AddNewService;
import pages.ClientApplicationPage;
import pages.CreateAuthorization;
import pages.LoginPage;

public class SCApprovalFinalAuth extends BaseTest {


	@Test(dataProvider = "ReadVariant", dataProviderClass = DataProvider_IN_OUT.class)
	public void CR(Map<String, String> data) throws Exception {
		DataSet++;

		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep(data);	
		driver = CAPage.doSCApprovalFinalAuthPages(data);
		//SCApprovalFinalAuth SCFA= new SCApprovalFinalAuth(driver);
		//SCFA.SCApprovalFinalAuthPages(data);		 
		
		
		String assitID = RPPage.getAssitID(data);
		dp.WriteVariant(SheetFilePath, sheetName, assitID, "Assist_ID", DataSet + 1);
		CAPage = new ClientApplicationPage(driver);
		String clientID = CAPage.getClientID(assitID);
		System.out.println("Client ID: "+clientID);		
	}
	

	public WebDriver SCApprovalFinalAuthPages(WebDriver driver,String clientId,Map<String,String> fileData) {
		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep("SC");				
		driver=CAPage.doSCApprovalFinalAuthPages(fileData);		
		return  driver;
		
	}


		
}
