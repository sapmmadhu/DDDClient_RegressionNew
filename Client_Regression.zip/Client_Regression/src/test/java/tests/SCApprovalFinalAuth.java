package tests;

import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Sleeper;
import org.testng.annotations.Test;

import dataProviders.DataProvider_IN_OUT;
import drivers.SetupDriver;
import pages.AddNewService;
import pages.ClientApplicationPage;
import pages.CreateAuthorization;
import pages.LoginPage;

public class SCApprovalFinalAuth extends BaseTest {


	@Test(dataProvider = "ReadVariant", dataProviderClass = DataProvider_IN_OUT.class)
	public void CR(Map<String, String> data) throws Exception {
		DataSet++;

		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep(data);

		RPPage = CAPage.doAddConsumersStep(data);
		String assitID = RPPage.getAssitID(data);
		dp.WriteVariant(SheetFilePath, sheetName, assitID, "Assist_ID", DataSet + 1);
		DGPage = RPPage.doAddRPStep(data);
		DIPage = DGPage.doDemographicsSteps(data);
		driver = DIPage.doDiagnosisSteps(data);

		CAPage = new ClientApplicationPage(driver);
		String clientID = CAPage.getClientID(assitID);
		System.out.println("Client ID: "+clientID);
	
		System.out.println("CR Driver:"+driver);
		System.out.println(" CR driver url :"+driver.getCurrentUrl());
		
		driver=Supervisor_Steps(driver,clientID);	
		driver=ISPPlanCreation(driver, clientID, data);
		AddNewService addNewService= new AddNewService(driver);
		driver=addNewService.doNewServiceStep(data);
		CreateAuthorization CA= new CreateAuthorization(driver);
		CA.doCreateAuthorizationStep(data);
		
		//driver=supervisor_ServiceSteps(driver, "SUPERVISOR",clientID, data);
		//driver=supervisor_ServiceSteps(driver, "APM",clientID, data);
		//supervisor_ServiceSteps(driver, "DGMT",clientID, data);	    
	}
	

	public WebDriver Supervisor_Steps(WebDriver driver,String clientId) {
		
		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep("SUPERVISOR");
		driver=CAPage.clickOn_Supervisor_CA(clientId);		
		return  driver;
		
	}

	
	public WebDriver ISPPlanCreation(WebDriver driver,String clientId,Map<String,String> fileData) {				
		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep("SC");
		driver=  CAPage.ISPPlanCreation(clientId,fileData);	
		return driver;
	}
	
	public WebDriver supervisor_ServiceSteps(WebDriver driver,String serviceType,String clientId, Map<String,String> fileData) {
		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep(serviceType);
		CAPage.supervisor_ServiceSteps(clientId, fileData);
		return driver;
	}
	
	
	
	
	
}
