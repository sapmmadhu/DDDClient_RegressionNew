package tests;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import dataProviders.ConfigFileReader;
import dataProviders.DataProvider_IN_OUT;
import drivers.Screenshot;
import drivers.SetupDriver;
import pages.ClientApplicationPage;
import pages.DemographicsPage;
import pages.DocumentedDisabilitiesPage;
import pages.LoginPage;
import pages.ResponsiblePartyPage;

public class DDDEligibility_SC {
	public WebDriver driver;

	LoginPage loginPage;
	ClientApplicationPage CAPage;
	ResponsiblePartyPage RPPage;
	DemographicsPage DGPage;
	DocumentedDisabilitiesPage DIPage;
	// DocumentedDisabilitiesPage DDPage;
	Screenshot img;
	// DocumentedDisabilitiesPage DCPage;

	static ConfigFileReader reader = new ConfigFileReader();
	static String SheetFilePath = reader.getExcelSheetFilePath();
	static String sheetName = reader.getExcelSheetName();
	public DataProvider_IN_OUT dp = new DataProvider_IN_OUT();
	public int DataSet = -1;

	
	@BeforeClass
	public void cleanDirectory() throws IOException {
		FileUtils.cleanDirectory(new File(reader.getScreenShotFilePath()));

	}

	@Test(dataProvider = "ReadVariant", dataProviderClass = DataProvider_IN_OUT.class)
	public void CR(Map<String, String> data) throws IOException {
		DataSet++;
		String TCNNumber = data.get("TCN");
		//System.out.println("TCN Number =====> " + TCNNumber);
		try {

			SetupDriver setupDriver = new SetupDriver(driver);
			driver = setupDriver.getDriver(reader.getBroswerName());
			driver.get(reader.getApplicationUrl());

			loginPage = new LoginPage(driver);
			CAPage = loginPage.doLoginStep(data);
			// CAPage = loginPage.doLoginStep();
			RPPage = CAPage.doAddConsumersStep(data);
			String assitID=RPPage.getAssitID(data);
			dp.WriteVariant(SheetFilePath, sheetName, assitID, "Assist_ID", DataSet+1);
			DGPage = RPPage.doAddRPStep(data);
			DGPage = DGPage.doDemographicsSteps(data);
            DIPage = DIPage.doDiagnosisSteps(data);

			DGPage.getDriver().quit();
		} catch (Exception e)

		{
			System.out.println("excepion TCN number: "+TCNNumber);
			img = new Screenshot(driver);
			img.takeScreenShot(TCNNumber);
			e.printStackTrace();

		}
	}
}
