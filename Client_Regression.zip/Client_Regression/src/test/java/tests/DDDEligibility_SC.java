package tests;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import dataProviders.DataProvider_IN_OUT;
import drivers.SetupDriver;
import pages.ClientApplicationPage;
import pages.LoginPage;

public class DDDEligibility_SC extends BaseTest {
	public  WebDriver sup_driver;

	@Test(dataProvider = "ReadVariant", dataProviderClass = DataProvider_IN_OUT.class)
	public void CR(Map<String, String> data) throws Exception {
		DataSet++;

		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep(data);

		RPPage = CAPage.doAddConsumersStep(data);
		String assitID = RPPage.getAssitID(data);
		dp.WriteVariant(SheetFilePath, sheetName, assitID, "Assist_ID", DataSet + 1);
		DGPage = RPPage.doAddRPStep(data);
		DIPage = DGPage.doDemographicsSteps(data);
		driver = DIPage.doDiagnosisSteps(data);

		CAPage = new ClientApplicationPage(driver);
		String clientID = CAPage.getClientID(assitID);
		System.out.println("Client ID: "+clientID);
		driver.quit();
		
		Supervisor_Steps(clientID);

	}

	public void Supervisor_Steps(String clientId) {
		SetupDriver setupDriver = new SetupDriver(sup_driver);
		sup_driver = setupDriver.getDriver(reader.getBroswerName());
		sup_driver.get(reader.getApplicationUrl());
		loginPage = new LoginPage(sup_driver);
		CAPage = loginPage.doLoginStep();
		CAPage.clickOn_Supervisor_CA(clientId);

	}
}
