package tests;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import dataProviders.ConfigFileReader;
import dataProviders.DataProvider_IN_OUT;
import drivers.Screenshot;
import drivers.SetupDriver;
import pages.BasePage;
import pages.ClientApplicationPage;
import pages.DemographicsPage;
import pages.LoginPage;
import pages.ResponsiblePartyPage;

public class DDDEligibility_SC  {
	public WebDriver driver;

	LoginPage loginPage;
	ClientApplicationPage CAPage;
	ResponsiblePartyPage RPPage;
	DemographicsPage DGPage;
	Screenshot img;
	//DocumentedDisabilitiesPage DCPage;
	
	static ConfigFileReader reader = new ConfigFileReader();

	@Test(dataProvider = "ReadVariant", dataProviderClass = DataProvider_IN_OUT.class)
	public void CR(Map<String, String> data) throws IOException {
		String TCNNumber= data.get("TCN");
		System.out.println("TCN NUmber =====> "+TCNNumber);
		try {

		
		SetupDriver setupDriver = new SetupDriver(driver);
		driver = setupDriver.getDriver(reader.getBroswerName());
		driver.get(reader.getApplicationUrl());
		
		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep(data);
		//CAPage = loginPage.doLoginStep();
		RPPage = CAPage.doAddConsumersStep(data);
		DGPage = RPPage.doAddRPStep(data);
		DGPage=DGPage.doDemographicsSteps(data);
	
		DGPage.getDriver().quit();
		}catch(Exception e)
		{
			//img= new Screenshot(driver);
			//img.takeScreenShot(TCNNumber);
			e.printStackTrace();
			
		}
	}
}
