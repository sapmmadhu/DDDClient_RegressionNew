package tests;

import java.util.Map;

import org.testng.annotations.Test;

import dataProviders.DataProvider_IN_OUT;
import drivers.SetupDriver;
import pages.LoginPage;

public class DDDEligibility_SC extends BaseTest {
//	public WebDriver driver;
//
//	LoginPage loginPage;
//	ClientApplicationPage CAPage;
//	ResponsiblePartyPage RPPage;
//	DemographicsPage DGPage;
//	DocumentedDisabilitiesPage DIPage;
//	Screenshot img;
//
//
//	static ConfigFileReader reader = new ConfigFileReader();
//	static String SheetFilePath = reader.getExcelSheetFilePath();
//	static String sheetName = reader.getExcelSheetName();
//	public DataProvider_IN_OUT dp = new DataProvider_IN_OUT();
//	public int DataSet = -1;
//
//	@BeforeClass
//	public void cleanDirectory() throws IOException {
//		FileUtils.cleanDirectory(new File(reader.getScreenShotFilePath()));
//	}

	@Test(dataProvider = "ReadVariant", dataProviderClass = DataProvider_IN_OUT.class)
	public void CR(Map<String, String> data) throws Exception {
		DataSet++;
		String TCNNumber = data.get("TCN");		
		
		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep(data);
		// CAPage = loginPage.doLoginStep();
		RPPage = CAPage.doAddConsumersStep(data);
		String assitID = RPPage.getAssitID(data);
		dp.WriteVariant(SheetFilePath, sheetName, assitID, "Assist_ID", DataSet + 1);
		DGPage = RPPage.doAddRPStep(data);
		DIPage = DGPage.doDemographicsSteps(data);
		DIPage = DIPage.doDiagnosisSteps(data);	

	}
}
