package tests;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import dataProviders.DataProvider_IN_OUT;
import pages.ClientApplicationPage;
import pages.LoginPage;

@Listeners(ExtentReports.Listeners.class)
public class CA_Web2_EndToEndLinksValidation extends BaseTest {

	public DataProvider_IN_OUT dp1 = new DataProvider_IN_OUT();
	public String clientID;
	public int DataSet1 = 25;


	@Test(dataProvider = "ExcelRead")
	public void CR1(Map<String, String> data) throws Exception {

		driver.navigate().to(reader.getApplicationUrl2());
		Thread.sleep(5000);
		loginPage = new LoginPage(driver);
		driver = loginPage.doVendorLoginStep();
		ClientApplicationPage caPage = new ClientApplicationPage(driver);
		caPage.doCAWeb2EndToEndLinks(data, dp1, SheetFilePath, "CRLinks", "WorkingStatus", DataSet1 + 1);
	}
}
