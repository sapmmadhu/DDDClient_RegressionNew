package tests;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import drivers.SetupDriver;
import pages.CommonNaviagtions;
import pages.LoginPage;

public class GlobalNotifications extends BaseTest {

	public static WebDriver driver;

	@Test(priority = 1, dataProvider = "ExcelRead", dataProviderClass = BaseTest.class)
	public void CR1(Map<String, String> data) throws Exception {
		
		DataSet++;
		SetupDriver setupDriver = new SetupDriver(driver);
		driver = setupDriver.getDriver(reader.getBroswerName());
		driver.get(reader.getApplicationUrl());
		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep(data);

		CommonNaviagtions nav = new CommonNaviagtions(driver);
		nav.navToSaveClientDetails(data);

	}
}