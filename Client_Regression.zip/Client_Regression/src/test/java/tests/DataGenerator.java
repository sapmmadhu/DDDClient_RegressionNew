package tests;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import drivers.SetupDriver;
import pages.LoginPage;

public class DataGenerator extends BaseTest {
	public static WebDriver driver;

	@Test(priority = 1, dataProvider = "ExcelRead", dataProviderClass = BaseTest.class)
	public void dataGenerator(Map<String, String> data) throws Exception {
		DataSet++;
		SetupDriver setupDriver = new SetupDriver(driver);
		driver = setupDriver.getDriver(reader.getBroswerName());
		driver.get(reader.getApplicationUrl());
		loginPage = new LoginPage(driver);
		CAPage = loginPage.doLoginStep(data);

		RPPage = CAPage.doAddConsumersStep(data);
		String assitID = RPPage.getAssitID(data);
		dp.WriteVariant(SheetFilePath, sheetName, assitID, "Assist_ID", DataSet + 1);
		driver = RPPage.doAddRPStep(data);
	}
}