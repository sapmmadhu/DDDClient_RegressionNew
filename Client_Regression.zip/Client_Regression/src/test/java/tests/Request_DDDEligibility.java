package tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import dataProviders.DataProvider_IN_OUT;
import steps.NavigateToCA;

public class Request_DDDEligibility {
	public WebDriver driver;

	NavigateToCA NCA;	
	
	@Test(dataProvider = "ReadVariant", dataProviderClass = DataProvider_IN_OUT.class)
	
	public void CR(String TCN, 
			String SCU, String SCP, 
			String CFN, String CLN, String CG, String CDOB,
	        String RFN, String RLN, String RSB, String RA1, String RA2, String RCTY, String RS, String RZ, String RHP,
	        String DISNA,
	        String FL, String FL1, String FL2, 
	        String ERN, String ERT,
	        String TOE, String ETINA,
	        String DEML, String DEMETH, String DEMTR, String DEMIN, String DEMEMER, String DEMCO, 
	        String VMCWTY, String VMCC,
	        String SVCDD, String SVCRU,
	        String VSVT, String VSGTGV, String VSWGP, String VSSN, String VSOS, String VSSD, String VSCST, String VSRU)
	
	
	{		
		NCA= new NavigateToCA(driver);
		NCA.CASteps(SCU, SCP, CFN, CLN, CG, CDOB);				
	}
}
