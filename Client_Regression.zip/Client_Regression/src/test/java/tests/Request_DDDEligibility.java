package tests;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import dataProviders.DataProvider_IN_OUT;
import pages.ClientApplicationPage;
import pages.LoginPage;

public class Request_DDDEligibility extends BaseTest {
	public WebDriver driver;

	LoginPage loginPage;
	ClientApplicationPage CAPage;

	@Test(dataProvider = "ReadVariant", dataProviderClass = DataProvider_IN_OUT.class)

	public void CR(Map<String, String> data){
		
		loginPage= new LoginPage(getDriver());
		CAPage=loginPage.loginStep(data.get("SCU"), data.get("SCP"));
		//System.out.println(loginPage.getDriver());
		//CAPage= new ClientApplicationPage(loginPage.getDriver());
		CAPage.addConsumersStep(data.get("CFN"), data.get("CLN"), data.get("CG"), data.get("CDOB"));		
	}
}
