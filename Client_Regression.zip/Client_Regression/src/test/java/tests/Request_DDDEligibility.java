package tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import dataProviders.DataProvider_IN_OUT;
import steps.NavigateToCA;

public class Request_DDDEligibility {
	public WebDriver driver;

	NavigateToCA NCA;
	
	
	@Test(dataProvider = "ReadVariant", dataProviderClass = DataProvider_IN_OUT.class)
	public void CR(String TCN, 
			String SCU, String SCP, 
			String CFN, String CLN, String CG, String CDOB) {
		
		NCA= new NavigateToCA(driver);
		NCA.CASteps(SCU, SCP, CFN, CLN, CG, CDOB);
		
		
		
	}
}
