package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import dataProviders.ConfigFileReader;
import drivers.SetupDriver;

public class BaseTest {

	public WebDriver driver;
	static ConfigFileReader reader = new ConfigFileReader();

	//@BeforeTest
	public void beforeSuite() {
		
		
		SetupDriver setupDriver = new SetupDriver(driver);
		driver = setupDriver.getDriver(reader.getBroswerName());		
		driver = new FirefoxDriver();		
		driver.get(reader.getApplicationUrl());
	}

	
	
	
	
	
//	@AfterTest
	public void afterSuite() {
		// if (null != driver) {
		//driver.close();
		getDriver().quit();
		// }
	}

	public WebDriver getDriver() {
		return driver;
	}
}
