package tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import dataProviders.ConfigFileReader;
import drivers.SetupDriver;

public class BaseTest {

	public WebDriver driver;
	static ConfigFileReader reader = new ConfigFileReader();

	@BeforeClass
	public void beforeSuite() {
		SetupDriver setupDriver = new SetupDriver(driver);
		driver = setupDriver.getDriver(reader.getBroswerName());
		driver.get(reader.getApplicationUrl());
	}

	@AfterClass
	public void afterSuite() {
		// if (null != driver) {
		driver.close();
		driver.quit();
		// }
	}

	public WebDriver getDriver() {
		return driver;
	}
}
