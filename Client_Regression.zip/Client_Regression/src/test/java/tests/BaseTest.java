package tests;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import dataProviders.ConfigFileReader;
import dataProviders.DataProvider_IN_OUT;
import drivers.Screenshot;
import drivers.SetupDriver;
import pages.ClientApplicationPage;
import pages.DemographicsPage;
import pages.DocumentedDisabilitiesPage;
import pages.LoginPage;
import pages.ResponsiblePartyPage;
//import pages.SCApprovalFinalAuthPages;

public class BaseTest {
	public static WebDriver driver;

	LoginPage loginPage;
	ClientApplicationPage CAPage;
	ResponsiblePartyPage RPPage;
	DemographicsPage DGPage;
	DocumentedDisabilitiesPage DIPage;
	//SCApprovalFinalAuthPages SCFAPage;
	Screenshot img;


	static ConfigFileReader reader = new ConfigFileReader();
	static String SheetFilePath = reader.getExcelSheetFilePath();
	static String sheetName = reader.getExcelSheetName();
	public DataProvider_IN_OUT dp = new DataProvider_IN_OUT();
	public int DataSet = -1;

	@BeforeClass
	public void cleanDirectory() throws IOException {
		FileUtils.cleanDirectory(new File(reader.getScreenShotFilePath()));
	}
	
	@BeforeTest
	public void browserInvo() {
		SetupDriver setupDriver = new SetupDriver(driver);
		driver = setupDriver.getDriver(reader.getBroswerName());
		driver.get(reader.getApplicationUrl());
	}
	
	//@AfterClass
	public void tearDown() {
		driver.quit();
	}
	
	
	
	
//	@AfterTest
	public void afterSuite() {
		// if (null != driver) {
		//driver.close();
		getDriver().quit();
		// }
	}

	public WebDriver getDriver() {
		return driver;
	}
}
