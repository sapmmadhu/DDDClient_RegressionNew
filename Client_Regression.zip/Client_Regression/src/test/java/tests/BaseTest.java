package tests;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import dataProviders.ConfigFileReader;
import drivers.SetupDriver;

public class BaseTest {

	public static WebDriver driver;
	static ConfigFileReader reader = new ConfigFileReader();
	
	@BeforeClass
	public void cleanDirectory() throws IOException {
		//driver = new FirefoxDriver();
		FileUtils.cleanDirectory(new File(reader.getScreenShotFilePath()));
	}

	//@BeforeTest
	public void beforeSuite() {
		
		
		SetupDriver setupDriver = new SetupDriver(driver);
		driver = setupDriver.getDriver(reader.getBroswerName());		
		driver = new FirefoxDriver();		
		//driver = new ChromeDriver();
		driver.get(reader.getApplicationUrl());
	}
	
	
	@AfterClass
	public void tearDown() {
		driver.quit();
	}

	
	
	
	
	
//	@AfterTest
	public void afterSuite() {
		// if (null != driver) {
		//driver.close();
		getDriver().quit();
		// }
	}

	public WebDriver getDriver() {
		return driver;
	}
}
