package Constants;

import org.openqa.selenium.By;

public class CRConstants {

	// LoginPage
	public static final String USER_NAME = "//input[@id='MainContent_txtUserName']";
	public static final String PASSWORD = "//input[@id='MainContent_txtPassword']";
	public static final String LOGIN = "//input[@id='MainContent_btnLogin']";

	// Client Application

	public static final String CLIENT_APPLICATION = "//a[contains(text(),'CLIENT APPLICATION')]";

	// Dashboard Page
	public static final String CONSUMER_ADMINISTRATION = "//a[contains(text(),'Consumer Administration ')]";
	public static final String VIEW_MY_CONSUMERS = "//a[contains(text(),'View My Consumers')]";
	public static final String ADD_CONSUMER = "//input[@value='Add Consumer']";
	public static final String LAST_NAME = "//input[@id='ContentPrimary_txtLastName']";
	public static final String FIRST_NAME = "//input[@id='ContentPrimary_txtFirstName']";
	public static final String GENDER = "//select[@name='ctl00$ContentPrimary$ddlGender']";
	public static final String DATE_OF_BIRTH = "//input[@id='ContentPrimary_txtDOB']";
	public static final String CONTINUE = "//input[@id='ContentPrimary_btnAddAndContinue']";
	public static final String ADD_AND_CONTINUE = "//a[contains(text(),'Add and Continue')]";
	public static final String POPUP = "(//button[contains(text(),'Close')])[2]";

	public static final String BB_AA="//a[@id='aClientCaret']//span[contains(text(),'BB AA')]";
	public static final String ASSIST_ID ="(//div[@id='pnlConsumerDetails']//span)[1]";
	// Responsible party screen
	public static final String RP_FIRST_NAME = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtContactFN']";
	public static final String RP_LAST_NAME = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtContactLN']";
	public static final String CHECK_BOX_LIST = "//*[@id='ContentPrimary_ctrl_ContactAddress_chkAddNewAddr']/tbody/tr/td";
	public static final String HOME_CHECK_BOX = "//input[@id='ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0']";
	public static final String ADD_LINE_ONE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressLine1']";
	public static final String ADD_LINE_TWO = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressLine2']";
	public static final String CITY = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtCity']";
	public static final String STATE = "//select[@name='ctl00$ContentPrimary$ctrl_ContactAddress$ddlState']";
	public static final String ZIP = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtZip5']";
	public static final String HOME_PHONE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtHomePhonePrefixSuffix']";
	public static final String FOOTER_SCROLL = "//*[@id='footerInj']/div[1]";
	public static final String START_DATE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressStDate']";
	public static final String TODAY_DATE = "(//div[@class='datetimepicker-days']//th[contains(text(),'Today')])[1]";
	public static final String SAVE = "//input[@id='ContentPrimary_ctrl_ContactAddress_btnSave']";// Final Save button

	// Address validation
	public static final String USE_AS_ENTERED = "//input[@value='Use as Entered']";
	public static final String CLOSE = "//input[contains(@type,'button')]";
	public static final String FINAL_CLOSE = "//button[contains(text(),'Close')]";

	// Consumer address book
	public static final String CONSUMER_MAIN_MENU = "//li[@id='liConsumerMenu']//a[contains(text(),'Consumer Main Menu')]";
	public static final String DOCUMENTED_DISABILITIES = "//input[@id='lnkDocumentedDiabilities']";
	public static final String CONSUMER_MENU_LIST = "//ul[@class='dropdown-menu mega-dropdown-menu']/li/ul/li";
	public static final String DISABILITIES_TYPE_DROPDOWN = "//input[@id='ContentPrimary_DropDownList1']"; 

	// Functional limitations
	public static final String FUNCTIONAL_LIMITATIONS = "//input[@id='ContentPrimary_lbFuncLimit1']";
	public static final String FUNCTIONAL_LIMITATIONS_ROWS = "//*[@id=\"Table11\"]/tbody/tr"; 
																								
	public static final String ASSIGN_TO_DIAGNOSIS = "//input[@id='ContentPrimary_btnAssignFuncLimitations']";

	// Evaluation/ Report
	public static final String EVALUATION_REPORT = "//input[@id='ContentPrimary_lbDisablityPrioirty1']";
	public static final String ER_FIRSTNAME = "//input[@id='ContentPrimary_txtProfessionalName']";
	public static final String ER_TITLE = "//input[@id='ContentPrimary_txtProfessionalTitle']";
	public static final String ER_EVALUATION_DROPDOWN = "//input[@id='ContentPrimary_ddlProfessionalReportType']"; 
	public static final String ER_DATEREPORT = "//input[@id='ContentPrimary_txtProfessionalDateofReport']";
	public static final String ER_TODAY = "//div[@class='datetimepicker-days']//th[contains(text(),'Today')]";
	public static final String ER_COMMENTS = "//input[@id='ContentPrimary_txtProfessionalComments']"; 
																										
	public static final String ER_SAVE = "//input[@id='ContentPrimary_btnAssignProfessionalDetails']";

	/*
	 * // Etiology public static final String ETIOLOGY =
	 * "//input[@id='ContentPrimary_btnConcerns']"; // Add Etiology button public
	 * static final String ETIOLOGY_SELECT = "//input[@value='Select Etiology']";
	 * public static final String ETIOLOGY_TYPE = "//*[@id=\"CheckBoxList1\"]"; //
	 * Types of Etiology from the list public static final String ETIOLOGY_ASSIGN =
	 * "//input[@value='Assign']"; // Assigning Etiology selection public static
	 * final String ETIOLOGY_FINALSAVE = "//input[@value='Save']"; public static
	 * final String ETIOLOGY_LINKCLOSE = "//input[@id='lnkClose']"; // Before Save
	 * Etiology -To Check - Link Close
	 */

	// Demographics
	public static final String DEMO_LINK = "//a[contains(text(),'Demographics')]";
	public static final String DEMO_LANGUAGE_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlConsumerLanguage']";
	public static final String DEMO_ETHNICITY_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlEthnicity']";
	public static final String DEMO_TRIBE_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlTribe']";
	//public static final String DEMO_BIRTHPLACEOTHER = "//textarea[@name='ctl00$ContentPrimary$txtDisabilityDescription']";
	//public static final String DEMO_SSN = "//input[@name='ctl00$ContentPrimary$txtSsn']";
	//public static final String DEMO_SSN = "//input[@id='ContentPrimary_txtSsn']";
	public static final String DEMO_INCONT_DROPDOWN = "//button[@data-id='ContentPrimary_Incontinent_Dropdownlist']";
	public static final String DEMO_EMERGENCY_PLAN_DROPDOWN = "//select[@name='ctl00$ContentPrimary$PowerDependent_Dropdownlist']";
	public static final String DEMO_COMMENTS = "//textarea[@name='ctl00$ContentPrimary$txtDisabilityDescription']";
	//textarea[@id='ContentPrimary_txtDisabilityDescription'] 
	
	public static final String DEMO_REASON = "//select[@name='ctl00$ContentPrimary$ddlICAPReason']";
	//public static final String DEMO_ICAPSCORE = "//input[@name='ctl00$ContentPrimary$txtICAPScore']";
	public static final String DEMO_SAVE = "//input[@value='Save']";
	//public static final String DEMO_SAVE ="//input[@name='ctl00$ContentPrimary$btnSave']";

	// Eligibility
	public static final String ELIGIDDDBUTTON = "//input[@name='ctl00$btnDetermineEligibility']";
	public static final String ELIGIDETERREDETER = "//a[contains(text(),'Eligibility Determination/Redetermination')]";
	public static final String ELIGIYESBUTTON = "//input[@id='ContentPrimary_RadioButton1']";
	public static final String ELIGINOBUTTON = "//input[@id='ContentPrimary_RadioButton2']";
	public static final String ELIGIDETERNOTES = "//textarea[@name='ctl00$ContentPrimary$txtNotes']"; // Determination
																										// notes
	public static final String ELIGIFINALSAVE = "//input[@value='Save']";
	public static final String ELIGISUCCESSMSG = "//span[contains(text(),'Save Successful')]";// Successful message
																								// validation
	public static final String ELIGIVIEWMYCONSUMERS = "//a[contains(text(),'View My Consumers')]";
	public static final String ELIGIWORKERDROPDOWN = "//div[contains(text(),'PRIMARY')]"; // Worker drop down
	public static final String ELIGICLIENTDROPDOWN = "//div[contains(text(),'--SELECT--')]"; // Client drop down
	public static final String ELIGIMYCONSUMERS = "(//a[@data-toggle='collapse'])[1]";
	public static final String ELIGISTATUS = "//*[text()='APPROVED']";
	public static final String ELIGISELECT = "//a[contains(text(),'Select')]";
		

//  ********* New Items are added below after Eligibility process which is ISP envelope, Add new service and Vendor selection process *********
	
	// Create ISP Envelope
	public static final String ISPSERVICE = "//a[contains(text(),'ISP Service Plan')]"; 
	public static final String ISPANNUALCOMPDATE = "//input[@id='ContentPrimary_txtAnnual']";
	public static final String ISPREVIEWCOMPDATE = "//input[@id='ContentPrimary_txtAnnual']";
	public static final String ISPCREATENEW = "//input[@value='Create New ISP Envelope']"; 
	
	
	//Add New Service 
	public static final String SRVCENEW = "//a[@id='ContentPrimary_lnkAddNewService']";
	public static final String SRVCEDROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlService']"; 																					
	public static final String SRVCEREQUUNITS = "//input[@name='ctl00$ContentPrimary$txtRequestedUnits']";
	public static final String SRVCESAVE = "//input[@name='ctl00$ContentPrimary$btnSave']";
	public static final String SRVCEAPPRSTATUS = "//input[@id='lnkServiceApprovalRequestStatus']";

		
	//The below steps are header validations in "Consumer Services & Authorizations" screen	
	public static final String VSHEADERCHOOSEANISP = "//span[contains(text(), 'Choose an ISP:')]";
	public static final String VSPRINT = "//input[@name='ctl00$ContentPrimary$btnPrint']";
	public static final String VSHEADERAVAILSERVICES = "//a[contains(text(), 'Available Services')]";
	
	public static final String VSHEADERFINALAUTH = "//a[contains(text(), 'Finalized Authorizations:')]";
	public static final String VSACTIVEINACTIVE = "//span[contains(text(), 'View Active/Inactive Authorizations: ')]";
	
	public static final String VSHEADERCESHIGHRATE = "//a[contains(text(), 'CES Higher Rate Approvals:')]";
	public static final String VSCONSPAYREPO = "//a[contains(text(), 'Consumer Payment Report')]";
	public static final String VSCESWORK = "//a[contains(text(), 'CES Worksheet')]";
	public static final String VSACTINACTAPPROVALS = "//select[@name='ctl00$ContentPrimary$ddlApprovalsStatus']";
	
	


	// Clicking on "Vendor Selection & Authorization link from Consumer main menu
	public static final String VSAUTHLINK = "//a[contains(text(), 'Vendor Selection & Authorization')]";
	public static final String VSAUTHNEW = "//a[contains(text(), 'Create New Authorization')]";	
	
	
	// Vendor selection screen - Button validations
	public static final String VSBUTTONSEARCH = "";
	public static final String VSCLEAR = "";
	public static final String VSCANCELRETURN = "";
	public static final String VSSAVEANDCONT = "";
	
	
	// Vendor selection screen
	public static final String VSAUTHSTARTDATE = "//input[@name='ctl00$ContentPrimary$txtAuthStartDate']"; 														 
	public static final String VSAUTHENDDATE = "//input[@name='ctl00$ContentPrimary$txtAuthEndDate']"; 
    public static final String VSVENDORTYPE = "//select[@name='ctl00$ContentPrimary$ddlVendorType']";
	public static final String VSSEARCH = "//input[@name='ctl00$ContentPrimary$btnSearch2']"; 
	public static final String VSBYPASS = "//input[@id='ContentPrimary_chkByPass']";
	//public static final String VSBYPASS = "//input[@name='ctl00$ContentPrimary$chkByPass']";
	public static final String VSGOODTOGO = "//*[@id=\"ispMain\"]/div[6]/div/table/tbody/tr/td/table/tbody/tr[6]/td[2]/table/tbody/tr/td[2]/table/tbody/tr/td"; 
	public static final String VSWORKERGENPRE = "//select[@name='ctl00$ContentPrimary$ddlWorkerGenderPreference']"; 
	public static final String VSSPECIALNEEDS = "//select[@name='table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/div/table/tbody']";
	//List<WebElement> tdlist = driver.findElements(By.cssSelector("table[id='ContentPrimary_dbgSpecialNeeds'] tr td"));
	
		
	// Office/ Site selection & Authorizations - Button validations
	public static final String VSBUTTONCANCEL = "//input[@name='ctl00$ContentPrimary$btnCancel']";
	public static final String VSBUTTONSAVECON = "//input[@name='ctl00$ContentPrimary$btnSaveContinue']";
	
	
	// Office/ Site selection & Authorizations
	public static final String VSSAVECONTINUE = "//input[@name='ctl00$ContentPrimary$btnSave']";
	public static final String VSOFFICESITE = "//input[@id='ContentPrimary_dbgVendorSites']"; 
	public static final String VSOFFICESITESAVE = "//input[@name='ctl00$ContentPrimary$btnSaveContinue']";
	
	
	
	// Service units allocation screen - Button validations	
	public static final String VSBUTTONADD = "ctl00$ContentPrimary$lvlservice$btnAddNonTransportation";
	public static final String VSBUTTONCLEAR = "//input[@name='ctl00$ContentPrimary$lvlservice$btnClear']";
	public static final String VSBUTTONCANCELRETURN = "//input[@name='ctl00$ContentPrimary$btnCancelReturn']";
	public static final String VSBUTTONSAVE = "//input[@name='ctl00$ContentPrimary$btnSave']";
	public static final String VSBUTTONAUTHORIZE = "ctl00$ContentPrimary$btnAuthorize";
	
	
	
	// Service units allocation screen
	public static final String VSOFFICELEVELSERVICE = "//select[@name='ctl00$ContentPrimary$lvlservice$ddlLocationOfService']";
	//public static final String VSOFFICELEVELSERVICE = "//select[@id='ContentPrimary_lvlservice_ddlLocationOfService']";
	public static final String VSHOURSWEEK = "//input[@name='ctl00$ContentPrimary$lvlservice$txtHrsPerWeek']";
	public static final String VSSERVICESELECTDAYS = "//*[@id=\"ContentPrimary_lvlservice_pnlDayandTime\"]/table";
	public static final String VSSERVICESTARTTIME = "//input[@name='ctl00$ContentPrimary$lvlservice$txtTime']";
	public static final String VSSERVICEENDTIME = "//input[@name='ctl00$ContentPrimary$lvlservice$txtEndTime']";
	public static final String VSSERVICECROSSST = "//textarea[@name='ctl00$ContentPrimary$lvlservice$txtPickupCrossStreet']"; 
														
	public static final String VSSERVICEADD = "//input[@name='ctl00$ContentPrimary$lvlservice$btnAddNonTransportation']";
	//public static final String VSSERVICEADD = "//input[@id='ContentPrimary_lvlservice_btnAddNonTransportation']";

		
	// To perform Edit and Delete actions on Date and Time selection
	public static final String VSSERVICEEDIT = "//a[contains(text(), 'Edit')]";
	public static final String VSSERVICEDELETE = "//a[contains(text(), 'Delete')]";
	public static final String VSSERVICEDELETEPOP = ""; // Alert message to handle
	
	
    // To fill requested units before Save action
	public static final String VSSERVICEREQUNITS = "//input[@name='ctl00$ContentPrimary$dbgRequestUnits$ctl02$dbgtxtRequestUnits']";
	public static final String VSSERVICEFINALSAVE = "//input[@name='ctl00$ContentPrimary$btnSave']";
	
	
	// To send final authorization to send vendors
	public static final String VSSERVICEFINALAUTH = "//input[@name='ctl00$ContentPrimary$btnAuthorize']";
	//public static final String VSSERVICEFINALAUTH = "//input[@id='ContentPrimary_btnAuthorize']";
	
	
	
	// To verify Final authorizations section after authorization
	public static final String VSFINALAUTHPANEL = "//div[@id='ContentPrimary_divAuthorizations']";
	//public static final String VSFINALAUTHPANEL = "//input[@name='ctl00$ContentPrimary$hfAuthorizations']";
	
	
	public static final String VSCHANGEAUTH = "//a[@id='ContentPrimary_dbgApprovedAuthorizations_dbghlnkChangeAuthorization_2']";
	//public static final String VSFINALCHANGEAUTH = "//a[contains(text(), 'Change Authorization')]";
	//public static final String VSFINALCHANGEAUTHOR = "//a[contains(text(), 'Change Authorization')]";
	
	
	public static final String VSCHANGEREASON = "//select[@name='cboChangeReason']";
	//public static final String VSCHANGEREASON = "//select[@id='cboChangeReason']";
	
	
	public static final String VSCHANGESAVE = "//input[@name='btnSave']";  
	//public static final String VSFINALCHANGESAVE = "//input[@id='btnSave']";
	public static final String VSCHANGEDELETE = "//input[@name='btnTerminate']";
	//public static final String VSCHANGEDELETEPOPOP = "//input[@name='btnTerminate']"; - This is Alert pop op
	
		

	
	
	
	
	
	
	
	
	
	//  *****************  New Documented disabilities screen   ************************************ //
	
	// Outline  page validations
	// Qualifying Diagnosis page
	public static final String DIAG_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlDiagnosis']"; 
	//public static final String DIAG_DROPDOWN = "//select[@id='ddlDiagnosis']";
	//public static final String DIAG_DROPDOWN = "-98";
	public static final String DIAG_VIEWEDIT = "//a[contains(text(), 'View / Edit')]";
	public static final String DIAG_DELETE = "//a[contains(text(), 'Delete')]";
	public static final String FL_TABLE = "//*[@id='ctl00_ContentPrimary_cblFunctionalLimitation']/tbody";
	public static final String FL_ONE = "//textarea[@id='txtFLEconomic']";
	public static final String FL_TWO = "//textarea[@id='txtFLCapacity']";
	public static final String FL_THREE = "//textarea[@id='txtFLLearning']";
	public static final String FL_FOUR = "//textarea[@id='txtFLMobility']";
	public static final String FL_FIVE = "//textarea[@id='txtFLReceptive']";
	public static final String FL_SIX = "//textarea[@id='txtFLSelfCare']";
	public static final String FL_SEVEN = "//textarea[@id='txtFLSelfDirection']";
	public static final String ERNAME = "//input[@id='txtEvalName']";
	public static final String ERTITLE = "//input[@id='txtEvalTitle']";
	public static final String ERORG = "//input[@id='txtEvalOrganization']";
	public static final String ERADDRESS = "//input[@id='txtEvalAddress']";
	public static final String ERDROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlEvalType']";
	public static final String EROTHER = "//input[@id='txtEVTypeOther']";	
	public static final String ERDOR = "//input[@id='txtEVReportDate']";
	public static final String ERCOMMENTS = "//textarea[@id ='txtEVComments']";
	public static final String ERSAVE = "//button[@id='btnSave']";	
	public static final String ERPHONE = "//input[@id='txtEvalPhoneNo']";
	public static final String ERFINALSAVE = "";
	
	// Delete Diagnosis pop op 
	public static final String DIAG_DELETE_YES = "//button[@class='btn btn-primary btn_yes_confirm']";
	public static final String DIAG_DELETE_NO = "//button[@class='btn btn-primary btn_no_confirm']";
	public static final String DIAG_DELETE_POPOP = "";
	
	// Diagnosis - Types of drop down below header -  Add
	public static final String DIAG_PRIMA = "//select[@name='ctl00$ContentPrimary$ddlSequence']".valueOf("Primary");
	public static final String DIAG_SECOND = "//select[@name='ctl00$ContentPrimary$ddlSequence']".valueOf("Secondary");
	public static final String DIAG_TERTI = "//select[@name='ctl00$ContentPrimary$ddlSequence']".valueOf("Tertiary");
	public static final String DIAG_QUATE = "//select[@name='ctl00$ContentPrimary$ddlSequence']".valueOf("Quaternary");
	public static final String DIAG_QUINA = "//select[@name='ctl00$ContentPrimary$ddlSequence']".valueOf("Quinary");
	public static final String DIAG_VIEW = "";
    
    // Button validations
    public static final String BUTTONPRINT = "//button[@id='btnSummary']"; 
    public static final String BUTTONCANCEL = "//button[@id='btnCancel']"; 
    public static final String BUTTONSAVE = "//button[@id='btnSave']";	
    public static final String BUTTONADD = "";
    public static final String BUTTONVIEW = "";
    public static final String BUTTONEDIT = "";
    public static final String BUTTONDELETE = "";
    public static final String BUTTONMODIFY = "";
    public static final String BUTTONHISTORY = "";
    public static final String BUTTONCOLLAPSE = "";
    public static final String BUTTONCALANDER =""; 
    public static final String BUTTONPRIVACY ="";
    public static final String BUTTONDISCLAIMER = "";   
    
    
    // Tab validations before fill FL, Evaluation report/ title, Qualifying Diagnosis information   
    public static final String TABETIOLOGY = "//a[contains(text(), 'Etiology')]";
    public static final String TABAUGCOMMDIAG ="//a[contains(text(), 'Aug Comm Diagnosis')]";
    public static final String TABQUALDIAG = "//a[contains(text(), 'Qualifying Diagnosis ')]";
    public static final String TABNEW = "";
    
       
    // Header validations 
    public static final String HEADERFL = "//div[contains(text(), 'Functional Limitations')]";
    public static final String HEADERER = "//div[contains(text(), 'Evaluation/Report')]"; 
    public static final String HEADERADD ="//div[contains(text(), 'Add')]"; 
    //public static final String HEADERETIOLOGY ="//div[contains(text(), 'Add')]";
   
    public static final String QDSUMMARY = "//div/div/div/div/div[@class='panel-heading header-color']";
    public static final String QDSUMSEQUENCE = "//div/div/div/div/div/table/tbody/tr[@class='header-color']";
    public static final String QDSUMDIAGNOSIS = "//div/div/div/div/div/table/tbody/tr[@class='header-color']";
    public static final String QDSUMSTARTDATE = "//div/div/div/div/div/table/tbody/tr[@class='header-color']";
    public static final String QDDIAGNOSISHEADER = "//div[contains(text(), 'Diagnosis')]";
   
           
    // Aug Comm Diagnosis page
    public static final String HEADERVIEWAUGCOMMDIAG ="//div[contains(text(), 'View Aug Comm Diagnosis')]";
    
    public static final String AUGCOMMDIAG_ADD = "";
    public static final String AUGCOMMDIAG_EDIT = "";
    public static final String AUGCOMMDIAG_CANCEL = "";
    public static final String AUGCOMMDIAG_DELETE = "";
    public static final String AUGCOMMDIAG_VIEW = "";
    public static final String AUGCOMMDIAG_SAVE = "";
    public static final String AUGCOMMDIAG_DROPDOWN = "";
    public static final String AUGCOMMDIAG_SELECT ="";
    public static final String AUGCOMMDIAG_BACK = "";
    public static final String AUGCOMMDIAG_HISTORY = "";
    public static final String AUGCOMMDIAG_TYPES = "";
    public static final String AUGCOMMDIAG_FINALSAVE = "";
    public static final String AUGCOMMDIAG_RETURN = "";
    public static final String AUGCOMMDIAG_STARTDATE = "";
    public static final String AUGCOMMDIAG_ENDDATE = "";
    
    
    
      
    // Etiology page - Before click on Final Save button
    public static final String ETIOLOGY_SAVE = "//div[contains(text(), 'Functional Limitations')]"; 
    public static final String ETIOLOGY_DELETE_CHKBOX = "//div[contains(text(), 'Functional Limitations')]";
    public static final String ETIOLOGY_CANCEL = "//div[contains(text(), 'Functional Limitations')]";
    public static final String ETIOLOGY_DROPDOWN = "//div[contains(text(), 'Functional Limitations')]";
	public static final String ETIOLOGY_HISTORY = "";
	public static final String ETIOLOGY_COLLAPSE ="";
	public static final String ETIOLOGY_NAME = "";
	public static final String ETIOLOGY_STARTDATE = "";
	public static final String ETIOLOGY_ENDDATE = "";
	public static final String ETIOLOGY_BACK = "";
	public static final String ETIOLOGY_RETURN = "";
	public static final String ETILOGY_FINALSAVE = "";
	public static final String ETIOLOGY_EDIT = "";
	public static final String ETIOLOGY_HISTORYCOLLAPSE = "";
	public static final String ETIOLOGY_HOMEPAGE = "";
	public static final String ETIOLOGY_TYPES = "";
	
	
	
    
    
    
    
    
    
	
	
	
	
	
	
	
	
	
	
	// Below are from Dashboard page after click on hyperlink "Client application"
	
	//Task Queue button validations
	public static final String TQSEARCH = "//a[contains(text(), 'Search')]";
	public static final String TQRESET = "//input[@type='submit']";
	public static final String TQPRINT = "//a[contains(text(), 'Print')]";
	
	
	//Progress notes button validations
	public static final String PNSEARCH = "//a[contains(text(), 'Search')]";
	public static final String PNRESET = "//input[@type='submit']";
	public static final String PNPRINT = "//a[contains(text(), ' Print')]";
	public static final String PNADDNOTE = "//input[@value='Add Note']";
	
	
	//Global Notification validations
	public static final String GNSEARCH = "//a[contains(text(), ' Search')]";
	public static final String GNSAVE = "//input[@value='Save']";
	public static final String GNPRINT = "//a[contains(text(), 'Print')]";
	
	
	//Claims Tracking validations
	public static final String CTSEARCH = "//a[contains(text(), 'Search')]";
	public static final String CTCANCEL = "//input[@value='Cancel']";
		
	
}
