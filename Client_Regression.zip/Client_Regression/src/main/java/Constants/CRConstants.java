package Constants;

import org.openqa.selenium.By;

public class CRConstants {

	// LoginPage
	public static final String USER_NAME = "//input[@id='MainContent_txtUserName']";
	public static final String PASSWORD = "//input[@id='MainContent_txtPassword']";
	public static final String LOGIN = "//input[@id='MainContent_btnLogin']";

	// Client Application

	public static final String CLIENT_APPLICATION = "//a[contains(text(),'CLIENT APPLICATION')]";

	// Dashboard Page
	public static final String CONSUMER_ADMINISTRATION = "//a[contains(text(),'Consumer Administration ')]";
	public static final String VIEW_MY_CONSUMERS = "//a[contains(text(),'View My Consumers')]";
	public static final String ADD_CONSUMER = "//input[@value='Add Consumer']";
	public static final String LAST_NAME = "//input[@id='ContentPrimary_txtLastName']";
	public static final String FIRST_NAME = "//input[@id='ContentPrimary_txtFirstName']";
	public static final String GENDER = "//select[@name='ctl00$ContentPrimary$ddlGender']";
	public static final String DATE_OF_BIRTH = "//input[@id='ContentPrimary_txtDOB']";
	public static final String CONTINUE = "//input[@id='ContentPrimary_btnAddAndContinue']";
	public static final String ADD_AND_CONTINUE = "//a[contains(text(),'Add and Continue')]";
	public static final String POPUP = "(//button[contains(text(),'Close')])[2]";

	public static final String BB_AA="//a[@id='aClientCaret']//span[contains(text(),'BB AA')]";
	public static final String ASSIST_ID ="(//div[@id='pnlConsumerDetails']//span)[1]";
	// Responsible party screen
	public static final String RP_FIRST_NAME = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtContactFN']";
	public static final String RP_LAST_NAME = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtContactLN']";
	public static final String CHECK_BOX_LIST = "//*[@id='ContentPrimary_ctrl_ContactAddress_chkAddNewAddr']/tbody/tr/td";
	public static final String HOME_CHECK_BOX = "//input[@id='ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0']";
	public static final String ADD_LINE_ONE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressLine1']";
	public static final String ADD_LINE_TWO = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressLine2']";
	public static final String CITY = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtCity']";
	public static final String STATE = "//select[@name='ctl00$ContentPrimary$ctrl_ContactAddress$ddlState']";
	public static final String ZIP = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtZip5']";
	public static final String HOME_PHONE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtHomePhonePrefixSuffix']";
	public static final String FOOTER_SCROLL = "//*[@id='footerInj']/div[1]";
	public static final String START_DATE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressStDate']";
	public static final String TODAY_DATE = "(//div[@class='datetimepicker-days']//th[contains(text(),'Today')])[1]";
	public static final String SAVE = "//input[@id='ContentPrimary_ctrl_ContactAddress_btnSave']";// Final Save button

	// Address validation
	public static final String USE_AS_ENTERED = "//input[@value='Use as Entered']";
	public static final String CLOSE = "//input[contains(@type,'button')]";
	public static final String FINAL_CLOSE = "//button[contains(text(),'Close')]";

	// Consumer address book
	public static final String CONSUMER_MAIN_MENU = "//li[@id='liConsumerMenu']//a[contains(text(),'Consumer Main Menu')]";
	public static final String CONSUMER_MENU_LIST = "//ul[@class='dropdown-menu mega-dropdown-menu']/li/ul/li";
	public static final String DISABILITIES_TYPE_DROPDOWN = "//input[@id='ContentPrimary_DropDownList1']"; 

	
	// Demographics
	public static final String DEMO_LINK = "//a[contains(text(),'Demographics')]";
	public static final String DEMO_LANGUAGE_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlConsumerLanguage']";
	public static final String DEMO_ETHNICITY_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlEthnicity']";
	public static final String DEMO_TRIBE_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlTribe']";
	public static final String DEMO_INCONT_DROPDOWN = "//button[@data-id='ContentPrimary_Incontinent_Dropdownlist']";
	public static final String DEMO_EMERGENCY_PLAN_DROPDOWN = "//select[@name='ctl00$ContentPrimary$PowerDependent_Dropdownlist']";
	public static final String DEMO_COMMENTS = "//textarea[@name='ctl00$ContentPrimary$txtDisabilityDescription']";
	
	
	public static final String DEMO_REASON = "//select[@name='ctl00$ContentPrimary$ddlICAPReason']";
	public static final String DEMO_SAVE = "//input[@value='Save']";


	

	
	//  ***********************  New Documented disabilities screen   *************************************** //
	
    // Button validations
    public static final String BUTTONPRINT = "//button[@id='btnSummary']"; 
    public static final String BUTTONCANCEL = "//button[@id='btnCancel']"; 
    public static final String BUTTONSAVE = "//button[@id='btnSave']";	
 
     
    // Tab validations before fill FL, Evaluation report/ title, Qualifying Diagnosis information   
    public static final String TABETIOLOGY = "//a[contains(text(), 'Etiology')]";
    public static final String TABAUGCOMMDIAG ="//a[contains(text(), 'Aug Comm Diagnosis')]";
    public static final String TABQUALDIAG = "//a[contains(text(), 'Qualifying Diagnosis ')]";
         
    
    // Header validations    
    public static final String QDSUMMARY = "//div[contains(text(), 'Summary')]";
    public static final String QDSUMSEQUENCE = "//th[contains(text(), 'Sequence')]";
    public static final String QDSUMDIAGNOSIS = "//th[contains(text(), 'Diagnosis')]";
    public static final String QDSUMSTARTDATE = "//th[contains(text(), 'Start Date')]";
       
    public static final String HEADDIAGNOSIS = "//div[contains(text(), 'Diagnosis')]";
    public static final String HEADERFL = "//div[contains(text(), 'Functional Limitations')]";
    public static final String HEADERER = "//div[contains(text(), 'Evaluation/Report')]"; 
    public static final String HEADERADD ="//div[contains(text(), 'Add')]"; 
    
             
   
    // Qualifying Diagnosis page
    public static final String ELIGIBILITY_DELETES="//a[contains(text(),'Eligibility Dates')]";
    public static final String DOCUMENTED_DISABILITIES="//a[contains(text(),'Documented Disabilities')]";
 	public static final String DIAG_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlDiagnosis']"; // Select one Diagnosis
  	public static final String FL_TABLE = "//table[@id='cblFunctionalLimitation']";// This will calculate total number of FLs available in UI page
 	public static final String FL_ONE = "//textarea[@id='txtFLEconomic']";
 	public static final String FL_TWO = "//textarea[@id='txtFLCapacity']";
 	public static final String FL_THREE = "//textarea[@id='txtFLLearning']";
 	public static final String FL_FOUR = "//textarea[@id='txtFLMobility']";
 	public static final String FL_FIVE = "//textarea[@id='txtFLReceptive']";
 	public static final String FL_SIX = "//textarea[@id='txtFLSelfCare']";
 	public static final String FL_SEVEN = "//textarea[@id='txtFLSelfDirection']";
 	public static final String ERNAME = "//input[@id='txtEvalName']";
 	public static final String ERTITLE = "//input[@id='txtEvalTitle']";
 	public static final String ERORGA = "//input[@id='txtEvalOrganization']";
 	public static final String ERPHONE = "//input[@id='txtEvalPhoneNo']";
  	public static final String ERADDRESS = "//input[@id='txtEvalAddress']";
 	public static final String ERDROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlEvalType']";
 	public static final String EROTHER = "//input[@id='txtEVTypeOther']";// This step will execute when ER type is OTHER	
 	public static final String ERDOR = "//input[@id='txtEVReportDate']";
 	public static final String ERCOMMENTS = "//textarea[@id ='txtEVComments']";
 	public static final String ERSAVE = "//button[@id='btnSave']";	
 	public static final String ERCANCEL = "//button[@id='btnCancel']";
 	public static final String DIAG_DROPDOWNMORE = "//select[@name='ctl00$ContentPrimary$ddlDiagnosis']"; // Select three more Diagnosis with FL, ER
	public static final String DIAG_VIEWEDIT = "//a[contains(text(), 'View / Edit')]";
 	public static final String DIAG_DELETE = "//a[contains(text(), 'Delete')]";
    // After delete one diagnosis, Click on Save again
 	
 	
 	// This will implement after Aug comm UI is completed
 	public static final String DIAG_AUGCOMM = "//a[contains(text(), 'Aug Comm Diagnosis')]";
 	public static final String DIAG_AUGCOMM_SAVE = "";
 	public static final String DIAG_AUGCOMM_CANCEL = "";
 	public static final String DIAG_AUGCOMM_VIEW = "";
 	
 	// Delete Diagnosis pop op 
 	public static final String DIAG_DELETE_YES = "//button[@class='btn btn-primary btn_yes_confirm']";
 	public static final String DIAG_DELETE_NO = "//button[@class='btn btn-primary btn_no_confirm']";
 	   
    
 	
 	// *************************** Etiology screen ***************************//
 	
 	public static final String ETI_SUMMARY_HEADER = "//div[contains(text(), 'Summary')]";
 	public static final String ETI_SAVE = "//button[@id='btnSaveEtiology']";
 	public static final String ETI_CANCEL = "//button[@id='btnCancelEtiology']";
 	public static final String ETI_HISTORY = "//a[contains(text(), 'History ')]";
 	public static final String ETI_ETIOLOGY = "//th[contains(text(), 'Etiology')]";
 	public static final String ETI_STARTDATE = "//th[contains(text(), 'Start Date')]";
 	public static final String ETI_ENDDATE = "//th[contains(text(), 'End Date')]";
 	public static final String ETI_DROPDOWN = "//select[@name='ctl00$ContentPrimary$lstEtiology']";
 	public static final String ETI_SEARCH ="//*[@id=\"masterPage\"]/div[2]/div/div[1]/input";
 	public static final String ETI_SELECTALL = "//button[@class='actions-btn bs-select-all btn btn-default']";
 	public static final String ETI_DESELECTALL = "//button[@class='actions-btn bs-deselect-all btn btn-default']";
 	public static final String ETI_DELETE = "//input[@name='chkDelAll']";
 	
 	
 	
 	
 	
 	
 	
 	
 	// Eligibility process flow

	public static final String ELIGIDDDBUTTON = "//input[@name='ctl00$btnDetermineEligibility']";
	public static final String ELIGIDETERREDETER = "//a[contains(text(),'Eligibility Determination/Redetermination')]";
	public static final String ELIGIYESBUTTON = "//input[@id='ContentPrimary_RadioButton1']";
	public static final String ELIGINOBUTTON = "//input[@id='ContentPrimary_RadioButton2']";
	public static final String ELIGIDETERNOTES = "//textarea[@name='ctl00$ContentPrimary$txtNotes']"; // Determination
																										// notes
	public static final String ELIGIFINALSAVE = "//input[@value='Save']";
	public static final String ELIGISUCCESSMSG = "//span[contains(text(),'Save Successful')]";// Successful message
																								// validation
	public static final String ELIGIVIEWMYCONSUMERS = "//a[contains(text(),'View My Consumers')]";
	public static final String ELIGIWORKERDROPDOWN = "//div[contains(text(),'PRIMARY')]"; // Worker drop down
	public static final String ELIGICLIENTDROPDOWN = "//div[contains(text(),'--SELECT--')]"; // Client drop down
	public static final String ELIGIMYCONSUMERS = "(//a[@data-toggle='collapse'])[1]";
	public static final String ELIGISTATUS = "//*[text()='APPROVED']";
	public static final String ELIGISELECT = "//a[contains(text(),'Select')]";
		

//  ********* New Items are added below after Eligibility process which is ISP envelope, Add new service and Vendor selection process *********
	
	// Create ISP Envelope Header/ Button validation
	public static final String ISPANNUALISP = "//select[@name='ctl00$ContentPrimary$ddlIspDates']";
	public static final String ISPBUTTONENVELOPE ="//input[@name='ctl00$ContentPrimary$btnAddISP']";
	//public static final String ISPHEADERISPDATES ="//*[@id=\"ContentPrimary_pnlConsumerISPDates\"]/h5";
	public static final String ISPHEADERDATEHISTORY = "//a[contains(text(), 'ISP Date History')]";
	public static final String ISPHEADERSCHEDULER = "//a[contains(text(), 'ISP Scheduler')]";
	public static final String ISPHEADERCOVER = "//a[contains(text(), 'ISP Cover Page')]";
	public static final String ISPHEADERMRA = "//a[contains(text(), 'Managed Risk Agreement')]";
	public static final String ISPHEADERNEWSERVICE = "//a[contains(text(), 'Add New Service')]";
	public static final String ISPBUTTONCANRET = "//input[@name='ctl00$ContentPrimary$btnCancel']";
	public static final String ISPBUTTONSAVE = "//input[@name='ctl00$ContentPrimary$btnSave']";
	public static final String ISPBUTTONPRINT = "//input[@name='ctl00$ContentPrimary$btnPrint']";
	
	// Pending Approval & Approved - Change pending approvals
	public static final String ISPPENINGAPP = "//span[contains(text(), 'Pending Approval & Approved')]";
	public static final String ISPCHANGEAPP = "//span[contains(text(), 'Change Pending Approvals')]";
	public static final String ISPALLCHANGEAPP = "//a[contains(text(), 'Submit ALL Change Entered for Approval')]";
	public static final String ISPALLENTERAPP =  "//a[contains(text(), 'Submit ALL Entered for Approval')]";
	
	
	
	// Create ISP Envelope
	public static final String ISPSERVICE = "//a[contains(text(),'ISP Service Plan')]"; 
	public static final String ISPANNUALDATE = "//input[@id='ContentPrimary_txtAnnual']";
	public static final String ISPREVIEWDATE = "//input[@id='ContentPrimary_txtAnnual']";
	public static final String ISPCREATENEW = "//input[@value='Create New ISP Envelope']"; 
	public static final String ISPSUCCESSFULMSG = "//span[contains(text(),'FOCUS ISP Date and New ISP Envelope Successfully Created')]";
	public static final String ISPSTARTDATE = "//span[@id='ContentPrimary_lblConsumerISPStartDate']";
	public static final String ISPENDDATE = "//span[@id='ContentPrimary_lblConsumerISPEndDate']";
	
	// Add New Service - Header and button validations
	public static final String ISPCANCEL = "//input[@name='ctl00$ContentPrimary$btnCancel']";
	public static final String ISPSAVE = "//input[@name='ctl00$ContentPrimary$btnSave']";
	public static final String ISPPRINT = "//input[@name='ctl00$ContentPrimary$btnPrint']";
	
	
	
	//Add New Service 
	public static final String SRVCENEW = "//a[@id='ContentPrimary_lnkAddNewService']";
	public static final String SRVCEDROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlService']"; //select[@id='ContentPrimary_ddlService']
	
	// Verify Payment type is selected as PAID Service or not
    public static final String SRVCPAYMENTTYPE = "//label[contains(text(), 'Paid Service')]";
    
    
	public static final String SRVCESTARTDATE = "//input[@name='ctl00$ContentPrimary$txtStartDate']";
	public static final String SRVCEENDDATE = "//input[@name='//input[@name='ctl00$ContentPrimary$txtEndDate']']";
	
	public static final String SRVCEREQUUNITS = "//input[@name='ctl00$ContentPrimary$txtRequestedUnits']";
	public static final String SRVCESAVE = "//input[@name='ctl00$ContentPrimary$btnSave']";
	
	// Successful message
	public static final String SRVCSUCCESSFUL = "//span[contains(text(), 'Record successfully Saved/Updated')]";
	public static final String SRVCAPPRSTATUS = "//input[@id='lnkServiceApprovalRequestStatus']";// Check service status is approved or not from View My Consumers
	
    public static final String SRVCDELETE = "//a[contains(text(), 'Delete')]"; // After service approval, Verify DELETE link showing or not
    public static final String SRVCCHANGE = "//a[contains(text(), 'Change')]"; // After service approval, Verify CHANGE link showing or not
	public static final String SRVCCOMMENTS = "//a[contains(text(), 'Comments and Outcomes')]"; // After service approval, Verify Comments section showing or not
	public static final String SRVCDELTEPOPOP = ""; // This is Alert after click on Delete button
	
	
	
	//Header and Button validations in "Consumer Services & Authorizations" screen	from Vendor Selection & Authorization
	public static final String VSHEADERCHOOSEANISP = "//span[contains(text(), 'Choose an ISP:')]";
	public static final String VSPRINT = "//input[@name='ctl00$ContentPrimary$btnPrint']";   //input[@id= 'ContentPrimary_btnPrint']
	public static final String VSHEADERAVAILSERVICES = "//span[@id='ContentPrimary_lblAvailableServices']";
	
	public static final String VSHEADERFINALAUTH = "//span[@id='ContentPrimary_lblFinalAuthorizations']"; //a[@id='lnkAuthorizationsDown']
	public static final String VSACTIVEINACTIVE = "//span[contains(text(), 'View Active/Inactive Authorizations: ')]";
	
	public static final String VSHEADERCESHIGHRATE = "//a[contains(text(), 'CES Higher Rate Approvals:')]";
	public static final String VSCONSPAYREPO = "//a[contains(text(), 'Consumer Payment Report')]";
	public static final String VSCESWORK = "//a[contains(text(), 'CES Worksheet')]";
	public static final String VSACTINACTAPPROVALS = "//select[@name='ctl00$ContentPrimary$ddlApprovalsStatus']";
	
	
	

	// Clicking on "Create New Authorization" from same screen - Consumer Services & Authorizations
	public static final String VSAUTHNEW = "//a[contains(text(), 'Create New Authorization')]";	
	//public static final String VSAUTHNEW = "//a[@id='ContentPrimary_dbgAvailableServices_Hyp1_0']";
	
	
	// Vendor selection screen - Button validations
	public static final String VSBUTTONSEARCH = "//input[@name='ctl00$ContentPrimary$btnSearch2']";
	public static final String VSCLEAR = "//input[@name='ctl00$ContentPrimary$btnClear']";  //input[@id='ContentPrimary_btnClear']
	public static final String VSCANCELRETURN = "//input[@name='ctl00$ContentPrimary$btnCancelAndReturn']"; //input[@id='ContentPrimary_btnCancelAndReturn']
	public static final String VSSAVEANDCONT = "//input[@name='ctl00$ContentPrimary$btnSave']"; //input[@id='ContentPrimary_btnSave']
	
	
	// Vendor selection screen
	public static final String VSEMERGENCY = "//input[@name='ctl00$ContentPrimary$chkEmergency']"; // This is just a validation
	public static final String VSBYPASS = "//input[@name='ctl00$ContentPrimary$chkByPass']";
	public static final String VSAUTHSTARTDATE = "//input[@name='ctl00$ContentPrimary$txtAuthStartDate']"; 														 
	public static final String VSAUTHENDDATE = "//input[@name='ctl00$ContentPrimary$txtAuthEndDate']"; 
    public static final String VSVENDORTYPE = "//select[@name='ctl00$ContentPrimary$ddlVendorType']";
	public static final String VSSEARCH = "//input[@name='ctl00$ContentPrimary$btnSearch2']"; 
	public static final String VSGOODTOGO = "//table[@id='ContentPrimary_dbgVendors']"; 
	public static final String VSWORKERGENPRE = "//select[@name='ctl00$ContentPrimary$ddlWorkerGenderPreference']"; 
	public static final String VSSPECIALNEEDS = "//table[@id='ContentPrimary_dbgSpecialNeeds']";
	//List<WebElement> tdlist = driver.findElements(By.cssSelector("table[id='ContentPrimary_dbgSpecialNeeds'] tr td"));
	public static final String VSVENSELECTIONSAVE = "//input[@name='ctl00$ContentPrimary$btnSave']";
		
	
	
	// Office/ Site selection & Authorizations - Button validations
	public static final String VSBUTTONCANCEL = "//input[@name='ctl00$ContentPrimary$btnCancel']"; //input[@id='ContentPrimary_btnCancel']
	public static final String VSBUTTONSAVECONT = "//input[@name='ctl00$ContentPrimary$btnSaveContinue']"; //input[@id='ContentPrimary_btnSaveContinue']
	
	
	/*
	 * // Office/ Site selection & Authorizations public static final String
	 * VSTABLEVIEW = "//table[@id='ContentPrimary_dbgVendorSites']"; public static
	 * final String VSTABLESELECTION =
	 * "//div/table[@id='ContentPrimary_dbgVendorSites']"; // Below step is for to
	 * add Office selection/ Office site for the vendor
	 * 
	 * // Save and Continue public static final String VSSAVECONTINUE =
	 * "//input[@name='ctl00$ContentPrimary$btnSave']"; public static final String
	 * VSOFFICESITE = "//input[@id='ContentPrimary_dbgVendorSites']";
	 * //input[@name='ctl00$ContentPrimary$dbgVendorSites$ctl02$rdnSelect']
	 * 
	 * public static final String VSOFFICESITESAVE =
	 * "//input[@name='ctl00$ContentPrimary$btnSaveContinue']";
	 * 
	 */
	
	
	// Service Units Allocation Screen - Button validations	
	public static final String VSVENDORSTARTDATE = "//span[contains(text(), 'Vendor Call Start Date:')]"; // Should be current date
	public static final String VSVENDORENDDATE = "//span[contains(text(), 'Vendor Call End Date:')]"; // Should be after 5 days from current
	public static final String VSBUTTONADD = "//input[@name='ctl00$ContentPrimary$lvlservice$btnAddNonTransportation']";
	public static final String VSBUTTONCLEAR = "//input[@name='ctl00$ContentPrimary$lvlservice$btnClear']";
	public static final String VSBUTTONCANCELRETURN = "//input[@name='ctl00$ContentPrimary$btnCancelReturn']";
	public static final String VSBUTTONSAVE = "//input[@name='ctl00$ContentPrimary$btnSave']";
	public static final String VSBUTTONAUTHORIZE = "//input[@name='ctl00$ContentPrimary$btnAuthorize']";
	
	
	
	// Service Units Allocation Screen
	
	
	/*
	 * public static final String VSOFFICELEVELSERVICE =
	 * "//select[@name='ctl00$ContentPrimary$lvlservice$ddlLocationOfService']";
	 * //public static final String VSOFFICELEVELSERVICE =
	 * "//select[@id='ContentPrimary_lvlservice_ddlLocationOfService']"; public
	 * static final String VSFEEDING =
	 * "//input[@name='ctl00$ContentPrimary$lvlservice$chkFeeding']"; public static
	 * final String VSFEEDINGUNITS =
	 * "//input[@name='ctl00$ContentPrimary$lvlservice$txtFeedingUnits']"; public
	 * static final String VSFEEDINGTHERAPY =
	 * "//input[@name='ctl00$ContentPrimary$lvlservice$txtThreapyUnits']"; public
	 * static final String VSHOURSWEEK =
	 * "//input[@name='ctl00$ContentPrimary$lvlservice$txtHrsPerWeek']";
	 */
	
	
	
	public static final String VSSERVICESELECTDAYS = "//span[@id='ContentPrimary_lvlservice_lblDays']";
	public static final String VSSERVICESTARTTIME = "//input[@name='ctl00$ContentPrimary$lvlservice$txtTime']";
	public static final String VSSERVICEENDTIME = "//input[@name='ctl00$ContentPrimary$lvlservice$txtEndTime']";
	public static final String VSSERVICECROSSST = "//textarea[@name='ctl00$ContentPrimary$lvlservice$txtPickupCrossStreet']"; 
	public static final String VSSERVICEADD = "//input[@name='ctl00$ContentPrimary$lvlservice$btnAddNonTransportation']";

	// To validate Clear button presents or not
	public static final String VSSERVICECLEAR = "//input[@name='ctl00$ContentPrimary$lvlservice$btnClear']";
		
	
	// To perform Edit and Delete actions on Date and Time selection
	public static final String VSSERVICEEDIT = "//a[contains(text(), 'Edit')]";
	public static final String VSSERVICEDELETE = "//a[contains(text(), 'Delete')]";
	public static final String VSSERVICEDELETEOK = ""; // Alert message to handle
	public static final String VSSERVICEDELETECANCEL = ""; // Alert message to handle
		
    // To fill requested units before Save action
	public static final String VSSERVICEREQUNITS = "//input[@name = 'ctl00$ContentPrimary$dbgRequestUnits$ctl02$dbgtxtRequestUnits']";
	
	// To Check field "Effective Requested Units" after filled Requested Units
	public static final String VSSERVICEEFFREQUNITS = "//input[@name = 'ctl00$ContentPrimary$dbgRequestUnits$ctl02$dbgtxtEffectiveUnits']";
		
	public static final String VSSERVICEFINALSAVE = "//input[@name = 'ctl00$ContentPrimary$btnSave']";
	
	// To validate successful message
	public static final String VSSERVICESUCCESSMSG = "//span[contains(text(), 'The request details are successfully saved.')]";
		
	
	// To send final authorization to send vendors via "Authorize" button
	public static final String VSSERVICEFINALAUTH = "//input[@name = 'ctl00$ContentPrimary$btnAuthorize']";
		
	
	// To verify Final authorizations panel section after authorizations to vendors
	public static final String VSFINALAUTHPANEL = "//div[@id='ContentPrimary_divAuthorizations']";
	//public static final String VSFINALAUTHPANEL = "//input[@name='ctl00$ContentPrimary$hfAuthorizations']";
	public static final String VSVERIFIEDSTARTDATE = "//td[contains(text(), 'Verified Service Start Date')]";
	public static final String VSVERIFIEDVIEWHIS = "//a[contains(text(), 'View History')]";
	
	
	// To see Change Authorization panel
	public static final String VSCHANGEAUTH = "//a[contains(text(), 'Change Authorization')]";	
	public static final String VSCHANGEREASON = "//select[@name='cboChangeReason']";
	
	//Change Authorization button validations
	public static final String VSCHANGESAVE = "//input[@name='btnSave']";  
	public static final String VSCHANGEDELETE = "//input[@name='btnTerminate']";
		
	
	// Successful message after Change authorization
	public static final String VSCHANGESUCCESS = "//span[contains(text(), 'Authorization changed successfully!')]";
	public static final String VSCHANGECLOSE = "//a[contains(text(), 'Close')]";
	
	
	// Verify Authorized start date is getting changed or not
	public static final String VSCHANGEDATE = "";
	
	// Compare Total units and Authorized Units from both Available services and Finalized authorizations
	public static final String VSCOMPAREUNITS = "";
	
		
	// Warning message when user create New authorization when NO available units from Consumer Services & Authorizations
	
	
	
	
	
    
    
    
    
    
    
	
	
	
	
	
	
	
	
	
	
	// Below are from Dashboard page after click on hyperlink "Client application"
	
	//Task Queue button validations
	public static final String TQSEARCH = "//a[contains(text(), 'Search')]";
	public static final String TQRESET = "//input[@type='submit']";
	public static final String TQPRINT = "//a[contains(text(), 'Print')]";
	
	
	//Progress notes button validations
	public static final String PNSEARCH = "//a[contains(text(), 'Search')]";
	public static final String PNRESET = "//input[@type='submit']";
	public static final String PNPRINT = "//a[contains(text(), ' Print')]";
	public static final String PNADDNOTE = "//input[@value='Add Note']";
	
	
	//Global Notification validations
	public static final String GNSEARCH = "//a[contains(text(), ' Search')]";
	public static final String GNSAVE = "//input[@value='Save']";
	public static final String GNPRINT = "//a[contains(text(), 'Print')]";
	
	
	//Claims Tracking validations
	public static final String CTSEARCH = "//a[contains(text(), 'Search')]";
	public static final String CTCANCEL = "//input[@value='Cancel']";
		
	
}
