package Constants;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;


public class CRConstants {
	WebDriver driver;
	// LoginPage -  D034315 - SC level
	public static final String USER_NAME = "//input[@id='MainContent_txtUserName']";
	public static final String PASSWORD = "//input[@id='MainContent_txtPassword']";
	public static final String LOGIN = "//input[@id='MainContent_btnLogin']";

	// Client Application

	public static final String CLIENT_APPLICATION = "//a[contains(text(),'CLIENT APPLICATION')]";

	// Dashboard Page
	public static final String CONSUMER_ADMINISTRATION = "//a[contains(text(),'Consumer Administration ')]";
	public static final String VIEW_MY_CONSUMERS = "//a[contains(text(),'View My Consumers')]";
	public static final String ADD_CONSUMER = "//input[@value='Add Consumer']";
	public static final String LAST_NAME = "//input[@id='ContentPrimary_txtLastName']";
	public static final String FIRST_NAME = "//input[@id='ContentPrimary_txtFirstName']";
	//public static final String SSN = "//input[@name='ctl00$ContentPrimary$txtSSAN']";
	//public static final String SSN = "//input[@id='ContentPrimary_txtSSAN']";
	public static final String GENDER = "//select[@name='ctl00$ContentPrimary$ddlGender']";
	//select[@name='ctl00$ContentPrimary$ddlGender']
	public static final String DATE_OF_BIRTH = "//input[@id='ContentPrimary_txtDOB']";
	public static final String CONTINUE = "//input[@id='ContentPrimary_btnAddAndContinue']";
	//public static final String CONTINUE = "//input[@name='ctl00$ContentPrimary$btnAddAndContinue']";
	public static final String ADD_AND_CONTINUE = "//a[contains(text(),'Add and Continue')]";
	public static final String POPUP = "(//button[contains(text(),'Close')])[2]";

	public static final String BB_AA="//a[@id='aClientCaret']//span[contains(text(),'BB AA')]";
	public static final String ASSIST_ID ="(//div[@id='pnlConsumerDetails']//span)[1]";
	
	
	
	// Responsible party screen
	// Contact type is to be added when user selects Responsible party. And the value is to entered from data sheet 
	public static final String CONTACT_TYPE = "//select[@name='ctl00$ContentPrimary$ctrl_ContactAddress$lstContactEntityType']";
	//public static final String CONTACT_TYPE = "//select[@id='ContentPrimary_ctrl_ContactAddress_lstContactEntityType']";
	
	
	// Add/ Edit Consumer
	public static final String ADDEDIT_CONSUMER = "//a[contains(text(), 'Add/Edit Consumer')]";		
	// View Address Book
	public static final String VIEW_ADDRESS_BOOK = "//a[contains(text(), 'View Address Book')]";	
	public static final String RP_FIRST_NAME = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtContactFN']";
	//public static final String RP_FIRST_NAME = "//input[@name='ctl00$ContentPrimary$ctrl_ContactAddress$txtContactFN']";	
	public static final String RP_LAST_NAME = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtContactLN']";
	//public static final String RP_LAST_NAME = "//input[@name='ctl00$ContentPrimary$ctrl_ContactAddress$txtContactLN']";	
	public static final String CHECK_BOX_LIST = "//input[@name='ctl00$ContentPrimary$ctrl_ContactAddress$chkAddNewAddr$0']";
	public static final String HOME_CHECK_BOX = "//input[@id='ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0']";	
	public static final String ADD_LINE_ONE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressLine1']";
	//public static final String ADD_LINE_ONE_NEW = "//input[@name='ctl00$ContentPrimary$ctrl_ContactAddress$txtAddressLine1']";	
	public static final String ADD_LINE_TWO = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressLine2']";
	//public static final String ADD_LINE_TWO_NEW = "//input[@name='ctl00$ContentPrimary$ctrl_ContactAddress$txtAddressLine2']";	
	public static final String CITY = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtCity']";
	//public static final String CITYNEW = "//span[@id='ContentPrimary_ctrl_ContactAddress_lblCityReq']";	
	public static final String STATE = "//select[@name='ctl00$ContentPrimary$ctrl_ContactAddress$ddlState']";
	//public static final String STATE = "//select[@id='ContentPrimary_ctrl_ContactAddress_ddlState']";	
	public static final String ZIP = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtZip5']";
	//public static final String ZIPNEW = "//input[@name='ctl00$ContentPrimary$ctrl_ContactAddress$txtZip5']";	
	public static final String COUNTRY = "//input[@name='ctl00$ContentPrimary$ctrl_ContactAddress$lblCounty']";	
	public static final String HOME_PHONE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtHomePhonePrefixSuffix']";
	public static final String FOOTER_SCROLL = "//*[@id='footerInj']/div[1]";	
	public static final String START_DATE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressStDate']";
	public static final String START_DATE_CAL = "(//span[@class='glyphicon glyphicon-calendar'])[1]";
	
	public static final String TODAY_DATE = "(//div[@class='datetimepicker-days']//th[contains(text(),'Today')])[1]";	
	public static final String SAVE = "//input[@name='ctl00$ContentPrimary$ctrl_ContactAddress$btnSave']";// Final Save button
	//public static final String SAVENEW = "//input[@name='ctl00$ContentPrimary$ctrl_ContactAddress$btnSave']";	
	public static final String CANCEL = "//input[@name='ctl00$ContentPrimary$ctrl_ContactAddress$btnCancel']";
	//public static final String CANCEL = "//input[@id='ContentPrimary_ctrl_ContactAddress_btnCancel']";
	// Address validation
	public static final String USE_AS_ENTERED = "//input[@value='Use as Entered']";
	public static final String CLOSE = "//input[contains(@type,'button')]";
	public static final String FINAL_CLOSE = "//button[contains(text(),'Close')]";
	// Consumer address book
	public static final String CONSUMER_MAIN_MENU = "//li[@id='liConsumerMenu']//a[contains(text(),'Consumer Main Menu')]";
	public static final String CONSUMER_MENU_LIST = "//ul[@class='dropdown-menu mega-dropdown-menu']/li/ul/li";
	public static final String DISABILITIES_TYPE_DROPDOWN = "//input[@id='ContentPrimary_DropDownList1']"; 	
	// Demographics
	public static final String DEMO_LINK = "//a[contains(text(),'Demographics')]"; //a[@id='lnkConsumerDemographics']
	public static final String DEMO_LANGUAGE_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlConsumerLanguage']";
	public static final String DEMO_ETHNICITY_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlEthnicity']";
	public static final String DEMO_TRIBE_DROPDOWN = "//select[@name = 'ctl00$ContentPrimary$ddlTribe']";
	//public static final String DEMO_STATE_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlBirthState']";
	public static final String DEMO_INCONT_DROPDOWN = "//button[@data-id='ContentPrimary_Incontinent_Dropdownlist']";
	public static final String DEMO_EMERGENCY_PLAN_DROPDOWN = "//select[@name='ctl00$ContentPrimary$PowerDependent_Dropdownlist']";
	public static final String DEMO_COMMENTS = "//textarea[@name='ctl00$ContentPrimary$txtDisabilityDescription']";
	//public static final String DEMO_COMMENTS = "//textarea[@id='ContentPrimary_txtDisabilityDescription']";
	
	public static final String DEMO_REASON = "//select[@name='ctl00$ContentPrimary$ddlICAPReason']";
	public static final String DEMO_ICAPSCORE = "//input[@name='ctl00$ContentPrimary$txtICAPScore']";
	
	public static final String DEMO_SAVE = "//input[@value='Save']"; //input[@id='ContentPrimary_btnSave']
	//public static final String DEMO_SAVE = "//input[@name='ctl00$ContentPrimary$btnSave']";
    

	// Demographics age is more than 6 - To be used with new Documented disabilities screen
	public static final String DEMO_LINKNEW = "//a[contains(text(), 'Demographics')]";
	public static final String DEMO_DOBNEW = "//input[@name='ctl00$ContentPrimary$txtBirthDate']";
	public static final String DEMO_LANGNEW = "//select[@name='ctl00$ContentPrimary$ddlConsumerLanguage']";
	public static final String DEMO_ETHNEW = "//select[@name='ctl00$ContentPrimary$ddlEthnicity']";
	public static final String DEMO_TRIBENEW = "//select[@name='ctl00$ContentPrimary$ddlTribe']";
	public static final String DEMO_STATE = "//select[@name='ctl00$ContentPrimary$ddlBirthState']";
	public static final String DEMO_MARITAL = "//select[@name='ctl00$ContentPrimary$ddlMaritalStatus']";
	public static final String DEMO_SSNNEW = "//input[@name='ctl00$ContentPrimary$txtSsn']";
	public static final String DEMO_AHCCCSID = "//input[@name='ctl00$ContentPrimary$txtAhcccsId']";
	public static final String DEMO_INCONTNEW = "//select[@name='ctl00$ContentPrimary$Incontinent_Dropdownlist']";
	public static final String DEMO_EMERNEW = "//select[@name='ctl00$ContentPrimary$PowerDependent_Dropdownlist']";
	public static final String DEMO_COMMENTSNEW = "//textarea[@name='ctl00$ContentPrimary$txtDisabilityDescription']";	
	public static final String DEMO_ICAPSCORENEW = "//input[@name='ctl00$ContentPrimary$txtICAPScore']";	
	public static final String DEMO_ICAPREASONNEW = "//select[@name='ctl00$ContentPrimary$ddlICAPReason']";
	public static final String DEMO_ICAPTYPENEW = "//select[@name='ctl00$ContentPrimary$ddlICAPType']";
	public static final String DEMO_ICAPDATE = "//input[@name='ctl00$ContentPrimary$txtICAPDate']";
	public static final String DEMO_SAVENEW = "//input[@name='ctl00$ContentPrimary$btnSave']";
	//public static final String DEMO_SAVENEW = "//input[@id='ContentPrimary_btnSave']";
	

	
	//  ***********************  New Documented disabilities screen   *************************************** //
     
    // Tab validations before fill FL, Evaluation report/ title, Qualifying Diagnosis information   
    public static final String TABETIOLOGY = "//a[contains(text(), 'Etiology')]";
    public static final String TABAUGCOMMDIAG ="//a[contains(text(), 'Aug Comm Diagnosis')]";
    public static final String TABQUALDIAG = "//a[contains(text(), 'Qualifying Diagnosis ')]";
             
    // Header validations   in Diagnosis, FL and ER sections
    public static final String QDSUMMARY = "//div[contains(text(), 'Summary')]";
    public static final String QDSUMSEQUENCE = "//th[contains(text(), 'Sequence')]";
    public static final String QDSUMDIAGNOSIS = "//th[contains(text(), 'Diagnosis')]";
    public static final String QDSUMSTARTDATE = "//th[contains(text(), 'Start Date')]";
       
    public static final String HEADDIAGNOSIS = "//div[contains(text(), 'Diagnosis')]";
    public static final String HEADERFL = "//div[contains(text(), 'Functional Limitations')]";
    public static final String HEADERER = "//div[contains(text(), 'Evaluation/Report')]"; 
    public static final String HEADERADD = "//div[contains(text(), 'Add')]";
                
   
    // Qualifying Diagnosis page
    public static final String ELIGIBILITY_DELETES= "//a[contains(text(),'Eligibility Dates')]";
    public static final String DOCUMENTED_DISABILITIES= "//a[@id='lnkDocumentedDiabilities']";
  //a[contains(text(), 'Documented Disabilities')]
    
  
 	public static final String QD_SUMMARY = "//div[contains(text(), 'Summary')]"; 
 	public static final String QD_SEQUENCE = "//th[contains(text(), 'Sequence')]";
 	public static final String QD_DIAGNOSIS = "//th[contains(text(), 'Diagnosis')]";
 	public static final String QD_STARTDATE = "//th[contains(text(), 'Start Date')]";
    public static final String DIAG_DROPDOWN = "//button[@data-id='ddlDiagnosis']//span[@class='bs-caret']"; 
    //public static final String DIAG_DROPDOWN = "//select[@id='ddlDiagnosis']";
    public static final String DIAG_LEVEL_DROPDOWN = "//button[@data-id='ddlCognitiveLevel']//div[@class='filter-option']";
    
  
    // Functional limitations free text boxes validations with ID combinations
   
    public static final String FL_TABLE = "//table[@id='cblFunctionalLimitation']";
 	public static final String FL_ONE = "//textarea[@id='txtFLEconomic']"; 
 	public static final String FL_TWO = "//textarea[@id='txtFLCapacity']";
 	public static final String FL_THREE = "//textarea[@id='txtFLLearning']";
 	public static final String FL_FOUR = "//textarea[@id='txtFLMobility']"; 
 	public static final String FL_FIVE = "//textarea[@id='txtFLReceptive']"; 
 	public static final String FL_SIX = "//textarea[@id='txtFLSelfCare']"; 
 	public static final String FL_SEVEN = "//textarea[@id='txtFLSelfDirection']";
 	
 	
 	
 	// Evaluation/ Report table validations and fill the required fields below
 
 	public static final String ER_NAME = "//input[@id='txtEvalName']"; 
 	public static final String ER_TITLE = "//input[@id='txtEvalTitle']"; 
 	public static final String ER_ORGA = "//input[@id='txtEvalOrganization']";  
 	public static final String ER_PHONE = "//input[@id='txtEvalPhoneNo']";  
  	public static final String ER_ADDRESS = "//input[@id='txtEvalAddress']";
 	public static final String ER_TYPE_DROPDOWN = "//button[@data-id='ddlEvalType']//span[@class='bs-caret']"; 
 	//public static final String ERDROPDOWN = "//select[@id='ddlEvalType']";
 	public static final String ER_OTHER = "//span[text()='Other']";	
 	public static final String ER_OTHER_TEXT = "//input[@id='txtEVTypeOther']";
 	// This is Date of Report with ID property
 	public static final String ER_DOR_CALANDER = "//span[@class='glyphicon glyphicon-calendar']";
 	public static final String ER_DOR_TODAY = "//div[@class='datetimepicker-days']//th[text()='Today']";
 	// Date of report is to be filled with another property
 	
 	
 	
 	public static final String ERCOMMENTS = "//textarea[@id='txtEVComments']"; 
 	//public static final String ERCOMMENTS = "//*[@id=\"txtEVComments\"]";
 	
 	
 	
 	//  Button validations on the bottom of the page with 2 combinations ID and Text
 	public static final String DOCSAVE = "//button[@id='btnSave']";	
 	//public static final String DOCSAVE = "//button[contains(text(), ' Save')]";
 	public static final String DOCCANCEL = "//button[@id='btnCancel']";
 	//public static final String DOCCANCEL = "//button[contains(text(), ' Cancel')]";
 	public static final String PRINT = "//button[@id='btnSummary']";
 	//public static final String PRINT = "//button[contains(text(), ' Print Summary')]";
 	
 	
 	
 	// Below is to select the Diagnosis from the drop down
 	public static final String DIAG_DROPDOWNMORE = "//select[@name='ctl00$ContentPrimary$ddlDiagnosis']";
 	//public static final String DIAG_DROPDOWNMORE = "//select[@id='ddlDiagnosis']";
	public static final String DIAG_VIEWEDIT = "//a[contains(text(), 'View / Edit')]"; // After add Diagnosis, Edit option will gets display
 	public static final String DIAG_DELETE = "//a[contains(text(), 'Delete')]";  // After add Diagnosis, Delete option will gets display' 	
 	
 	
 	public static final String DIAG_DELETE_POPOP = "//a[contains(text(), 'Delete')]";
 	public static final String DIAG_DELETE_POPOP_CONFIRM = "//a[contains(text(), 'Delete')]";
    
 	
 	// After delete one diagnosis, Click on Save again in the bottom of the page
 	
 		       	
 	// *************************** Etiology screen ***************************// 	 	
 	public static final String ETI_ETIOLOGY= "//a[contains(text(), 'Etiology')]"; 	 
 	
 	// Header validations
 	public static final String ETI_HISTORY = "//a[@id='aRecCnt']"; 
 	public static final String ETI_ETIOLOGY_SUM = "//th[contains(text(), 'Etiology')]";
 	public static final String ETI_STARTDATE_SUM = "//*[@id=\"gvEtiologyView\"]/tbody/tr/th[3]"; 
 	public static final String ETI_ENDDATE_SUM = "//*[@id=\"gvEtiologyView\"]/tbody/tr/th[4]";
 	public static final String ETI_DELETEALL_SUM = "//input[@name='chkDelAll']";
    
 	
 	// Below is to select Etiology type from the drop down
 	public static final String LIST_ETI_DROPDOWN = "//button[@data-id='ContentPrimary_lstEtiology']//div[@class='filter-option-inner']";
 	
 	 	
 	//Save button in Etiology screen after user select one OR multiple etiology selections
	public static final String ETI_SAVE = "//button[@id='btnSaveEtiology']";
 	//public static final String ETI_SAVE = "//button[contains(text(), 'Save')]"; 		
	
	
	//   ******************************************************************************************************   //
 	// Eligibility process flow for the users  as a SC login (D034315) - This is to click on "Determine DDD eligibility button"
	   public static final String ELIGIDDDBUTTON = "//input[@name='ctl00$btnDetermineEligibility']";
	//public static final String ELIGIDDDBUTTON = "//input[@id='btnDetermineEligibility']";
	
	// Capture successful message on top left corner after SC clicks on "Determine DDD Eligibility" button
	// This  should be capture after user clicks on DDD button in 2ms interval
	
	
	// Login as a SC Supervisor (D031826) to give DDD Eligible approval - http://ddqaweb1.preprod.des:8080/organization/ddd/focusdd/frm_Login.aspx
	
	// Consumer administration -->  Eligibility Determination/Redetermination -->	
	public static final String ELIGIDETERREDETER = "//a[contains(text(),'Eligibility Determination/Redetermination')]";
	public static final String ELIGIYESBUTTON = "//input[@id='ContentPrimary_RadioButton1']"; // To click on YES radio button
	public static final String ELIGINOBUTTON = "//input[@id='ContentPrimary_RadioButton2']"; // To click on NO radio button	
	public static final String ELIGIDETERNOTES = "//textarea[@name='ctl00$ContentPrimary$txtNotes']"; // This is to give approve/ reject notes by SC/ SCS
	//public static final String ELIGIDETERNOTES = "//textarea[@id='ContentPrimary_txtNotes']";	// With another property -ID
	public static final String ELIGIFINALSAVE = "//input[@id='ContentPrimary_btnSaveContinue']";
	//public static final String ELIGIFINALSAVE = "//input[@name='ctl00$ContentPrimary$btnSaveContinue']";	
	
	
	// Login as a SC (D034315) From Consumer administration - Click on "View My Consumers" -This is to view DDD/ LTC is approved or not
	public static final String ELIGIVIEWMYCONSUMERS = "//a[contains(text(),'View My Consumers')]";  //From consumer administration/ view my consumers  
	//public static final String ELIGIVIEWMYCONSUMERS = "//a[@id='lnkViewMyConsumers']";	
	public static final String ELIGIWORKERDROPDOWN = "//div[contains(text(),'PRIMARY')]"; 
	public static final String ELIGICLIENTDROPDOWN = "//div[contains(text(),'--SELECT--')]"; 
	public static final String ELIGIMYCONSUMERS = "(//a[@data-toggle='collapse'])[1]";
	public static final String ELIGISTATUS = "//*[text()='APPROVED']";
	public static final String ELIGISELECT = "//a[contains(text(),'Select')]"; //This is to select the consumer which have got DDD eligible approved after SC/ SCS is approved
		
	
	
    //  ************* After Eligibility process --------------  Create ISP envelope, Add new service and Vendor selection process *************	
	
	// To click on "Consumer Main Menu" from Address bar

	
	// Create ISP Envelope
	public static final String ISPSERVICE = "//a[contains(text(),'ISP Service Plan')]";   //To select ISP service plan from Consumer Main Menu address bar
	public static final String ISPANNUALDATE = "//input[@id='ContentPrimary_txtAnnual']"; // To select annual start date
	//public static final String ISPANNUALDATE = "//input[@name='ctl00$ContentPrimary$txtAnnual']";  //This is with Name property which will replace X Path with ID property
	public static final String ISPREVIEWDATE = "//input[@id='ContentPrimary_txtAnnual']"; // To select annual review date
	//public static final String ISPREVIEWDATE = "//input[@name='ctl00$ContentPrimary$txtReviewComplete']";  - This is to be filled with Review date - name property
	public static final String ISPCREATENEW = "//input[@value='Create New ISP Envelope']";  // This is to click on ISP button - To create new ISP envelope
	//public static final String ISPCREATENEW = "//input[@name='ctl00$ContentPrimary$btnAddISP']"; // To create new ISP envelope with name property.
	
	
	// After click on "Create New ISP Envelope" -  "Alert" gets displayed, This is to be handle with OK button
		
	/*
	 * // Switching to Alert Alert alert = driver.switchTo().alert(); // Capturing
	 * alert message. String alertMessage= driver.switchTo().alert().getText(); //
	 * Displaying alert message System.out.println(alertMessage);
	 * Thread.sleep(5000); // Accepting alert alert.accept(); }
	 */	
	
		
	// To capture successful message after ISP plan gets created - Instead Span tag below, To be handled with another property
	public static final String ISPSUCCESSFULMSG = "//span[contains(text(),'FOCUS ISP Date and New ISP Envelope Successfully Created')]";	
	
	
	
	
	
	
	
	
	
	
	
	
	// To validate "New Service" validation after ISP creation	- This gets displayed just below ISP dates section
	
	// To click on  "Add New Service"  hyperlink is below
	public static final String SRVCENEW = "//a[@id='ContentPrimary_lnkAddNewService']";  // This is to click "Add New Service" with ID property
	//public static final String SRVCENEW = "//a[contains(text(), 'Add New Service')]";  // This is to click "Add New Service" with text property
	
	
	// The below is to click "Add New Service" hyperlink with "href" property 
	//public static final String SRVCNEW = "//a[@href='javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(\"ctl00$ContentPrimary$lnkAddNewService\", \"\", true, \"\", \"\", false, true))']";
	
	
	public static final String SRVCEDROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlService']"; 
	//public static final String SRVCEDROPDOWN = "//select[@id='ContentPrimary_ddlService']";  // This is with ID property	
	
	
	
	// Verify Payment type is selected as PAID Service or not (Depends upon service type - Direct Service/ Indirect service will be selected in radio button) 
    // Select service as "OEA" and verify "Paid Service" radio button is checked by default
	
    
    public static final String SRVCESTARTDATE = "//input[@name='ctl00$ContentPrimary$txtStartDate']"; //Same as ISP start date from previous screen
    //public static final String SRVCESTARTDATE = "//input[@id='ContentPrimary_txtStartDate']"; // This is with ID property
	public static final String SRVCEENDDATE = "//input[@name='ctl00$ContentPrimary$txtEndDate']";  // Same as ISP end date from previous screen
	//public static final String SRVCEENDDATE = "//input[@id='ContentPrimary_txtNoUnitsApproved']";  // This is with ID property
	public static final String SRVCEREQUUNITS = "//input[@name='ctl00$ContentPrimary$txtRequestedUnits']";
	//public static final String SRVCEREQUUNITS = "//input[@id='ContentPrimary_txtRequestedUnits']";	// This is with ID property and this is where UNITS requested first time for the consumer
	public static final String SRVCCOMMENTSNEW = "//textarea[@name='ctl00$ContentPrimary$txtComments']";	
	//public static final String SRVCCOMMENTSNEW = "//textarea[@id='ContentPrimary_txtComments']"; // Comments with ID property
	public static final String SRVCESAVE = "//input[@name='ctl00$ContentPrimary$btnSave']";
    //public static final String SRVCESAVE = "//input[@id='ContentPrimary_btnSave']";	// This is with ID property
	
	
	
	// Capture successful message after service is created and updated
	public static final String SRVCMSG = "//span[contains(text(), 'Record successfully Saved/Updated')]";	
	
	
	// Below actions are after Service is getting created by SC or SCS, SC/ SCS will send approval to supervisors to get an approval 
	// Click on "Submit for Approval" from ISP plan screen under "Pending Approval & Approved" panel
	public static final String SRVCSUBMITAPPROVAL = "";		
	public static final String SRVCCOMMENTSOUT = "//a[contains(text(), 'Comments and Outcomes')]";	
	//Below is change the comments and outcomes
	public static final String SRVCCOMMENTSEDIT = "";		
	// Print successful message after "Submit for approval" from ISP screen
	public static final String SRVCSUBMITMSG = "//span[contains(text(), 'Your request has been submitted')]";		
	
	
	
	
	
	
	
	
	//Login as SCS - "D031826" - Consumer administration - Service approvals - To give approval - It should go to next level
	public static final String SRVCCONSADMIN = "//a[contains(text(), 'Consumer Administration ')]";
	public static final String SRVCAPPLINK = "//a[contains(text(), 'Service Approvals')]";
	//Click on EDIT link against the consumer name	
	
	
	// To give approved NOTES from consumer service approval screen
	public static final String SVCAPPNOTES ="//textarea[@name='ctl00$ContentPrimary$txtNotes']"; 
	// The below is to fill "Approved Units" under "Consumer Service Approval" screen
	public static final String SRVCAPPROUNITS = "//input[@name='ctl00$ContentPrimary$txtApprovedUnits']"; 
	//public static final String SRVCAPPROUNITS = "//input[@id='ContentPrimary_txtApprovedUnits']"; 

	
	// If UNITS are more than requested OR InValid number, pop op warning message and capture that warning message to print it in the console
	public static final String SRVCPOPOP = "//span[contains(text(), 'Approved Units cannot be greater than Requested Units')]";
	// To see - View Services hyperlink just above CANCEL button in the same page
	public static final String SRVCVIEW = "//a[contains(text(), 'View Services')]";
	// To click on - CLOSE - pop op from "View Services" pop op
	public static final String SRVCCLOSEPOPOP = "//a[contains(text(), 'Close')]";
	// Again GIVE UNITS approved same as requested and click on SAVE button
	public static final String SRVCAPPRSAVE = "//input[@name='ctl00$ContentPrimary$btnSave']"; 
	//public static final String SRVCAPPRSAVE = "//input[@id='ContentPrimary_btnSave']";	
	// To capture warning message which is showing in the top of the page - Should escalated to next level in order to get an approval
	public static final String SRVCNXTLEVEL = "//span[@id='ContentPrimary_lblMessage']";
	
	
	
	
	
	
	
	
	
	// The below hyperlink is showing under "Add New Service" panel and this to be captured
	public static final String SRVCALLENTERED = "//a[contains(text(), 'Submit ALL Entered for Approval')]";	
	// The below hyperlink is showing under "Add New Service"  panel and this to be captured  
	public static final String SRVCALLAPPROVAL = "//a[@id='ContentPrimary_lnkSubmitAllChangePending']";
	
	
	
	
	
	
	
	
	
	
	
	
	
	// Login as APM - D016967 - Consumer administration - Service approvals - To give approval - It should go to next level
	// Follow steps from 390 to 413
	
	
	
	
	
	// Login as DGMT - D028750 - Consumer administration - Service approvals - To give approval  - It should go to next level
	// Follow steps from 390 to 413
	
	
	
	// login as SC - D034315 to check the service OEA  is approved status or not - D034315 - Consumer administration - view my consumers
	// Follow steps from 390 to 413
	
	
	
	
	
	// After service approval - To verify ISP service panel in SC login (D034315)
    public static final String SRVCDELETE = "//a[contains(text(), 'Delete')]"; // After service approval, Verify DELETE link showing or not
    public static final String SRVCCHANGE = "//a[contains(text(), 'Change')]"; // After service approval, Verify CHANGE link showing or not
	public static final String SRVCCOMMENTS = "//a[contains(text(), 'Comments and Outcomes')]"; // After service approval, Verify Comments section showing or not
	public static final String SRVCDELTEPOPOP = ""; // This is Alert after click on Delete button
	
	
	// Below is to create New Authorization
	//Consumer main menu -> Vendor selection & authorization -> Clicking on "Create New Authorization" from same screen for the particular screen
	public static final String VSAUTHNEW = "//a[contains(text(), 'Create New Authorization')]";	
	//public static final String VSAUTHNEW = "//a[@id='ContentPrimary_dbgAvailableServices_Hyp1_0']";
	
	

	// Vendor selection screen
	// Click on "Bypass Vendor Call" check box
	public static final String VSBYPASS = "//input[@name='ctl00$ContentPrimary$chkByPass']";
	//public static final String VSBYPASS = "//input[@id='ContentPrimary_chkByPass']";
	public static final String VSAUTHSTARTDATE = "//input[@name='ctl00$ContentPrimary$txtAuthStartDate']"; // same like Service start date													 
	//public static final String VSAUTHSTARTDATE = "//input[@id='ContentPrimary_txtAuthStartDate']";
	public static final String VSAUTHENDDATE = "//input[@name='ctl00$ContentPrimary$txtAuthEndDate']"; // same like Service end date
    //public static final String VSAUTHENDDATE = "//input[@id='ContentPrimary_txtAuthEndDate']";
	public static final String VSVENDORTYPE = "//select[@name='ctl00$ContentPrimary$ddlVendorType']";
	public static final String VSVENDORNAME = "//input[@name='ctl00$ContentPrimary$txtVendorName']";  // Provide vendor name as - bright
	public static final String VSSEARCH = "//input[@name='ctl00$ContentPrimary$btnSearch2']"; 
    
	
	
	
	// Select "A Brighter Avenue, L.L.C." from Search results
	// Following is Gender preference
	public static final String VSWORKERGENPRE = "//select[@name='ctl00$ContentPrimary$ddlWorkerGenderPreference']"; 
    //public static final String VSWORKERGENPRE = "//select[@id='ContentPrimary_ddlWorkerGenderPreference']";
	
	
	
	// Select any one or two special needs
	public static final String VSSPECIALNEEDS = "//*[@id=\"ispMain\"]/div[6]/div/table/tbody/tr/td/table/tbody/tr[10]/td/table/tbody/tr[2]/td[2]/div";
	//public static final String VSSPECIALNEEDSSELECT = "//*[@id=\"ispMain\"]/div[6]/div/table/tbody/tr/td/table/tbody/tr[10]/td/table/tbody/tr[2]/td[2]/div";
		
	
	// Save and Continue on Vendor selection
	public static final String VSSAVECONT = "//input[@name='ctl00$ContentPrimary$btnSave']";	
	//public static final String VSSAVECONT = "//input[@id='ContentPrimary_btnSave']";

	
	// Select one Office/Site selection & Authorization
	public static final String VSOFFICESELECTION = "//input[@id='ContentPrimary_dbgVendorSites_rdnSelect_0']";  // This is first office site
	public static final String VSOFFICESAVECONT = "//input[@name='ctl00$ContentPrimary$btnSaveContinue']";
	public static final String VSOFFICECANCELRETURN = "//input[@id='ContentPrimary_btnCancel']";
	
	
		
	// Service units allocation screen	
	public static final String VSSERVICELEVEL = "//select[@id='ContentPrimary_lvlservice_ddlLocationOfService']"; // Service level Drop down
	public static final String VSSERVICEHOURSPERWEEK ="//input[@id='ContentPrimary_lvlservice_txtHrsPerWeek']";
	
	public static final String VSSERVICESELECTDAYS = "//span[@id='ContentPrimary_lvlservice_lblDays']"; // Select all days
	public static final String VSSERVICESTARTTIME = "//input[@name='ctl00$ContentPrimary$lvlservice$txtTime']";
	//public static final String VSSERVICESTARTTIME = "//input[@id='ContentPrimary_lvlservice_txtTime']";
	public static final String VSSERVICEENDTIME = "//input[@name='ctl00$ContentPrimary$lvlservice$txtEndTime']";
	//public static final String VSSERVICEENDTIME = "//input[@id='ContentPrimary_lvlservice_txtEndTime']";
	public static final String VSSERVICECROSSST = "//textarea[@name='ctl00$ContentPrimary$lvlservice$txtPickupCrossStreet']"; 
	//public static final String VSSERVICECROSSST = "//textarea[@id='ContentPrimary_lvlservice_txtPickupCrossStreet']";
	public static final String VSSERVICEADD = "//input[@name='ctl00$ContentPrimary$lvlservice$btnAddNonTransportation']";
    //public static final String VSSERVICEADD = "//input[@id='ContentPrimary_lvlservice_btnAddNonTransportation']";
	
		
	
	// To perform Edit and Delete actions on Date and Time selection
	public static final String VSSERVICEEDIT = "//a[contains(text(), 'Edit')]";   
	//public static final String VSSERVICEEDIT = "//a[@href=\"javascript:__doPostBack('ctl00$ContentPrimary$lvlservice$gvNonTransportationServices$ctl02$btnEdit2','')\"]";
	//public static final String VSSERVICEEDIT = "//a[@id='ContentPrimary_lvlservice_gvNonTransportationServices_btnEdit2_0']";
	
	
	public static final String VSSERVICEDELETE = "//a[contains(text(), 'Delete')]";
	//public static final String VSSERVICEDELETE = "//a[@href=\"javascript:__doPostBack('ctl00$ContentPrimary$lvlservice$gvNonTransportationServices$ctl02$btnDelete','')\"]";
	//public static final String VSSERVICEDELETE = "//a[@id='ContentPrimary_lvlservice_gvNonTransportationServices_btnDelete_0']";
	
		
	
	// Below is to validate after performing "Delete" operation
	public static final String VSSERVICEDELETEOK = ""; // Alert message to handle
	public static final String VSSERVICEDELETECANCEL = ""; // Alert message to handle	
	
	
		
    // To fill requested units before "Save"
	public static final String VSSERVICEREQUNITS = "//input[@name = 'ctl00$ContentPrimary$dbgRequestUnits$ctl02$dbgtxtRequestUnits']";
	//public static final String VSSERVICEREQUNITS = "//input[@id='ContentPrimary_dbgRequestUnits_dbgtxtRequestUnits_0']";
	
	
	
	// To Check field "Effective Requested Units" after filled Requested Units
	public static final String VSSERVICEEFFREQUNITS = "//input[@name = 'ctl00$ContentPrimary$dbgRequestUnits$ctl02$dbgtxtEffectiveUnits']";
	//public static final String VSSERVICEEFFREQUNITS = "//input[@id='ContentPrimary_dbgRequestUnits_dbgtxtRequestUnits_0']";
	public static final String VSSERVICEFINALSAVE = "//input[@name = 'ctl00$ContentPrimary$btnSave']";
	//public static final String VSSERVICEFINALSAVE = "//input[@id='ContentPrimary_btnSave']";
	
	
	
	// To validate successful message
	public static final String VSSERVICESUCCESSMSG = "//span[contains(text(), 'The request details are successfully saved.')]";
		
	
	
	// To send final authorization to send vendors via "Authorize" button from "Service Units Allocation" screen
	public static final String VSSERVICEFINALAUTH = "//input[@name = 'ctl00$ContentPrimary$btnAuthorize']";
	//public static final String VSSERVICEFINALAUTH = "//input[@id='ContentPrimary_btnAuthorize']";
	
	
	// To verify Final authorizations panel section after authorizations to vendors to particular service
	public static final String VSFINALAUTHPANEL = "//div[@id='ContentPrimary_divAuthorizations']";
	//public static final String VSFINALAUTHPANEL = "//input[@name='ctl00$ContentPrimary$hfAuthorizations']";
	public static final String VSVERIFIEDSTARTDATE = "//a[contains(text(), 'Add Verified Service Start Date')]";
	public static final String VSVERIFIEDVIEWHISTORY = "//a[contains(text(), 'View History')]";
		
	
	// To see Change Authorization under "Finalized Authorizations " panel
	public static final String VSCHANGEAUTH = "//a[contains(text(), 'Change Authorization')]";	
	// public static final String VSCHANGEAUTH = "ContentPrimary_dbgApprovedAuthorizations_dbghlnkChangeAuthorization_0";
	// Give one unit higher and see message and give one unit less than authorized units
	
	
	public static final String VSCHANGEREASON = "//select[@name='cboChangeReason']"; // Select "Change units" from the drop down
	// public static final String VSCHANGEREASON = "//select[@id='cboChangeReason']"; // This is with ID property - For "Change units" drop down
	public static final String VSCHANGESAVE = "//input[@id='btnSave']";
	//public static final String VSCHANGESAVE = "//input[@name='btnSave']";
			
	
	// Below is just to validate "Delete" button in the change authorization pop op
	public static final String VSCHANGEDELETE = "//input[@name=\"btnTerminate\"]";
	//public static final String VSCHANGEDELETE = "//input[@id='btnTerminate']";   // This is with ID property
	
	
	
	
	
	
	
	
	
	
	
	// ************************************************************************************************************************** //
	// Web 2 - Vendor approval process -  http://ddqaweb2/organization/ddd/focusdd/frm_Login.aspx  - abrighteravenue0909, dddtesting
	
	// Click on "Service authorizations
	public static final String SVCAUTH = "//a[contains(text(), 'SERVICE AUTHORIZATIONS')]";
	
	
	// Below are link validations to print in Console
	public static final String SVCMAINLINK = "//a[contains(text(), 'Main Menu')]";
	public static final String SVCNOTILINK = "//a[contains(text(), 'Service Notifications')]";
	public static final String SVCPENDLINK = "//a[contains(text(), 'Pending Auths')]";
	public static final String SVCDECLINK  = "//a[contains(text(), 'Declined Requests')]";	
	public static final String SVCACKLINK  = "//a[contains(text(), 'Acknowledge Auths')]";
	public static final String SVCFINLINK  = "//a[contains(text(), 'Final Auths')]";
	public static final String SVCRESLINK  = "//a[contains(text(), 'Service Notifications without responses')]";
	
	
	// Click on "Acknowledge Auths"  link on the top of menu
	//public static final String SVCACKLINK  = "//a[contains(text(), 'Acknowledge Auths')]";
	
	
	// Select the Consumer name which is created from Web1 - To give acknowledge from Vendor side in the screen -"Authorizations - Acknowledge Authorizations"
	
	
		
	// Enter estimated start date 
	public static final String SVCESTIDATE = "//input[@name='txtEstimatedStartDate']";
	//public static final String SVCESTIDATE = "//input[@id='txtEstimatedStartDate']";
	//public static final String SVCESTIDATE = "//*[@id=\"txtEstimatedStartDate\"]";
	
	
	// Giving final acknowledge from vendor side by clicking on "Acknowledge" button under "New Authorizations" panel
	public static final String SVCACKNOW = "//input[@name='btnAcknowledge']";
	//public static final String SVCACKNOW = "//input[@id='btnNewAuthAck']";
	
		
	// This is just to validate "Modified Acknowledge" button in the bottom of the page under "Modified Authorizations" panel
	public static final String SVCMODACK = "btnModifiedAuthAck";
	
	
	
	
	// Log in again - Web 1 - http://ddqaweb1.preprod.des:8080/organization/ddd/focusdd/frm_Login.aspx    --   D034315
	// See Vendor selection/ authorization --> Finalized authorizations --> Check the column "Authorized Start Date" is showing date or NOT
	// If that column is showing date, which means, one vendor is acknowledged for the service to Consumer/ Client
		

	// Available Services panel - Column validations
    public static final String SVCCODEAVASER = "//a[@href=\"javascript:__doPostBack('ctl00$ContentPrimary$dbgAvailableServices$ctl01$ctl01','')\"]";
    public static final String SVCDDDAVASER ="//a[@href=\"javascript:__doPostBack('ctl00$ContentPrimary$dbgAvailableServices$ctl01$ctl02','')\"]";
    public static final String SVCTOTALAVASER = "//a[@href=\"javascript:__doPostBack('ctl00$ContentPrimary$dbgAvailableServices$ctl01$ctl03','')\"]";
    public static final String SVCTOTALAVAVASER = "//a[@href=\"javascript:__doPostBack('ctl00$ContentPrimary$dbgAvailableServices$ctl01$ctl04','')\"]";
    public static final String SVCWAITAVASER = "//a[@href=\"javascript:__doPostBack('ctl00$ContentPrimary$dbgAvailableServices$ctl01$ctl05','')\"]";
    public static final String SVCSTARTAVASER = "//a[@href=\"javascript:__doPostBack('ctl00$ContentPrimary$dbgAvailableServices$ctl01$ctl06','')\"]";
    public static final String SVCENDAVASER = "//a[@href=\"javascript:__doPostBack('ctl00$ContentPrimary$dbgAvailableServices$ctl01$ctl07','')\"]";
    
    	
	// Finalized Authorizations panel - Column validations 
	public static final String SVCCODE = "//a[@href=\"javascript:__doPostBack('ctl00$ContentPrimary$dbgApprovedAuthorizations$ctl01$ctl01','')\"]";
	public static final String SVCDDD  = "//a[@href=\"javascript:__doPostBack('ctl00$ContentPrimary$dbgApprovedAuthorizations$ctl01$ctl02','')\"]";
	public static final String SVCSTART = "//a[@href=\"javascript:__doPostBack('ctl00$ContentPrimary$dbgApprovedAuthorizations$ctl01$ctl03','')\"]";
	public static final String SVCEND   = "//a[@href=\"javascript:__doPostBack('ctl00$ContentPrimary$dbgApprovedAuthorizations$ctl01$ctl04','')\"]";
	public static final String SVCAUTHUNITS  = "//a[@href=\"javascript:__doPostBack('ctl00$ContentPrimary$dbgApprovedAuthorizations$ctl01$ctl05','')\"]";
	public static final String SVCPAIDUNITS  = "//a[@href=\"javascript:__doPostBack('ctl00$ContentPrimary$dbgApprovedAuthorizations$ctl01$ctl06','')\"]";
	public static final String SVCVERSTART   = "//td[contains(text(), 'Verified Service Start Date')]";
	
	
    // Higher rate approvals
	public static final String SVCCES = "//a[contains(text(), 'CES Higher Rate Approvals')]";
	
    // After click on CES Higher Rate Approvals
	public static final String SVCREPORT = "//a[contains(text(), 'Consumer Payment Report')]";
	public static final String SVCWORK = "//a[contains(text(), 'CES Worksheet')]";
    
    
    
	
	
	
	
	
	
	
	
	
	
	// Below are from Dashboard page after click on hyperlink "Client application"
	
	//Task Queue button validations
	public static final String TQSEARCH = "//a[contains(text(), 'Search')]";
	public static final String TQRESET = "//input[@type='submit']";
	public static final String TQPRINT = "//a[contains(text(), 'Print')]";
	
	
	//Progress notes button validations
	public static final String PNSEARCH = "//a[contains(text(), 'Search')]";
	public static final String PNRESET = "//input[@type='submit']";
	public static final String PNPRINT = "//a[contains(text(), ' Print')]";
	public static final String PNADDNOTE = "//input[@value='Add Note']";
	
	
	//Global Notification validations
	public static final String GNSEARCH = "//a[contains(text(), ' Search')]";
	public static final String GNSAVE = "//input[@value='Save']";
	public static final String GNPRINT = "//a[contains(text(), 'Print')]";
	
	
	//Claims Tracking validations
	public static final String CTSEARCH = "//a[contains(text(), 'Search')]";
	public static final String CTCANCEL = "//input[@value='Cancel']";
		
	
}
