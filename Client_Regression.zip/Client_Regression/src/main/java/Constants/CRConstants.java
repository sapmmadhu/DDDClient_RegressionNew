package Constants;

public class CRConstants {

	// LoginPage
	public static final String USER_NAME = "//input[@id='MainContent_txtUserName']";
	public static final String PASSWORD = "//input[@id='MainContent_txtPassword']";
	public static final String LOGIN = "//input[@id='MainContent_btnLogin']";

	// Client Application

	public static final String CLIENT_APPLICATION = "//a[contains(text(),'CLIENT APPLICATION')]";

	// Dashboard Page
	public static final String CONSUMER_ADMINISTRATION = "//a[contains(text(),'Consumer Administration ')]";
	public static final String VIEW_MY_CONSUMERS = "//a[contains(text(),'View My Consumers')]";
	public static final String ADD_CONSUMER = "//input[@value='Add Consumer']";
	public static final String LAST_NAME = "//input[@id='ContentPrimary_txtLastName']";
	public static final String FIRST_NAME = "//input[@id='ContentPrimary_txtFirstName']";
	public static final String GENDER = "//select[@name='ctl00$ContentPrimary$ddlGender']";
	public static final String DATE_OF_BIRTH = "//input[@id='ContentPrimary_txtDOB']";
	public static final String CONTINUE = "//input[@id='ContentPrimary_btnAddAndContinue']";
	public static final String ADD_AND_CONTINUE = "//a[contains(text(),'Add and Continue')]";
	public static final String POPUP = "(//button[contains(text(),'Close')])[2]";

	// Responsible party screen
	public static final String RP_FIRST_NAME = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtContactFN']";
	public static final String RP_LAST_NAME = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtContactLN']";
	public static final String CHECK_BOX_LIST = "//*[@id='ContentPrimary_ctrl_ContactAddress_chkAddNewAddr']/tbody/tr/td";
	public static final String HOME_CHECK_BOX = "//input[@id='ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0']";
	public static final String ADD_LINE_ONE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressLine1']";
	public static final String ADD_LINE_TWO = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressLine2']";
	public static final String CITY = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtCity']";
	public static final String STATE = "//select[@name='ctl00$ContentPrimary$ctrl_ContactAddress$ddlState']";
	public static final String ZIP = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtZip5']";
	public static final String HOME_PHONE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtHomePhonePrefixSuffix']";
	public static final String FOOTER_SCROLL = "//*[@id='footerInj']/div[1]";
	public static final String START_DATE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressStDate']";
	public static final String TODAY_DATE = "(//div[@class='datetimepicker-days']//th[contains(text(),'Today')])[1]";
	public static final String SAVE = "//input[@id='ContentPrimary_ctrl_ContactAddress_btnSave']";// Final Save button

	// Address validation
	public static final String USE_AS_ENTERED = "//input[@value='Use as Entered']";
	public static final String CLOSE = "//input[contains(@type,'button')]";
	public static final String FINAL_CLOSE = "//button[contains(text(),'Close')]";

	// Consumer address book
	public static final String CONSUMER_MAIN_MENU = "//li[@id='liConsumerMenu']//a[contains(text(),'Consumer Main Menu')]";
	public static final String DOCUMENTED_DISABILITIES = "//input[@id='lnkDocumentedDiabilities']";
	public static final String CONSUMER_MENU_LIST = "//ul[@class='dropdown-menu mega-dropdown-menu']/li/ul/li";
	public static final String DISABILITIES_TYPE_DROPDOWN = "//input[@id='ContentPrimary_DropDownList1']"; 

	// Functional limitations
	public static final String FUNCTIONAL_LIMITATIONS = "//input[@id='ContentPrimary_lbFuncLimit1']";
	public static final String FUNCTIONAL_LIMITATIONS_ROWS = "//*[@id=\"Table11\"]/tbody/tr"; 
																								
	public static final String ASSIGN_TO_DIAGNOSIS = "//input[@id='ContentPrimary_btnAssignFuncLimitations']";

	// Evaluation/ Report
	public static final String EVALUATION_REPORT = "//input[@id='ContentPrimary_lbDisablityPrioirty1']";
	public static final String ER_FIRSTNAME = "//input[@id='ContentPrimary_txtProfessionalName']";
	public static final String ER_TITLE = "//input[@id='ContentPrimary_txtProfessionalTitle']";
	public static final String ER_EVALUATION_DROPDOWN = "//input[@id='ContentPrimary_ddlProfessionalReportType']"; 
	public static final String ER_DATEREPORT = "//input[@id='ContentPrimary_txtProfessionalDateofReport']";
	public static final String ER_TODAY = "//div[@class='datetimepicker-days']//th[contains(text(),'Today')]";
	public static final String ER_COMMENTS = "//input[@id='ContentPrimary_txtProfessionalComments']"; 
																										
	public static final String ER_SAVE = "//input[@id='ContentPrimary_btnAssignProfessionalDetails']";

	/*
	 * // Etiology public static final String ETIOLOGY =
	 * "//input[@id='ContentPrimary_btnConcerns']"; // Add Etiology button public
	 * static final String ETIOLOGY_SELECT = "//input[@value='Select Etiology']";
	 * public static final String ETIOLOGY_TYPE = "//*[@id=\"CheckBoxList1\"]"; //
	 * Types of Etiology from the list public static final String ETIOLOGY_ASSIGN =
	 * "//input[@value='Assign']"; // Assigning Etiology selection public static
	 * final String ETIOLOGY_FINALSAVE = "//input[@value='Save']"; public static
	 * final String ETIOLOGY_LINKCLOSE = "//input[@id='lnkClose']"; // Before Save
	 * Etiology -To Check - Link Close
	 */

	// Demographics
	public static final String DEMO_LINK = "//a[contains(text(),'Demographics')]";
	public static final String DEMO_LANGUAGE_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlConsumerLanguage']";
	public static final String DEMO_ETHNICITY_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlEthnicity']";
	public static final String DEMO_TRIBE_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlTribe']";
	public static final String DEMO_INCONT_DROPDOWN = "//button[@data-id='ContentPrimary_Incontinent_Dropdownlist']";
	public static final String DEMO_EMERGENCY_PLAN_DROPDOWN = "//select[@name='ctl00$ContentPrimary$PowerDependent_Dropdownlist']";
	public static final String DEMO_COMMENTS = "//textarea[@name='ctl00$ContentPrimary$txtDisabilityDescription']";
	public static final String DEMO_REASON = "//select[@name='ctl00$ContentPrimary$ddlICAPReason']";
	public static final String DEMO_SAVE = "//input[@value='Save']";

	// Eligibility
	public static final String ELIGIDDDBUTTON = "//input[@name='ctl00$btnDetermineEligibility']";
	public static final String ELIGIDETERREDETER = "//a[contains(text(),'Eligibility Determination/Redetermination')]";
	public static final String ELIGIYESBUTTON = "//input[@id='ContentPrimary_RadioButton1']";
	public static final String ELIGINOBUTTON = "//input[@id='ContentPrimary_RadioButton2']";
	public static final String ELIGIDETERNOTES = "//textarea[@name='ctl00$ContentPrimary$txtNotes']"; // Determination
																										// notes
	public static final String ELIGIFINALSAVE = "//input[@value='Save']";
	public static final String ELIGISUCCESSMSG = "//span[contains(text(),'Save Successful')]";// Successful message
																								// validation
	public static final String ELIGIVIEWMYCONSUMERS = "//a[contains(text(),'View My Consumers')]";
	public static final String ELIGIWORKERDROPDOWN = "//div[contains(text(),'PRIMARY')]"; // Worker drop down
	public static final String ELIGICLIENTDROPDOWN = "//div[contains(text(),'--SELECT--')]"; // Client drop down
	public static final String ELIGIMYCONSUMERS = "(//a[@data-toggle='collapse'])[1]";
	public static final String ELIGISTATUS = "//*[text()='APPROVED']";
	public static final String ELIGISELECT = "//a[contains(text(),'Select')]";
	
	

//  ********* New Items are added below after Eligibility process which is ISP envelope, Add new service *********
	// Create ISP Envelope
	public static final String ISPSERVICE = "//a[contains(text(),'ISP Service Plan')]"; 
	public static final String ISPANNUALCOMPDATE = "//input[@id='ContentPrimary_txtAnnual']";
	public static final String ISPREVIEWCOMPDATE = "//input[@id='ContentPrimary_txtAnnual']";
	public static final String ISPCREATENEW = "//input[@value='Create New ISP Envelope']"; 
	
	// To handle pop op alert after click on "Create New ISP Envelope"

	// Add New Service
	public static final String SVCNEW = "//input[@id='ContentPrimary_lnkAddNewService']";
	public static final String SVCENTEREDAPPROVAL = "//input[@id='ContentPrimary_lnkSubmitAllPending']";	
	public static final String SVCDROPDOWN = "//ctl00$ContentPrimary$ddlService']"; 																					
	public static final String SVCREQUUNITS = "//select[@name='ctl00$ContentPrimary$txtRequestedUnits']";
	public static final String SVCSAVE = "//input[@value='Save']";
	public static final String SVCAPPRSTATUS = "//input[@id='lnkServiceApprovalRequestStatus']";

	// Click on the consumer ID (Auto approved) from Service approval status (After
	// new service approved) - this is for Vendor selection screen process

	public static final String VSBYPASSVENDORCALL = ""; // To click By Pass Vendor call check box which is showing 2nd panel
														
	public static final String VSAUTHSTARTDATE = ""; // This date should be same as service date as based on the approval of newly added service
														 
	public static final String VSAUTHENDDATE = ""; // This date should be same as service end date as based on the approval of newly added service
													
	public static final String VSVENDORTYPE = ""; // Select vendor type from the drop down
	public static final String VSSEARCH = ""; // this will search the available vendors
	public static final String VSVENDORCHECKBOX = ""; // select the Good To Go Vendor check box from the list
	public static final String VSWORKERGENPRE = ""; // To select worker gender preference
	public static final String VSSPECIALNEEDS = ""; // To select desired special needs from the check box list
	public static final String VSSAVECONTINUE = "";
	public static final String VSOFFICESITE = ""; // Vendor site Office selection
	public static final String VSOFFICESITESAVE = "";
	public static final String VSSERVICESELECTDAYS = ""; // To select all days for service
	public static final String VSSERVICESTARTTIME = "";
	public static final String VSSERVICEENDTIME = "";
	public static final String VSSERVICECROSSST = ""; // To fill cross street information check box like alpha numeric characters
														
	public static final String VSSERVICEADD = "";
	public static final String VSSERVICEREQUNITS = ""; // To fill requested units which is less than available units or equal
														 
	public static final String VSSERVICEFINALSAVE = "";
	public static final String VSSERVICEFINALAUTH = ""; // This is for sending final authorization to all the vendors
	
	
	
	
	
	
	
	//  *****************  New Documented disabilities screen   ************************************ //
	
	public static final String ADD_DIAGNOSIS_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlDiagnosis']"; 
	public static final String FL_TABLE = "//*[@id='ctl00_ContentPrimary_cblFunctionalLimitation']/tbody";
	public static final String FL_ONE = "//textarea[@id='txtFLEconomic']";
	public static final String FL_TWO = "//textarea[@id='txtFLCapacity']";
	public static final String FL_THREE = "//textarea[@id='txtFLLearning']";
	public static final String ERNAME = "//input[@id='txtEvalName']";
	public static final String ERTITLE = "//input[@id='txtEvalTitle']";
	public static final String ERADDRESS = "//div[contains(text(), 'Address')]";	
	public static final String ERDROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlEvalType']";
	public static final String ERDOR = "//input[@id='txtEVReportDate']";
	public static final String ERCOMMENTS = "//textarea[@id='txtEVComments']";
    public static final String ERSAVE = "//button[@id='btnSave']";	
    public static final String ETIOLOGY ="//a[contains(text(), 'Etiology')]";
    
    public static final String VIEWEDIT = "//a[contains(text(), 'View / Edit')]";
    public static final String DELETE = "//a[contains(text(), 'Delete')]";   
    
    
    // Button validations
    public static final String PRINT = "//button[@id='btnSummary']";
    public static final String CANCEL = "//button[@id='btnCancel']";
    
    // Diagnosis summary headings validation 
    public static final String QDSUMMARY = "//div[contains(text(), 'Summary')]";
    public static final String QDSEQUENCE = "//*[@id=\"gvDiagnosisView\"]/tbody/tr[1]/th[1]";
    public static final String QDDIAGNOSIS = "//*[@id=\"gvDiagnosisView\"]/tbody/tr[1]/th[2]";
    public static final String QDSTARTDATE = "//*[@id=\"gvDiagnosisView\"]/tbody/tr[1]/th[3]";
    public static final String QDVIEWEDIT = "//div[contains(text(), 'View/Edit')]";
    public static final String QDDIAGNOSISBOX = "//div[contains(text(), 'Diagnosis')]";
    public static final String FLHEADER = "//div[contains(text(), 'Functional Limitations')]";
    public static final String ERHEADER = "//div[contains(text(), 'Evaluation/Report')]";
    
    
    
    
	
	
    
    
    
    
    
    
	
	//Task Queue button validations
	public static final String TQSEARCH = "//a[contains(text(), 'Search')]";
	public static final String TQRESET = "//input[@type='submit']";
	public static final String TQPRINT = "//a[contains(text(), 'Print')]";
	
	
	//Progress notes button validations
	public static final String PNSEARCH = "//a[contains(text(), 'Search')]";
	public static final String PNRESET = "//input[@type='submit']";
	public static final String PNPRINT = "//a[contains(text(), ' Print')]";
	public static final String PNADDNOTE = "//input[@value='Add Note']";
	
	
	//Global Notification validations
	public static final String GNSEARCH = "//a[contains(text(), ' Search')]";
	public static final String GNSAVE = "//input[@value='Save']";
	public static final String GNPRINT = "//a[contains(text(), 'Print')]";
	
	
	//Claims Tracking validations
	public static final String CTSEARCH = "//a[contains(text(), 'Search')]";
	public static final String CTCANCEL = "//input[@value='Cancel']";
		
	
}
