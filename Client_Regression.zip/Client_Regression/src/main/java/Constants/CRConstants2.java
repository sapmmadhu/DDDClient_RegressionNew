package Constants;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;


public class CRConstants2 {
	WebDriver driver;
	
	// LoginPage - SC level
	
	// QA & UAT
	public static final String USER_NAME2 = "//input[@id='txtUserName']";
	public static final String PASSWORD2 = "//input[@id='txtPassword']";
	public static final String LOGIN2 = "//input[@id='btnLogin']";
	
	

	// Service authorizations - QA
	//public static final String SERVICE_AUTHLINK = "//a[text()='SERVICE AUTHORIZATIONS']";	
	// Service authorizations - UAT
	public static final String SERVICE_AUTHLINK = "//a[text()='SERVICE AUTHORIZATIONS - TEST ENVIRONMENT']";
	
	
	
	// service notification - QA
	//public static final String CLIENT_SEARCH = "//a[@id='lnkbtnServiceNotifications']";	
	// service notifications- UAT
	public static final String SERVICE_NOTIFICATIONS = "//a[@id='lnkbtnServiceNotifications']";


	
	// UAT
	public static final String SERVICE_DDD = "//input[@id='rblServiceCode_0']";
	public static final String SERVICE_DROPDOWN = "//input[@id='txtAssistsId']";
    public static final String SERVICE_SEARCH = "//input[@id='btnSearch']";
    
    
	// After search, match the Assist ID from Vendor call queue in Web1
    public static final String SERVICE_VIEWDETAILS = "//a[text()='View Details']";
    public static final String SERVICE_YES = "//input[@name='rblAccept']";
    public static final String SERVICE_VENDORLEVEL = "//input[@id='chkVendorLevelAuth']";
    public static final String SERVICE_OFFICELEVEL = "//input[@id='dbgOfficeSiteInfo_chkAll']";
    
	
    // Select Calander level and click on current date  
    
    
    public static final String SERVICE_SUBMIT = "//input[@id='btnSubmit']";    
    public static final String SERVICE_MAINMENU = "//a[text()='Main Menu']";
    
    public static final String SERVICE_PENDING_NOTI = "//a[text()='Pending Authorizations']";
    public static final String SERVICE_VIEWDETAILS2 = "//a[text()='View Details']";
    //public static final String SERVICE_VIEWDETAILS2 = "//a[@id='dbgServices_hypViewDetails_0']";
    
    
    
    // Below is to click on "Return" to submit vendor auth and to see "Pending Authorization" screen
    public static final String SERVICE_RETURN = "//input[@id='btnReturn']";
    
    // Below is Decline request from Vendor side
    public static final String SERVICE_DECLINE = "//input[@id='chkDeclineReq']";
    
    
    
    
    
    // Below lines are for SC final Authorization to Vendor after their approval
    public static final String SERVICE_PEDNING_CALLS = "//a[@id='ContentPrimary_dbgAvailableServices_HypViewPending_0']";
    public static final String SERVICE_VENDOR_RESPPONSE = "//a[@id='ContentPrimary_dbgPendingAuths_lnkbtnVendorResponses_0']";
    // Before click on Accept radio button, Match -Vendor Call Tracking Number and then click
    public static final String SERVICE_ACCEPT = "//input[@id='html_radAccept']";
    public static final String SERVICE_CONTINUE = "//input[@id='ContentPrimary_btnContinue']";
    // Before click on Authorize button, Match - -Vendor Call Tracking Number and then click on Radio button
    public static final String SERVICE_OFFICE = "//input[@id='ContentPrimary_dbgVendorSites_rdnSelect_0']";
    public static final String SERVICE_AUTHORIZE = "//input[@id='ContentPrimary_btnAuthorize']";
    
    
    
    
    
    // Below lines are for Vendor Acknowledge/ Final Auths validation in Web2 - Vendor side
    public static final String SERVICE_ACKNAUTH = "//a[@id='lnkbtnAcknowledgeAuthorizations']";
    // Match tracking number and then click on check box
    public static final String SERVICE_CHECKBOX = "//input[@id='dbgNewAuths_chkNewAuth_1']";
    public static final String SERVICE_ACKNOWLEDGE= "//input[@id='btnNewAuthAck']";
    public static final String SERVICE_FINALAUTHS = "//a[text()='Final Auths']";
    public static final String SERVICE_TRACKINGID = "//input[@id='txtTrackingNumber']";
    public static final String SERVICE_AUTHSEARCH = "//input[@id='btnSearch']";
    
    
    //Tracking number in "Ackowledgement" section
    public static final String SERVICE_TRACKINGNUM = "//a[text()='TrackingNumber']";
    //Tracking number in "Final Acknowledgement" section which were modified by customer
    public static final String SERVICE_TRACKINGNUM1 = "//a[text()='TrackingNumber']";
    
    
    
    
}
