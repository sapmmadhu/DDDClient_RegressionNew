package Constants;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;


public class CRConstants2 {
	WebDriver driver;
	
	// LoginPage - SC level
	
	// QA & UAT
	public static final String USER_NAME2 = "//input[@id='txtUserName']";
	public static final String PASSWORD2 = "//input[@id='txtPassword']";
	public static final String LOGIN2 = "//input[@id='btnLogin']";
	
	
     public static final String SCLOGINCLIENTLINK = "//a[text()='CLIENT APPLICATION - TEST ENVIRONMENT']";
     
     // Tracking number field
     public static final String SCTRACKINGNUMBERSEARCH = "//input[@id='ContentPrimary_txtVCTrackingNumber']";
     
	// Service authorizations - QA
	//public static final String SERVICE_AUTHLINK = "//a[text()='SERVICE AUTHORIZATIONS']";	
	// Service authorizations - UAT
	public static final String SERVICE_AUTHLINK = "//a[text()='SERVICE AUTHORIZATIONS - TEST ENVIRONMENT']";
	
	
	
	// service notification - QA
	//public static final String CLIENT_SEARCH = "//a[@id='lnkbtnServiceNotifications']";	
	// service notifications- UAT
	public static final String SERVICE_NOTIFICATIONS = "//a[@id='lnkbtnServiceNotifications']";


	
	// UAT
	public static final String SERVICE_DDD = "//input[@id='rblServiceCode_0']";
	public static final String SERVICE_DROPDOWN = "//select[@id='ddlDDDcode']";
    public static final String SERVICE_SEARCH = "//input[@id='btnSearch']";
    
    
	// After search, match the Assist ID from Vendor call queue in Web1
    public static final String SERVICE_VIEWDETAILS = "//a[text()='View Details']";
    public static final String SERVICE_YES = "//input[@name='rblAccept']";
    public static final String SERVICE_VENDORLEVEL = "//input[@id='chkVendorLevelAuth']";
    public static final String SERVICE_OFFICELEVEL = "//input[@id='dbgOfficeSiteInfo_chkAll']";
    
	
    // Select Calander level and click on current date  
    public static final String SERVICE_ESTIMATED_START = "//input[@id='txtEstimatedStartDate']";
    public static final String SERVICE_VENDOR_CLOSE_DATE = "//span[@id='lblVCCloseDate']";
    
    
    
    
    
    public static final String SERVICE_SUBMIT = "//input[@id='btnSubmit']";    
    public static final String SERVICE_MAINMENU = "//a[text()='Main Menu']";
    
    public static final String SERVICE_PENDING_NOTI = "//a[text()='Pending Authorizations']";
    public static final String SERVICE_VIEWDETAILS2 = "//a[text()='View Details']";
    //public static final String SERVICE_VIEWDETAILS2 = "//a[@id='dbgServices_hypViewDetails_0']";
    
    
    
    // Below is to click on "Return" to submit vendor auth and to see "Pending Authorization" screen
    public static final String SERVICE_RETURN = "//input[@id='btnReturn']";
    
    // Below is "Decline request" from Vendor side in Web2 by choosing reason for declined request
    public static final String SERVICE_DECLINE = "//input[@id='rblAccept_1']";
    public static final String SERVICE_DECLINE_DROPDOWN = "//select[@id='dblReasons']";
    public static final String SERVICE_DECLINE_FOOTER = "//div[@class='header-footer-toggle']";
    public static final String SERVICE_DECLINE_SUBMIT = "//input[@id='btnSubmit']";
    
    
    
    // Below lines are for SC final Authorization after Vendor responded/ authorized for service request
    public static final String SERVICE_PEDNING_CALLS = "//a[@id='ContentPrimary_dbgAvailableServices_HypViewPending_0']";
    public static final String SERVICE_VENDOR_RESPPONSE = "//a[@id='ContentPrimary_dbgPendingAuths_lnkbtnVendorResponses_0']";
    // Before click on Accept radio button, Match -Vendor Call Tracking Number and then click
    public static final String SERVICE_ACCEPT = "//input[@id='html_radAccept']";
    public static final String SERVICE_CONTINUE = "//input[@id='ContentPrimary_btnContinue']";
    // Before click on Authorize button, Match - -Vendor Call Tracking Number and then click on Radio button
    public static final String SERVICE_OFFICE = "//input[@id='ContentPrimary_dbgVendorSites_rdnSelect_0']";
    public static final String SERVICE_AUTHORIZE = "//input[@id='ContentPrimary_btnAuthorize']";
    
    
 // Below is to find another way to consumer details from Consumer admin -> Vendor call queue with the help of Tracking number
    public static final String SC_CONS_VENDOR_CALLQUEUE = "//a[@id='lnkVendorCallQueue']";
    public static final String SC_CONS_ASSIST_ID = "//input[@id='ContentPrimary_txtAssistsID']";
    public static final String SC_CONS_SEARCH = "//input[@id='ContentPrimary_btnSearch']";
    
    
    
    
    // Below lines are for Vendor Acknowledge/ Final Auths validation in Web2 - Vendor side
    // Below is to click on "Acknowledge Auths" in the top line
    
    public static final String SERVICE_ACKNAUTH = "//a[text()='Acknowledge Auths']";
    
    // Match tracking number and then click on check box against the consumer name
    public static final String SERVICE_CHECKBOX = "//input[@id='dbgNewAuths_chkNewAuth_1']";
    public static final String SERVICE_ACKNOWLEDGE= "//input[@id='btnNewAuthAck']";
    public static final String SERVICE_FINALAUTHS = "//a[text()='Final Auths']";
    public static final String SERVICE_TRACKINGID = "//input[@id='txtTrackingNumber']";
    public static final String SERVICE_AUTHSEARCH = "//input[@id='btnSearch']";
    public static final String SERVICE_FINALCONSNAME = "//a[@id='dbgAuths_hypConsumerName_0']";
    public static final String SERVICE_RETURN_FINAL = "//input[@id='btnReturn']";
    
    public static final String SERVICE_MEDICOVERAGE = "//a[text()='View Medical Coverage & Waiver Information ']";
    
    
    
    //Tracking number in "Ackowledgement" section validation
    public static final String SERVICE_TRACKINGNUM = "//a[text()='TrackingNumber']";
    //Tracking number in "Final Acknowledgement" section which were modified by customer
    public static final String SERVICE_TRACKINGNUM1 = "//a[text()='TrackingNumber']";   
    
    
    
    // Footer scroll down - Consumer admin -> Vendor call queue
    public static final String SERVICE_FOOTER = "//div[@class='header-footer-toggle']";
    
    
    
    
}
