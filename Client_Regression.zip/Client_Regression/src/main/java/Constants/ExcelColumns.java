package Constants;

public class ExcelColumns {
	public static final String USER_NAME = "SCU";
	public static final String PASSWORD = "SCP";
	public static final String FIRSTNAME = "CFN";
	public static final String LASTNAME = "CLN";
	public static final String GENDER = "CG";
	public static final String CONSDOB = "CDOB";
	public static final String RESFIRSTNAME = "RFN";
	public static final String RESLASTNAME = "RLN";
	public static final String RESCHECKBOX = "RSB";
	public static final String RESADDLINEONE = "RA1";
	public static final String RESADDLINETWO = "RA2";
	public static final String RESCITY = "RCTY";
	public static final String RESSTATE = "RS";
	public static final String RESZIP = "RZ";
	public static final String RESHOMEPHONE = "RHP";	
	
}
