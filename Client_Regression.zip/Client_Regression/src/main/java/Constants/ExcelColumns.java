package Constants;

public class ExcelColumns {
	public static final String USER_NAME = "UN";
	public static final String PASSWORD = "PW";
	public static final String FIRSTNAME = "CFN";
	public static final String LASTNAME = "CLN";
	public static final String GENDER = "CG";
	public static final String CONSDOB = "CDOB";
	public static final String RP_FIRST_NAME = "RFN";
	public static final String RP_LAST_NAME = "RLN";
	public static final String HOME_CHECK_BOX = "RSB";
	public static final String ADD_LINE_ONE = "RA1";
	public static final String ADD_LINE_TWO = "RA2";
	public static final String CITY = "RCTY";
	public static final String STATE = "RS";
	public static final String ZIP = "RZ";
	public static final String HOME_PHONE = "RHP";	
	public static final String DISABILITIES_TYPE_DROPDOWN = "DISNA";
	public static final String FUNCTIONAL_LIMITATIONS = "FL";
	public static final String FUNCTIONAL_LIMITATIONS_ONE = "FL";
	public static final String FUNCTIONAL_LIMITATIONS_TWO = "FL";
	public static final String ER_FIRSTNAME = "ERN";
	public static final String ER_TITLE = "ERT";
	public static final String ER_EVALUATION_DROPDOWN = "TOE";
	public static final String ETIOLOGY_TYPE = "ETINA";
	public static final String DEMO_LANGUAGE_DROPDOWN = "DEMLAN"; 
	public static final String DEMO_ETHNICITY_DROPDOWN = "DEMETH";
	public static final String DEMO_TRIBE_DROPDOWN = "DEMTR"; 
	public static final String DEMO_INCONT_DROPDOWN = "DEMIN"; 
	public static final String DEMO_EMERGENCY_PLAN_DROPDOWN = "DEMEMER";
	public static final String DEMO_COMMENTS = "DEMEMER";
	public static final String ELIGIWORKERDROPDOWN = "DEMEMER";
	public static final String ELIGICLIENTDROPDOWN = "DEMEMER";	
}


