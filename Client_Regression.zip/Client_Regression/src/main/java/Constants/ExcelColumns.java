package Constants;

public class ExcelColumns {
	public static final String USER_NAME = "UN";
	public static final String PASSWORD = "PW";
	public static final String FIRSTNAME = "CFN";
	public static final String LASTNAME = "CLN";
	public static final String GENDER = "CG";
	public static final String CONSDOB = "CDOB";
	public static final String RP_FIRST_NAME = "RFN";
	public static final String RP_LAST_NAME = "RLN";
	public static final String HOME_CHECK_BOX = "RSB";
	public static final String ADD_LINE_ONE = "RA1";
	public static final String ADD_LINE_TWO = "RA2";
	public static final String CITY = "RCTY";
	public static final String STATE = "RS";
	public static final String ZIP = "RZ";
	public static final String HOME_PHONE = "RHP";	
	public static final String DIAGNOSIS_DROPDOWN = "DIANAME";
	public static final String FUNCTIONAL_LIMITATIONS_ONE_NAME = "FL1Name";
	public static final String FUNCTIONAL_LIMITATIONS_ONE_VALUE = "FL1Value";
	public static final String FUNCTIONAL_LIMITATIONS_TWO_NAME = "FL2Name";
	public static final String FUNCTIONAL_LIMITATIONS_TWO_VALUE = "FL2Value";
	public static final String FUNCTIONAL_LIMITATIONS_THREE_NAME = "FL3Name";
	public static final String FUNCTIONAL_LIMITATIONS_THREE_VALUE = "FL3Value";
	public static final String FUNCTIONAL_LIMITATIONS_FOUR_NAME = "FL4Name";
	public static final String FUNCTIONAL_LIMITATIONS_FOUR_VALUE = "FL4Value";
	public static final String FUNCTIONAL_LIMITATIONS_FIVE_NAME = "FL5Name";
	public static final String FUNCTIONAL_LIMITATIONS_FIVE_VALUE = "FL5Value";
	public static final String FUNCTIONAL_LIMITATIONS_SIX_NAME = "FL6Name";
	public static final String FUNCTIONAL_LIMITATIONS_SIX_VALUE = "FL6Value";
	public static final String FUNCTIONAL_LIMITATIONS_SEVEN_NAME = "FL7Name";
	public static final String FUNCTIONAL_LIMITATIONS_SEVEN_VALUE = "FL7Value";
	public static final String ER_FIRSTNAME = "ERN";
	public static final String ER_TITLE = "ERT";
	public static final String ER_PHONE = "ERPHN";
	public static final String ER_EVALUATION_DROPDOWN = "ERTYPE";
	public static final String ER_REASON = "ERRSN";
	public static final String ER_DATEOFREPORT = "ERDOR";
	public static final String ER_COMMENTS = "ERCOM";
	public static final String ETIOLOGY_TYPE = "ETINA";
	public static final String DEMO_LANGUAGE_DROPDOWN = "DEMLAN"; 
	public static final String DEMO_ETHNICITY_DROPDOWN = "DEMETH";
	public static final String DEMO_TRIBE_DROPDOWN = "DEMTR"; 
	public static final String DEMO_INCONT_DROPDOWN = "DEMIN"; 
	public static final String DEMO_EMERGENCY_PLAN_DROPDOWN = "DEMEMER";
	public static final String DEMO_COMMENTS = "DEMCO";
	public static final String ELIGIWORKERDROPDOWN = "VMCWT";
	public static final String ELIGICLIENTDROPDOWN = "VMCC";	
}


