package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import dataProviders.ConfigFileReader;
import drivers.CRConstants;

public class ClientApplication_Page extends Base_Page {
	
	public WebDriver driver;
	
	@FindBy(xpath = CRConstants.CLIENT_APPLICATION) public WebElement CA;
	@FindBy(xpath = CRConstants.ADD_CONSUMER) public WebElement ADD_CONSUMER;
	@FindBy(xpath = CRConstants.LAST_NAME) public WebElement LAST_NAME;
	@FindBy(xpath = CRConstants.FIRST_NAME)public WebElement FIRST_NAME;
	@FindBy(xpath = CRConstants.GENDER)public WebElement GENDER;
	@FindBy(xpath = CRConstants.DATE_OF_BIRTH)public WebElement DATE_OF_BIRTH;
	@FindBy(xpath = CRConstants.CONTINUE)public WebElement CONTINUE;
	@FindBy(xpath = CRConstants.ADD_AND_CONTINUE)public WebElement ADD_AND_CONTINUE;
	@FindBy(xpath = CRConstants.POPUP) public WebElement POPUP;
		
	ConfigFileReader reader= new ConfigFileReader();
	
	public ClientApplication_Page(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}	
		
	public WebDriver addConsumersStep(String firstNameStr, String lastNameStr, String genderStr, String dobStr)  {
		
		//reader.getImplicitlyWait();
		threadWait();
		this.webEleClick(CA);
		this.windowSwitch();
		webEleClick(ADD_CONSUMER);
		sendWebElements(LAST_NAME, lastNameStr);
		sendWebElements(FIRST_NAME, firstNameStr);
		threadWait();
		selectByValue(GENDER, genderStr);
		waitVisibility(DATE_OF_BIRTH);
		sendWebElements(DATE_OF_BIRTH, dobStr);
		doubleClickEle(CONTINUE);
		javaScriptEleCLick(ADD_AND_CONTINUE);
		waitAlert();
		threadWait();
		waitClickable(POPUP);		
		
		return driver;
		
		
	}
	
}
