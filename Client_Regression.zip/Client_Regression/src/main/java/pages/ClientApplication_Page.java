package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import dataProviders.ConfigFileReader;
import drivers.CRConstants;

public class ClientApplication_Page extends Base_Page {
	
	public WebDriver driver;
	
	@FindBy(xpath = CRConstants.CLIENT_APPLICATION) WebElement CA;
	@FindBy(xpath = CRConstants.ADD_CONSUMER) WebElement ADD_CONSUMER;
	@FindBy(xpath = CRConstants.LAST_NAME) WebElement LAST_NAME;
	@FindBy(xpath = CRConstants.FIRST_NAME) WebElement FIRST_NAME;
	@FindBy(xpath = CRConstants.GENDER) WebElement GENDER;
	@FindBy(xpath = CRConstants.DATE_OF_BIRTH) WebElement DATE_OF_BIRTH;
	@FindBy(xpath = CRConstants.CONTINUE) WebElement CONTINUE;
	@FindBy(xpath = CRConstants.ADD_AND_CONTINUE) WebElement ADD_AND_CONTINUE;
	@FindBy(xpath = CRConstants.POPUP) WebElement POPUP;
	
	
	ConfigFileReader reader= new ConfigFileReader();
	
	public ClientApplication_Page(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
		
	public WebDriver addConsumersStep(String firstNameStr, String lastNameStr, String genderStr, String dobStr)  {
		
		//reader.getImplicitlyWait();
		this.threadWait();
		this.webEleClick(CA);
		this.windowSwitch();
		this.webEleClick(ADD_CONSUMER);
		this.sendWebElements(LAST_NAME, lastNameStr);
		this.sendWebElements(FIRST_NAME, firstNameStr);
		this.threadWait();
		this.selectByValue(GENDER, genderStr);
		this.waitVisibility(DATE_OF_BIRTH);
		this.sendWebElements(DATE_OF_BIRTH, dobStr);
		this.doubleClickEle(CONTINUE);
		this.javaScriptEleCLick(ADD_AND_CONTINUE);
		this.waitAlert();
		this.threadWait();
		this.waitClickable(POPUP);
		
		
		return driver;
		
		
	}
	
}
