package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import drivers.CRConstants;

public class ConsumerMainMenu_Page extends Base_Page {
	
	public WebDriver driver;
	
	By ConsumerMainMenuBy = By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	By DocumentedDisabilitiesBy = By.xpath(CRConstants.DOCUMENTED_DISABILITIES);
	By DisTypeDropDownBy = By.xpath(CRConstants.DISABILITIES_TYPE_DROPDOWN);
	By FunctionalLimitationsBy = By.xpath(CRConstants.FUNCTIONAL_LIMITATIONS);
	By FunctionalLimitationsRowsBy = By.xpath(CRConstants.FUNCTIONAL_LIMITATIONS_ROWS);
	By AssignToDiagnosisBy = By.xpath(CRConstants.ASSIGN_TO_DIAGNOSIS);
	By EvaluationReportBy = By.xpath(CRConstants.EVALUATION_REPORT);
	By ERFirstNameBy = By.xpath(CRConstants.ER_FIRSTNAME);
	By ERTitleBy = By.xpath(CRConstants.ER_TITLE);
	By EREvaluationDDBy = By.xpath(CRConstants.ER_EVALUATION_DROPDOWN);
	By ERDateReportBy = By.xpath(CRConstants.ER_DATEREPORT);
	By ERTodayBy = By.xpath(CRConstants.ER_TODAY);
	By ERSaveBy = By.xpath(CRConstants.ER_SAVE);
	By EtiologySelectBy = By.xpath(CRConstants.ETIOLOGY_SELECT);
	By EtiologyTypeBy = By.xpath(CRConstants.ETIOLOGY_TYPE);
	By EtiologyAssignBy = By.xpath(CRConstants.EIOLOGY_ASSIGN);
	By EtiologyFinalSaveBy = By.xpath(CRConstants.EIOLOGY_FINALSAVE);
	

	
	public ConsumerMainMenu_Page(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public void FLClick(String text, String FL1, String FL2, String FL3, String FLName) {
		
		if (text.equalsIgnoreCase(FLName) && FL1.equalsIgnoreCase(FLName)
				|| (text.equalsIgnoreCase(FLName) && FL2.equalsIgnoreCase(FLName))
				|| (text.equalsIgnoreCase(FLName) && FL3.equalsIgnoreCase(FLName))) {
			driver.findElement(By.xpath("//label[contains(text(),'" + FLName + "')]")).click();
		}
		
	}
	
	public void evaluationType(String typeOFEvaluationStr, String evaluationValue) {
		Select se = new Select(ER_TITLE_DROPDOWN);
		if (typeOFEvaluationStr.equalsIgnoreCase(evaluationValue)) {
			se.selectByValue(evaluationValue);}
	}
	
	public WebDriver consumer_Documented_Disabilities_Steps( String disabilityNameStr, String FL1Str, String FL2Str, String FL3Str) {
		
		this.webEleClick(ConsumerMainMenuBy);
		this.checkListEleValues(CONSUMER_MENU_LIST,"Documented Disabilities");
		this.selectByVisibleText(DISABILITIES_TYPE_DROPDOWN, disabilityNameStr);
		this.webEleClick(FunctionalLimitationsBy);
		
		List<WebElement> listofRows=this.ListEleReturn(FUNCTIONAL_LIMITATIONS_ROWS);
		for (WebElement list : listofRows) {
			this.FLClick(list.getText(),FL1Str,FL2Str, FL3Str,"Self-Care");
			this.FLClick(list.getText(),FL1Str,FL2Str, FL3Str,"Learning");
			this.FLClick(list.getText(),FL1Str,FL2Str, FL3Str,"Self-direction");
			this.FLClick(list.getText(),FL1Str,FL2Str, FL3Str,"Mobility");
			this.FLClick(list.getText(),FL1Str,FL2Str, FL3Str,"Economic Self-Sufficiency");
			this.FLClick(list.getText(),FL1Str,FL2Str, FL3Str,"Capacity for Independent Living");
			this.FLClick(list.getText(),FL1Str,FL2Str, FL3Str,"Receptive and Expressive Language");
		}
		
		this.webEleClick(AssignToDiagnosisBy);
		this.threadWait();
		
		return driver;
		
	}
	
	public WebDriver evaluation_Report_Steps(String ERFirstNameStr, String ERTitleStr, String typeOfEvaluationStr) {
		
		this.webEleClick(EvaluationReportBy);
		this.threadWait();
		this.sendWebElements(ERFirstNameBy, ERFirstNameStr);
		this.sendWebElements(ERTitleBy, ERTitleStr);
		this.threadWait();
		this.evaluationType(typeOfEvaluationStr,"Psychological or Psycho-educational");
		this.evaluationType(typeOfEvaluationStr,"Neurological");
		this.evaluationType(typeOfEvaluationStr,"Psychiatric");
		this.evaluationType(typeOfEvaluationStr,"Developmental");
		this.evaluationType(typeOfEvaluationStr,"Physician");
		
		Select se = new Select(ER_TITLE_DROPDOWN);
		 if (typeOfEvaluationStr.equalsIgnoreCase("Other (please specify)")) {
				se.selectByValue("0");}
		
		this.webEleClick(ERDateReportBy);
		this.webEleClick(ERTodayBy);
		this.webEleClick(ERSaveBy);
		
		return driver;
	}
	
	public WebDriver etiologySteps( String etiologyNameStr) {
		
		this.webEleClick(EtiologySelectBy);
		this.threadWait();
		
		String winHandleBefore = driver.getWindowHandle();
		for(String winHandle : driver.getWindowHandles()){
		    driver.switchTo().window(winHandle);
		}
		
		this.windowMaximize();
		this.threadWait();
		driver.findElement(By.xpath("//label[contains(text(),'"+ etiologyNameStr + "')]//parent::td/input")).click();
		this.threadWait();
		this.webEleClick(EtiologyAssignBy);
		driver.switchTo().window(winHandleBefore);
		this.threadWait();
		this.webEleClick(EtiologyFinalSaveBy);
		this.threadWait();
		this.webEleClick(ConsumerMainMenuBy);
		this.threadWait();
		
		return driver;
	}
}
