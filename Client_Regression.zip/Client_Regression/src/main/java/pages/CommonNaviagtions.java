package pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Constants.CRConstants;

public class CommonNaviagtions extends BasePage {

	public WebDriver driver;

	public CommonNaviagtions(WebDriver driver) {
		super(driver);
	}

	private By CATestEnvByXpath = By.xpath("//a[text()='CLIENT APPLICATION - TEST ENVIRONMENT']");
	private By globalNotificationsByXpath = By.xpath("//a[@aria-controls='TabPanel3']");
	private By tableClientIDsByXpath = By
			.xpath("//table[@id='ContentPrimary_ctrlGlobalNotifications_dgGlobalNotes']/tbody/tr/td[2]");
	private By notifySCByXpath = By.xpath("//input[@value='Notify SC']");
	private By correspondanceById = By.id("ddlCorrespondence");
	private By categoryById = By.id("ddlcategory");
	private By narrativeById = By.id("txtNotes");
	private By saveById = By.id("btnSave");

	By clientSearchBy = By.xpath(CRConstants.CLIENT_SEARCH);
	By clientNameDropBy = By.xpath(CRConstants.CLIENT_SEARCH_NAME_DROPDOWN);
	By clientAssistBy = By.xpath(CRConstants.CLIENT_SEARCH_ASSIST_ID);
	By clientSearchFinalBy = By.xpath(CRConstants.CLIENT_SEARCH_BUTTON);

	public void navToSaveClientDetails(Map<String, String> data) {
		String clientId = data.get("Client_ID").trim();
		String assistID = data.get("Assist_ID").trim();
		String correspondence = data.get("CORRESPONDENCE").trim();
		String category = data.get("CATEGORY").trim();
		String narrative = data.get("NARRATIVE").trim();

		waitForPageToLoad();
		javaScriptClick(CATestEnvByXpath);
		windowSwitch();
		waitForPageToLoad();
		javaScriptClick(globalNotificationsByXpath);
		clientIDSearch(clientId, true);
		closeCurrentWindow();
		clickOnClientIDDetails(assistID, clientId);
		windowSwitch();
		waitForPageToLoad();
		MaximizeWindow();
		waitForPageToLoad();
		javaScriptClick(notifySCByXpath);
		waitForPageToLoad();
		ArrayList<String> allWindows = new ArrayList<String>(getDriver().getWindowHandles());
		System.out.println(allWindows.size());
		getDriver().switchTo().window(allWindows.get(3));
		System.out.println(getDriver().getTitle());
		// windowSwitch();
		waitForPageToLoad();
		MaximizeWindow();
		waitForPageToLoad();

		selectByVisibleText(correspondanceById, correspondence);
		selectByVisibleText(categoryById, category);
		writeText(narrativeById, narrative);
		javaScriptClick(saveById);
		closeCurrentWindow();
		closeCurrentWindow();
		closeCurrentWindow();
		// getDriver().switchTo().window(allWindows.get(0));
		javaScriptClick(CATestEnvByXpath);
		windowSwitch();
		waitForPageToLoad();
		javaScriptClick(globalNotificationsByXpath);
		clientIDSearch(clientId, false);
	}

	private void clickOnClientIDDetails(String assistId, String clientId) {
		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(clientSearchBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(3);
		selectByVisibleText(clientNameDropBy, "Assists Id");
		writeText(clientAssistBy, assistId);
		javaScriptClick(clientSearchFinalBy);
		waitForPageToLoad();
		By viewDetailsByXpath = By.xpath("//td[text()='" + clientId + "']//ancestor::tr[2]/td[1]/img");
		javaScriptClick(viewDetailsByXpath);

	}

	private void clientIDSearch(String valueToSearch, boolean flag) {
		List<WebElement> clientIds = getElements(tableClientIDsByXpath);
		for (WebElement clientId : clientIds) {
			if (clientId.getText().trim().contains(valueToSearch)) {
				if (flag) {
					throw new RuntimeException(valueToSearch + " is found in global notification table");
				} else {
					System.out.println(valueToSearch + " is found in global notification table");
				}
				break;
			}

		}

	}
}
