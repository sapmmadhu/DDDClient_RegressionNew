package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import drivers.CRConstants;

public class ResponsibleParty_Page extends Base_Page{	
	public WebDriver driver;
	
	
	By ResFirstNameBy = By.xpath(CRConstants.RES_FIRST_NAME);
	By ResLastNameBy = By.xpath(CRConstants.RES_LAST_NAME);
	By ResCheckBoxListBy = By.xpath(CRConstants.CHECK_BOX_LIST);
	By ResHomeCheckBoxBy = By.xpath(CRConstants.HOME_CHECK_BOX);
	By ResAddLineOneBy = By.xpath(CRConstants.ADD_LINE_ONE);
	By ResAddLineTwoBy = By.xpath(CRConstants.ADD_LINE_TWO);
	By ResCityBy = By.xpath(CRConstants.CITY);
	By ResStateBy = By.xpath(CRConstants.STATE);
	By ResZipBy = By.xpath(CRConstants.ZIP);
	By ResHomePhoneBy = By.xpath(CRConstants.HOME_PHONE);
	By ResFooterScrollBy = By.xpath(CRConstants.FOOTER_SCROLL);
	By ResStartDateBy = By.xpath(CRConstants.START_DATE);
	By ResTodayDateBy = By.xpath(CRConstants.TODAY_DATE);
	By ResSaveBy = By.xpath(CRConstants.SAVE);
	By ResUseAsEntBy = By.xpath(CRConstants.USE_AS_ENTERED);
	By ResCloseBy = By.xpath(CRConstants.CLOSE);
    

	
	public ResponsibleParty_Page(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public WebDriver addRPStep(String RPFirstNameStr, String RPLastNameStr, String RPSelectBoxStr, 
			String RPAddlineoneStr, String RPAddlinetwoStr, String RPCityStr, String RPStateStr, String RPZipStr, String RPHomePhoneStr) {
		
		sendWebElements(ResFirstNameBy, RPFirstNameStr);
		this.sendWebElements(ResLastNameBy, RPLastNameStr);
		this.threadWait();
		sendWebElements(ResCheckBoxListBy, RPSelectBoxStr);
		this.threadWait();
		sendWebElements(ResAddLineOneBy, RPAddlineoneStr);
		sendWebElements(ResAddLineTwoBy, RPAddlinetwoStr);
		sendWebElements(ResCityBy, RPCityStr);
		sendWebElements(ResStateBy, RPStateStr);
		sendWebElements(ResZipBy, RPZipStr);
		sendWebElements(ResHomePhoneBy, RPHomePhoneStr);
		this.windowMaximize();
		this.threadWait();
		//sendWebElements(FOOTER_SCROLL);
		//this.javaScriptEleCLick(ResStartDateBy);
		//this.javaScriptEleCLick(ResTodayDateBy);
		this.threadWait();
		this.waitVisibility(ResSaveBy);
		this.threadWait();
		this.waitVisibility(ResUseAsEntBy);
		this.threadWait();
		this.webEleClick(ResCloseBy);
		
		return driver;
	}
}
