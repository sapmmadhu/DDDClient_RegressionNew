package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import drivers.CRConstants;

public class ResponsibleParty_Page extends Base_Page{
	
	public WebDriver driver;

	@FindBy(xpath = CRConstants.RES_FIRST_NAME) WebElement RES_FIRST_NAME;
	@FindBy(xpath = CRConstants.RES_LAST_NAME) WebElement RES_LAST_NAME;
	@FindBy(xpath = CRConstants.CHECK_BOX_LIST) WebElement LIST_CHECK_BOX;
	@FindBy(xpath = CRConstants.HOME_CHECK_BOX) WebElement HOME_CHECK_BOX;
	@FindBy(xpath = CRConstants.ADD_LINE_ONE) WebElement ADD_LINE_ONE;
	@FindBy(xpath = CRConstants.ADD_LINE_TWO) WebElement ADD_LINE_TWO;
	@FindBy(xpath = CRConstants.CITY) WebElement CITY;
	@FindBy(xpath = CRConstants.STATE) WebElement STATE;
	@FindBy(xpath = CRConstants.ZIP) WebElement ZIP;
	@FindBy(xpath = CRConstants.HOME_PHONE) WebElement HOME_PHONE;
	@FindBy(xpath = CRConstants.FOOTER_SCROLL) WebElement FOOTER_SCROLL;
	@FindBy(xpath = CRConstants.START_DATE) WebElement START_DATE;
	@FindBy(xpath = CRConstants.TODAY_DATE) WebElement TODAY_DATE;
	@FindBy(xpath = CRConstants.SAVE) WebElement SAVE;
	@FindBy(xpath = CRConstants.USE_AS_ENTERED) WebElement USE_AS_ENTERED;
	@FindBy(xpath = CRConstants.CLOSE) WebElement CLOSE;
	
	public ResponsibleParty_Page(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	
	public WebDriver addRPStep(String RPFirstNameStr, String RPLastNameStr, String RPSelectBoxStr, 
			String RPAddlineoneStr, String RPAddlinetwoStr, String RPCityStr, String RPStateStr, String RPZipStr, String RPHomePhoneStr) {
		
		this.sendWebElements(RES_FIRST_NAME, RPFirstNameStr);
		this.sendWebElements(RES_LAST_NAME, RPLastNameStr);
		this.threadWait();
		this.checkListEleValues(LIST_CHECK_BOX, RPSelectBoxStr);
		this.threadWait();
		this.sendWebElements(ADD_LINE_ONE, RPAddlineoneStr);
		this.sendWebElements(ADD_LINE_TWO, RPAddlinetwoStr);
		this.sendWebElements(CITY, RPCityStr);
		this.selectByValue(STATE, RPStateStr);
		this.sendWebElements(ZIP, RPZipStr);
		this.sendWebElements(HOME_PHONE, RPHomePhoneStr);
		this.windowMaximize();
		this.threadWait();
		this.webEleClick(FOOTER_SCROLL);
		this.javaScriptEleCLick(START_DATE);
		this.javaScriptEleCLick(TODAY_DATE);
		this.threadWait();
		this.waitVisibility(SAVE);
		this.threadWait();
		this.waitVisibility(USE_AS_ENTERED);
		this.threadWait();
		this.webEleClick(CLOSE);
		
		return driver;
	}
}
