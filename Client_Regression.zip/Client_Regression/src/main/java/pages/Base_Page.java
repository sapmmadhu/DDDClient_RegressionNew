package pages;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Base_Page {
	public WebDriver driver;
	public WebDriverWait wait;
	 

	// Constructor
	public Base_Page(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 30);
	}

	public void webEleClick(By weebEleBy) {
		driver.findElement(weebEleBy).click();
	}

	public WebElement webEleReturn(WebElement webElement) {
		return webElement;
	}
	
	public List<WebElement> ListEleReturn(List<WebElement> webElements) {
		return webElements ;
	}

	public void selectByVisibleText(WebElement webElement, String value) {
		Select select = new Select(webElement);
		select.selectByVisibleText(value);
	}
	
	public void selectByValue(WebElement webElement, String value) {
		Select select = new Select(webElement);
		select.selectByValue(value);
	}
	
	public void doubleClickEle(WebElement webElement) {
		Actions actions = new Actions(driver);
		actions.doubleClick(webElement).perform();
	}

	public boolean isDisplayed(WebElement webElement) {
		return webElement.isDisplayed();
	}

	public String getTextValue(WebElement webElement) {
		return webElement.getText();
	}

	public void threadWait() {
		
		try {
		Thread.sleep(6000);
		}catch(InterruptedException ie) {
			ie.getMessage();
		}
	}

	public void webEleTextClear(WebElement webElement) {
		webElement.clear();
	}

	public void sendWebElements( By webElemBy, String value) {
	driver.findElement( (By) webElemBy).sendKeys(value);
	}

	public void javaScriptEleCLick(WebElement ele) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].click();", ele);
	}

	public WebDriverWait driverWait(int waitInSeconds) {
		return new WebDriverWait(driver, waitInSeconds);
	}

	public boolean isAlertPresent() {
		boolean presentFlag = false;
		try {
			Alert alert = driver.switchTo().alert();
			presentFlag = true;
			alert.accept();
		} catch (NoAlertPresentException ex) {
			ex.printStackTrace();
		}
		return presentFlag;
	}

	public void waitAlert() {
		if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
			this.isAlertPresent();
		}

	}

	public void windowSwitch() {
		String currentHandle = driver.getWindowHandle();
		Set<String> handles = driver.getWindowHandles();
		for (String handle : handles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}
	}
	
	public void windowMaximize() {
		this.driver.manage().window().maximize();
	}

	// Wait Wrapper Method
	public void waitVisibility(By elementBy) {
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy((By) elementBy));
		webEleClick(elementBy);
	}
	
	public WebElement returnVisibilityEle(WebElement elementBy) {
		 return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath( "//textarea[@name='ctl00$ContentPrimary$txtDisabilityDescription']")));
		
	}

	public void waitClickable(WebElement elementBy) {
		wait.until(ExpectedConditions.elementToBeClickable(elementBy)).click();
	}

	// Click Method
	public void click(By elementBy) {
		waitVisibility(elementBy);
		driver.findElement(elementBy).click();
	}
	
	public void checkListEleValues(WebElement elementBy, String value) {
	
		List<WebElement> checkBoxes=this.ListEleReturn(driver.findElements((By) elementBy));
		for (WebElement boxes : checkBoxes) {
			String textValues=boxes.getText();
			if(textValues.contains(value) ) {
			boxes.click();
			break;
			}
			else throw new RuntimeException(value+" is not available in the list");}
			
		}
	
	public void moveToElementActions(WebElement elementBy) {
		Actions actions = new Actions(driver);
		actions.moveToElement(elementBy).click().build().perform();
	}
	
}
