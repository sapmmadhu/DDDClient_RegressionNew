package pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CRCommon {
	private static String assistId;
	private static String trackingNumber;
	private static String serviceCode;
	private static String statusFromTableService;
	
	public static String addDaysToDate(String date, String expectedDateFormat, int addDay) {

		DateFormat dateFormat = new SimpleDateFormat(expectedDateFormat);
		Calendar cal = Calendar.getInstance();
		try {
			cal.setTime(dateFormat.parse(date));
		} catch (Exception ex) {
			ex.getMessage();
		}
		cal.add(Calendar.DATE, addDay);
		String newDate = dateFormat.format(cal.getTime());

		return newDate;
	}

	public static String getStatusFromTableService() {
		return statusFromTableService;
	}

	public static void setStatusFromTableService(String statusFromTableService) {
		CRCommon.statusFromTableService = statusFromTableService;
	}

	public static String getAssistId() {
		return assistId;
	}

	public static void setAssistId(String assistId) {
		CRCommon.assistId = assistId;
	}

	public static String getTrackingNumber() {
		return trackingNumber;
	}

	public static void setTrackingNumber(String trackingNumber) {
		CRCommon.trackingNumber = trackingNumber;
	}

	public static String getServiceCode() {
		return serviceCode;
	}

	public static void setServiceCode(String serviceCode) {
		CRCommon.serviceCode = serviceCode;
	}
	
	

}
