package pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CRCommon {

	public static String addDaysToDate(String date, String expectedDateFormat, int addDay) {

		DateFormat dateFormat = new SimpleDateFormat(expectedDateFormat);
		Calendar cal = Calendar.getInstance();
		try {
			cal.setTime(dateFormat.parse(date));
		} catch (Exception ex) {
			ex.getMessage();
		}
		cal.add(Calendar.DATE, addDay);
		String newDate = dateFormat.format(cal.getTime());

		return newDate;
	}

}
