package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class LearnAssertionsSoft {
WebDriver driver;
     
//Object of Class SoftAssert is created to use its methods
SoftAssert softassert = new SoftAssert();
SoftAssert softassert2 = new SoftAssert();
     
//current project workspace
String path = System.getProperty("user.dir"); 
     
@BeforeTest
public void SetDriver(){
System.setProperty("webdriver.chrome.driver",path+"\\Drivers\\chromedriver.exe");
     
driver = new ChromeDriver();// Object is created - Chrome browser is opened
driver.manage().window().maximize();
}
     
//Soft Assertion example - with a failure test case example
@Test
public void verifyTitle(){
driver.get("http://dddfua1wt01.preprod.des:8080/organization/ddd/focusdd/frm_login.aspx ");
String ActualTitle = driver.getTitle();
System.out.println("Actual Title :"+ActualTitle);
String ExpectedTitle = "CLIENT APPLICATION - TEST ENVIRONMENT";
         
//Soft assert applied to verify title
softassert.assertEquals(ActualTitle, ExpectedTitle);
 
 
//If failed, this line gets printed and execution is not halted
//System.out.println("Assertion 1 is executed�);
 
softassert.assertAll();
 
}
 
//Soft Assertion example - with a positive flow test case example
@Test
public void verifyElement(){
//WebElement logo-img = driver.findElement(By.Xpath(�//div[contains(@id,�amazon_icon�)])";
//softassert2.assertEquals (true, AmazonIcon.isDisplayed());
softassert2.assertAll();
System.out.println("Icon is displayed");
//System.out.println("Assertion 2 is executed�);
 
}
     
     
@AfterTest
public void closedriver(){
driver.close();
//Checks for failures if any and throws them at the end of execution 
}
     
}