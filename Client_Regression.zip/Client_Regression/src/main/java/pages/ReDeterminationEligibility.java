package pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import Constants.CRConstants;
import Constants.CRConstants2;
import Constants.ExcelColumns;
import dataProviders.ConfigFileReader;

public class ReDeterminationEligibility extends BasePage {
  
	public static WebDriver browser;
	public WebDriver driver;
	ConfigFileReader reader = new ConfigFileReader();

	By consumerAdminBy = By.xpath(CRConstants.CONSUMER_ADMINISTRATION);
	By clientApplicationBy = By.xpath(CRConstants.CLIENT_APPLICATION);
	By viewMyConsumerBy = By.xpath(CRConstants.VIEW_MY_CONSUMERS);
	
	By workerDropBy = By.xpath(CRConstants.ELIGIWORKERDROPDOWN);
	By clientDropBy = By.xpath(CRConstants.ELIGICLIENTDROPDOWN);
	By myConsumerBy = By.xpath(CRConstants.ELIGIMYCONSUMERS);


	By clientSearchBy = By.xpath(CRConstants.CLIENT_SEARCH);
	By clientNameDropBy = By.xpath(CRConstants.CLIENT_SEARCH_NAME_DROPDOWN);
	By clientAssistBy = By.xpath(CRConstants.CLIENT_SEARCH_ASSIST_ID);
	By clientSearchFinalBy = By.xpath(CRConstants.CLIENT_SEARCH_BUTTON);

	By firstListBy = By.xpath("//span[text()='1']");
	By secondListBy = By.xpath("//a[text()='2']");

	By eligiStatusBy = By.xpath(CRConstants.ELIGISTATUS);
	By consumerMainMenuBy = By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	
	By redeterminationBy = By.xpath(CRConstants.REDETERMINATION);
	By redeterminationReasonBy = By.xpath(CRConstants.REDETERMINATIONREASON);
	By redeterminationNotesBy = By.xpath(CRConstants.REDETERMINATIONNOTES);
	By redeterminationSaveBy = By.xpath(CRConstants.REDETERMINATIONSAVE);
	
	By eliDeterRedeterBy = By.xpath(CRConstants.ELIGIDETERREDETER);
	By eliDeterRedeterYesBy = By.xpath(CRConstants.ELIGIYESBUTTON);
	By eliDeterRedeterSaveBy = By.xpath(CRConstants.ELIGIFINALSAVE);
	By eliDeterSuccessMsgBy = By.xpath(CRConstants.ELIGISUCCESSMSG);


	By supervisorServiceBy = By.xpath(CRConstants.SRVCAPPLINK);
	By serviceUnitsBy = By.xpath(CRConstants.SRVCEREQUUNITS);
	By serviceSaveBy = By.xpath(CRConstants.SRVCESAVE);
	
	
	private By serviceApprovalsById = By.id("lnkServiceApprovals");	
	private By serviceApprovedUnitsById = By.id("ContentPrimary_txtApprovedUnits");
	private By serviceAppSaveById = By.id("ContentPrimary_btnSave");
	
	//  Below variables are from Constants2 in order to finish Web2 end to end flow

	
	
	private Calendar data;

	public ReDeterminationEligibility(WebDriver driver) {
		super(driver);
	}
	
		
		public String getClientID(String assistId) {

			waitForPageToLoad();
			sleepTime(2);
			javaScriptClick(clientSearchBy);
			waitForPageToLoad();

			System.out.println(getDriver().getTitle());
			windowSwitch();
			sleepTime(3);
			selectByVisibleText(clientNameDropBy, "Assists Id");
			writeText(clientAssistBy, assistId);
			javaScriptClick(clientSearchFinalBy);
			waitForPageToLoad();
			String clientId = getElement(By.xpath("(//td[text()='" + assistId + "']//following::td)[1]")).getText();
			closeCurrentWindow();
			sleepTime(5);
			navigateToBack();
			sleepTime(5);
			navigateToBack();

			return clientId;
		}
	

	// The below is DDD Eligibility approval from SC Supervisor
	public void dddeligibilityApp_Steps() {
		// To Match consumer name below
		javaScriptClick(eliDeterRedeterYesBy);
		javaScriptClick(eliDeterRedeterSaveBy);
	}

	public WebDriver clickOn_Supervisor_CA(String clientId) {
		waitForPageToLoad();
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(2);
		javaScriptClick(consumerAdminBy);
		sleepTime(2);
		javaScriptClick(eliDeterRedeterBy);
		waitForPageToLoad();
		By clientIdBy = By.xpath("(//a[text()='" + clientId + "']//following::a)[1]");

		Boolean status = searchClientID(clientId, clientIdBy);
		if (!status) {
			javaScriptClick(secondListBy);
			waitForPageToLoad();
			searchClientID(clientId, clientIdBy);
		}	


		sleepTime(3);
		javaScriptClick(eliDeterRedeterYesBy);
		sleepTime(4);
		javaScriptClick(eliDeterRedeterSaveBy);
		String successMsgBy = getElement(eliDeterSuccessMsgBy).getText();
		System.out.println(successMsgBy);
		closeCurrentWindow();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		return getDriver();
	}
	
	

	public boolean searchClientID(String clientId, By clientIdBy) {
		boolean isFound = false;
		List<WebElement> rows = getElements(By.xpath("//table[@id=\"ContentPrimary_dbgEligibilityDates\"]/tbody/tr"));
		for (WebElement row : rows) {
			if (row.findElement(By.cssSelector("td:nth-of-type(1)")).getText().equals(clientId)) {
				isFound = true;
				javaScriptClick(clientIdBy);
				break;
			}
		}
		return isFound;
	}	
	
}
	
   
