package pages;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Constants.CRConstants;
import Constants.ExcelColumns;

import org.openqa.selenium.WebDriver;

public class AddNewService extends BasePage{
	public WebDriver driver;

	public AddNewService(WebDriver driver) {
		super(driver);
	}
	
	By addNewServiceBy = By.xpath(CRConstants.SRVCENEW);
	By addServiceDropDownBy = By.xpath(CRConstants.SRVCEDROPDOWN);
	By startDateBy = By.xpath(CRConstants.SRVCESTARTDATE);
	By endDateBy = By.xpath(CRConstants.SRVCEENDDATE);
	By reqUnitsBy = By.xpath(CRConstants.SRVCEREQUUNITS);
	By commentsBy = By.xpath(CRConstants.SRVCCOMMENTSNEW);
	By saveBy = By.xpath(CRConstants.SRVCESAVE);	


public AddNewService doNewServiceStep(Map<String, String> data) {
	String svNameStr = data.get("SVCENAME");
	String reqUnitsStr = data.get("SRVCEREQUUNITS");
	
	
	writeText(addServiceDropDownBy, svNameStr);	
	sleepTime(2);
	javaScriptClick(startDateBy);
	javaScriptClick(endDateBy);
	writeText(reqUnitsBy, reqUnitsStr);
	sleepTime(2);
	return this;
}



}