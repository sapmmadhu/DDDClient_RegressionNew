package pages;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Constants.CRConstants;
import Constants.ExcelColumns;

import org.openqa.selenium.WebDriver;

public class AddNewService extends BasePage {
	public WebDriver driver;

	public AddNewService(WebDriver driver) {
		super(driver);
	}

	By addNewServiceBy = By.xpath(CRConstants.SRVCENEW);
	By addServiceDropDownBy = By.xpath(CRConstants.SRVCEDROPDOWN);
	By ispStartDateBy = By.xpath(CRConstants.SRVCEISPSTARTDATE);
	By ispEndDateBy = By.xpath(CRConstants.SRVCEISPENDDATE);

	By startDateBy = By.xpath(CRConstants.SRVCESTARTDATE);
	By endDateBy = By.xpath(CRConstants.SRVCEENDDATE);
	By reqUnitsBy = By.xpath(CRConstants.SRVCEREQUUNITS);
	By commentsBy = By.xpath(CRConstants.SRVCCOMMENTSNEW);
	By saveBy = By.xpath(CRConstants.SRVCESAVE);
	By servcieApprovedBy = By.xpath(CRConstants.SRVCAPPROVED);

	By serviceApprovalBy = By.xpath(CRConstants.SRVCSUBMITAPPROVAL);
//	
	private By HcpcsCodeById = By.id("ContentPrimary_lblServiceCode");
	

	public WebDriver doNewServiceStep(Map<String, String> data) {
		String svNameStr = data.get("SVCENAME").trim();
		String reqUnitsStr = data.get("SRVCEREQUUNITS").trim();
		// String commentsStr = data.get("SRVCCOMMENTSNEW").trim();

		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(addNewServiceBy);
		waitForPageToLoad();
		sleepTime(2);
		selectByVisibleText(addServiceDropDownBy, svNameStr);
		waitForPageToLoad();
		String serviceCode =  getElement(HcpcsCodeById).getText();
		
		writeText(startDateBy, getElement(ispStartDateBy).getText());
		writeText(endDateBy, endDate());

		writeText(reqUnitsBy, reqUnitsStr);
		sleepTime(2);
		// writeText(commentsBy, commentsStr);
		// sleepTime(2);
		javaScriptClick(saveBy);
		waitForPageToLoad();
		sleepTime(2);
		By approvalsStausBy = By.xpath("//span[text()='"+serviceCode+"       ']//ancestor::tr//a[contains(.,'Submit for')]");
		javaScriptClick(approvalsStausBy);
		
		waitForPageToLoad();
		closeCurrentWindow();
		sleepTime(5);
		navigateToBack();
		sleepTime(5);
		navigateToBack();	
		
		//String approvedMsg = getElement(servcieApprovedBy).getText();
		//System.out.println("New Service Approval status :" + approvedMsg);

		return getDriver();
	}

	public String endDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		//System.out.println("Current Date: " + sdf.format(cal.getTime()));
		cal.add(Calendar.DAY_OF_MONTH, 30);
		String newDate = sdf.format(cal.getTime());
		//System.out.println("Date after Addition: " + newDate);
		return newDate;
	}
}