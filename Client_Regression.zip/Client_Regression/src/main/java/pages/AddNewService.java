package pages;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Constants.CRConstants;
import Constants.ExcelColumns;

import org.openqa.selenium.WebDriver;

public class AddNewService extends BasePage{
	public WebDriver driver;

	public AddNewService(WebDriver driver) {
		super(driver);
	}
	
	By addNewServiceBy = By.xpath(CRConstants.SRVCENEW);
	By addServiceDropDownBy = By.xpath(CRConstants.SRVCEDROPDOWN);
	By ispStartDateBy = By.xpath(CRConstants.SRVCEISPSTARTDATE);
	By ispEndDateBy = By.xpath(CRConstants.SRVCEISPENDDATE);
	
	By startDateBy = By.xpath(CRConstants.SRVCESTARTDATE);
	By endDateBy = By.xpath(CRConstants.SRVCEENDDATE);
	By reqUnitsBy = By.xpath(CRConstants.SRVCEREQUUNITS);
	By commentsBy = By.xpath(CRConstants.SRVCCOMMENTSNEW);
	By saveBy = By.xpath(CRConstants.SRVCESAVE);	
	By servcieApprovedBy = By.xpath(CRConstants.SRVCAPPROVED);
	
    By serviceApprovalBy = By.xpath(CRConstants.SRVCSUBMITAPPROVAL);

public WebDriver doNewServiceStep(Map<String, String> data) {
	String svNameStr = data.get("SVCENAME").trim();
	String reqUnitsStr = data.get("SRVCEREQUUNITS").trim();
	//String commentsStr = data.get("SRVCCOMMENTSNEW").trim();	
	
	waitForPageToLoad();
	sleepTime(2);
	javaScriptClick(addNewServiceBy);
	waitForPageToLoad();
	sleepTime(2);
	selectByVisibleText(addServiceDropDownBy, svNameStr);
	waitForPageToLoad();
	writeText(startDateBy, getElement(ispStartDateBy).getText());
	writeText(endDateBy, getElement(ispEndDateBy).getText());
	
	
	writeText(reqUnitsBy, reqUnitsStr);
	sleepTime(2);
	//writeText(commentsBy, commentsStr);
	//sleepTime(2);
	javaScriptClick(saveBy);
	waitForPageToLoad();
	String approvedMsg = getElement(servcieApprovedBy).getText();
	System.out.println("New Service Approval status :"+approvedMsg);
	
	
	return getDriver();
}
}