package pages;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Constants.CRConstants;
import Constants.CRConstants2;
import Constants.ExcelColumns;
import org.openqa.selenium.WebDriver;

public class SCApprovalFinalAuthPages extends BasePage {

	public WebDriver driver;

	public SCApprovalFinalAuthPages(WebDriver driver) {
		super(driver);
	}
	
	By consumerAdminBy = By.xpath(CRConstants.CONSUMER_ADMINISTRATION);
	By viewMyConsumerBy = By.xpath(CRConstants.VIEW_MY_CONSUMERS);
	By clientApplicationBy = By.xpath(CRConstants.CLIENT_APPLICATION);
	By workerDropBy = By.xpath(CRConstants.ELIGIWORKERDROPDOWN);
	By clientDropBy = By.xpath(CRConstants.ELIGICLIENTDROPDOWN);
	By myConsumerBy = By.xpath(CRConstants.ELIGIMYCONSUMERS);
	By eligiStatusBy = By.xpath(CRConstants.ELIGISTATUS);	
	By consumerMainMenuBy= By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	
	By viewPendingCallsBy = By.xpath(CRConstants2.SERVICE_PEDNING_CALLS);
	By serVendorResBy = By.xpath(CRConstants2.SERVICE_VENDOR_RESPPONSE);
	By serAcceptBy = By.xpath(CRConstants2.SERVICE_ACCEPT);
	By serContinueBy = By.xpath(CRConstants2.SERVICE_CONTINUE);
	By serOfficeBy = By.xpath(CRConstants2.SERVICE_OFFICE);
	By serAuthBy = By.xpath(CRConstants2.SERVICE_AUTHORIZE);
	
	
	
	public SCApprovalFinalAuthPages doSCApprovalFinalAuthPages(Map<String, String> data) {

		

		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(consumerAdminBy);
		waitForPageToLoad();
		javaScriptClick(viewMyConsumerBy);
		waitForPageToLoad();
		javaScriptClick(workerDropBy);
		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(clientDropBy);
		waitForPageToLoad();
		sleepTime(2);
		// scrollIntoView(workerGenderBy);
		javaScriptClick(myConsumerBy);
		//eligiStatusBy
		javaScriptClick(consumerMainMenuBy);
        sleepTime(2);
        javaScriptClick(viewPendingCallsBy);
        sleepTime(2);
        javaScriptClick(serVendorResBy);
        sleepTime(2);
        javaScriptClick(serAcceptBy);
        sleepTime(2);
        javaScriptClick(serContinueBy);
        sleepTime(2);
        javaScriptClick(serOfficeBy);
        sleepTime(2);
        javaScriptClick(serAuthBy);
       
		// Should take Vendor Call Tracking Number to match this number in Web2
		
    	return new SCApprovalFinalAuthPages(getDriver());
	}



	public WebDriver doSCApprovalFinalAuthPages(WebDriver driver2) {
		// TODO Auto-generated method stub
		return null;
	}

	}


