package pages;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Constants.CRConstants;
import Constants.ExcelColumns;
import org.openqa.selenium.WebDriver;

public class CreateAuthorization extends BasePage {

	public WebDriver driver;

	public CreateAuthorization(WebDriver driver) {
		super(driver);
	}

	By consumerMainMenuBy = By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	By venSelectionBy = By.xpath(CRConstants.VSAUTHNEW);
	By createAuthLinkBy = By.xpath(CRConstants.VSAUTHNEWLINK);
	By byPassVendorBy = By.xpath(CRConstants.VSBYPASS);

	By serviceStartBy = By.xpath(CRConstants.VSSERVICESTART);
	By serviceEndBy = By.xpath(CRConstants.VSSERVICEEND);

	By authStartDateBy = By.xpath(CRConstants.VSAUTHSTARTDATE);
	By authEndDateBy = By.xpath(CRConstants.VSAUTHENDDATE);
	By vendorNameBy = By.xpath(CRConstants.VSVENDORNAME);

	By searchBy = By.xpath(CRConstants.VSSEARCH);
	By vendorCheckboxBy = By.xpath(CRConstants.VSVENCHECKBOX);

	By venFooterScrollBy = By.xpath(CRConstants.VSFOOTER_SCROLL);
	By workerGenderBy = By.xpath(CRConstants.VSWORKERGENPRE);
	By specialNeedsBy = By.xpath(CRConstants.VSSPECIALNEEDS);
	By saveContinueBy = By.xpath(CRConstants.VSSAVECONT);

	By vsOfficeBy = By.xpath(CRConstants.VSOFFICESELECTION);
	By vsOfficeContBy = By.xpath(CRConstants.VSOFFICESAVECONT);

	By levelServiceBy = By.xpath(CRConstants.VSSERVICELEVEL);
	By hoursWeekBy = By.xpath(CRConstants.VSSERVICEHOURSPERWEEK);
	By selectDaysBy = By.xpath(CRConstants.VSSERVICESELECTDAYS);

	By startTimeBy = By.xpath(CRConstants.VSSERVICESTARTTIME);
	By endTimeBy = By.xpath(CRConstants.VSSERVICEENDTIME);

	By crossStreetsBy = By.xpath(CRConstants.VSSERVICECROSSST);
	By addDaysBy = By.xpath(CRConstants.VSSERVICEADD);

	By availableUnitsBy = By.xpath(CRConstants.VSAVAIUNITS);
	By requestedUnitsBy = By.xpath(CRConstants.VSSERVICEREQUNITS);
	By effecReqUnitsBy = By.xpath(CRConstants.VSSERVICEEFFREQUNITS);

	By finalSaveBy = By.xpath(CRConstants.VSSERVICEFINALSAVE);
	// By authorizeBy = By.xpath(CRConstants.VSSERVICEFINALAUTH);

	By sendBy = By.xpath(CRConstants.VSSERVICESEND);
	
	By consumerAdminBy = By.xpath(CRConstants.CONSUMER_ADMINISTRATION);
	By vendorQueueBy = By.xpath(CRConstants.VSVENDORQUEUE);
	By vsAssistIdBy = By.xpath(CRConstants.VSASSISTID);
	By vsAssistSearchBy = By.xpath(CRConstants.VSSEARCHASSISTID);

	By venPopopBy = By.xpath(CRConstants.VENOKPOPOP);
	By venDropBy = By.xpath(CRConstants.VENDROP);
	By ssnBy = By.xpath(CRConstants.CONSUMERSSN);

	By payeeStartDateCalBy = By.xpath(CRConstants.PAYEE_START_DATE_CAL);
	By payeeTodayDateBy = By.xpath(CRConstants.PAYEE_TODAY_DATE);

	By verifyStartDateBy = By.xpath(CRConstants.VSVERIFIEDSTARTDATE);
	By changeAuthBy = By.xpath(CRConstants.VSCHANGEAUTH);
	By viewHistoryBy = By.xpath(CRConstants.VSVERIFIEDVIEWHISTORY);

	public WebDriver doCreateAuthorizationStep(Map<String, String> data) {

		// String selectVendorStr = data.get("VENDOR");
		String workerGenderStr = data.get("WORKERGENDER");
		String specialNeedsStr = data.get("SPECIALNEEDS");

		String locationServiceStr = data.get("LOCATION");
		String hoursPerWeekStr = data.get("HOURS");
		String crossStreetsStr = data.get("CROSS");

		String AMorPMStart = data.get("AMorPMStart");
		String dateTimeHourStartStr = data.get("DATETIMEHOURStart");
		String dateTimeMinuteStartStr = data.get("DATETIMEMINUTEStart");

		String AMorPMEnd = data.get("AMorPMEnd");
		String dateTimeHourEndStr = data.get("DATETIMEHOUREnd");
		String dateTimeMinuteEndStr = data.get("DATETIMEMINUTEEnd");

		String ssnStr = data.get("CONSUMERSSN");
		String vsAssistIdString = data.get("Assist_ID");

		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(consumerMainMenuBy);
		waitForPageToLoad();
		javaScriptClick(venSelectionBy);
		waitForPageToLoad();
		javaScriptClick(createAuthLinkBy);
		waitForPageToLoad();
		sleepTime(2);

		writeText(authStartDateBy, getElement(serviceStartBy).getText());
		writeText(authEndDateBy, getElement(serviceEndBy).getText());

		javaScriptClick(searchBy);
		waitForPageToLoad();
		sleepTime(2);
		// scrollIntoView(workerGenderBy);
		javaScriptClick(venFooterScrollBy);
		selectByVisibleText(workerGenderBy, workerGenderStr);

		By specialBy = By.xpath("(//span[text()='" + specialNeedsStr.trim() + "']//ancestor::tr)[4]/td[1]/input");
		sleepTime(2);
		scrollIntoView(specialBy);
		sleepTime(2);
		boolean specialCheckBoxBoolean = getElement(specialBy).isSelected();
		if (!specialCheckBoxBoolean) {
			javaScriptClick(specialBy);
		}

//			scrollIntoView(specialBy);
//			doubleClick(specialBy);

		scrollIntoView(saveContinueBy);
		javaScriptClick(saveContinueBy);
		

		// Below is to select level, hours for few services- OEA, HAM  ( ATC will not show location, HAH will not show hours/week))
		//selectByVisibleText(levelServiceBy, locationServiceStr);
		//waitForPageToLoad();
		
		

		// boolean locationBoolean = getElement(levelServiceBy).isSelected();
		// if (!locationBoolean) {
		// javaScriptClick(levelServiceBy);
		// selectByVisibleText(levelServiceBy, locationServiceStr);
		// }
		
		

		sleepTime(3);
		writeText(hoursWeekBy, hoursPerWeekStr);

		/*
		 * By daysTableBy=By.xpath("(//table[@class='tblHabilitation'])[3]/tbody/tr");
		 * 
		 * List<WebElement> rows = getElements(daysTableBy); //td:nth-of-type(1) span
		 * >input:nth-child(2)
		 * 
		 * 
		 * for(WebElement row : rows){
		 * row.findElement(By.cssSelector("td:nth-of-type(1) span input")).click(); }
		 */

		// Sunday
		javaScriptClick(By.xpath("//input[@id='ContentPrimary_lvlservice_chkSunday']"));
		// Moday
		javaScriptClick(By.xpath("//input[@id='ContentPrimary_lvlservice_chkMonday']"));
		// Tuesday
		javaScriptClick(By.xpath("//input[@id='ContentPrimary_lvlservice_chkTuesday']"));
		// Wednesday
		javaScriptClick(By.xpath("//input[@id='ContentPrimary_lvlservice_chkWednesday']"));
		// Thursday
		javaScriptClick(By.xpath("//input[@id='ContentPrimary_lvlservice_chkThursday']"));
		// Friday
		javaScriptClick(By.xpath("//input[@id='ContentPrimary_lvlservice_chkFriday']"));
		// Saturday
		javaScriptClick(By.xpath("//input[@id='ContentPrimary_lvlservice_chkSaturday']"));

		// javaScriptClick(startTimeBy);
		writeText(startTimeBy, "1");
		sleepTime(2);
		selectDateTimeHour(2, AMorPMStart, dateTimeHourStartStr);
		selectDateTimeMinute(2, dateTimeMinuteStartStr);

		// javaScriptClick(endTimeBy);
		writeText(endTimeBy, "1");
		sleepTime(2);
		selectDateTimeHour(3, AMorPMEnd, dateTimeHourEndStr);
		selectDateTimeMinute(3, dateTimeMinuteEndStr);

		writeText(crossStreetsBy, crossStreetsStr);
		javaScriptClick(addDaysBy);
		waitForPageToLoad();
		sleepTime(2);

		scrollIntoView(availableUnitsBy);
		String availableUnits = getElement(availableUnitsBy).getText();
		scrollIntoView(requestedUnitsBy);
		writeText(requestedUnitsBy, availableUnits);
		sleepTime(3);
		keysEnter(requestedUnitsBy);
		sleepTime(2);

		javaScriptClick(finalSaveBy);
		sleepTime(2);

		javaScriptClick(sendBy);
		waitForPageToLoad();
		sleepTime(2);

		javaScriptClick(venPopopBy);
		waitForPageToLoad();
		// sleepTime(2);

		// isAlertPresent();
		// sleepTime(2);

		javaScriptClick(By.xpath("//div[text()='Select']"));
		sleepTime(2);
		javaScriptClick(By.xpath("//span[text()='A MINOR']"));
		sleepTime(2);

		// writeText(ssnBy, ssnStr);
		// sleepTime(2);
		// javaScriptClick(payeeStartDateCalBy);
		// sleepTime(2);
		// javaScriptClick(payeeTodayDateBy);

		waitForPageToLoad();
		// selectByVisibleText(venDropBy, "RESPONSIBLE PARTY");
		ResponsiblePartyPage rp = new ResponsiblePartyPage(getDriver());
		rp.vendorCallStep(data, 2);
		
		
		// Below is to click vendor call send button 2nd time, after filling additional consumer
		sleepTime(2);
		javaScriptClick(consumerMainMenuBy);
		waitForPageToLoad();
		javaScriptClick(venSelectionBy);
		waitForPageToLoad();
		javaScriptClick(createAuthLinkBy);
		waitForPageToLoad();
		sleepTime(2);
		scrollIntoView(saveContinueBy);
		javaScriptClick(saveContinueBy);
		sleepTime(2);
		scrollIntoView(finalSaveBy);
		javaScriptClick(finalSaveBy);
		sleepTime(2);
		scrollIntoView(sendBy);
		javaScriptClick(sendBy);
		waitForPageToLoad();
		sleepTime(2);
		
		// To see Assist ID stored in Vendor Queue
		javaScriptClick(consumerAdminBy);
		sleepTime(2);
		javaScriptClick(vendorQueueBy);
		sleepTime(2);
		writeText(vsAssistIdBy, vsAssistIdString);
		javaScriptClick(vsAssistSearchBy);
		
		// Should take Vendor Call Tracking Number to match this number in Web2
		
		return getDriver();
	}

	public void selectDateTimeHour(int index, String AMorPM, String dateTimeHourStr) {
		By dateTimeHourBy = By
				.xpath("(//div[@class='datetimepicker datetimepicker-dropdown-bottom-right dropdown-menu'])[" + index
						+ "]//div[@class='datetimepicker-hours']//legend[text()='" + AMorPM
						+ "']//parent::fieldset//span");
		List<WebElement> elements = getElements(dateTimeHourBy);
		for (WebElement ele : elements) {
			if (ele.getText().equalsIgnoreCase(dateTimeHourStr)) {
				javaScriptClick(ele);
				// ele.click();
				break;
			}
		}
	}

	public void selectDateTimeMinute(int index, String dateTimeMinuteStr) {
		By dateTimeMinutesBy = By
				.xpath("(//div[@class='datetimepicker datetimepicker-dropdown-bottom-right dropdown-menu'])[" + index
						+ "]//div[@class='datetimepicker-minutes']//span");
		List<WebElement> elements = getElements(dateTimeMinutesBy);
		for (WebElement ele : elements) {
			if (ele.getText().equalsIgnoreCase(dateTimeMinuteStr)) {
				javaScriptClick(ele);
				// ele.click();
				break;
			}
		}
	}

}
