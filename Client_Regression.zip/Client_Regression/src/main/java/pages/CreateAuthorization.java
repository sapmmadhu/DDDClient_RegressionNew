package pages;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Constants.CRConstants;
import Constants.ExcelColumns;
import org.openqa.selenium.WebDriver;

public class CreateAuthorization extends BasePage {

	public WebDriver driver;

	public CreateAuthorization(WebDriver driver) {
		super(driver);
	}
	
	By consumerMainMenuBy= By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	By venSelectionBy = By.xpath(CRConstants.VSAUTHNEW);
	By createAuthLinkBy = By.xpath(CRConstants.VSAUTHNEWLINK);
	By byPassVendorBy = By.xpath(CRConstants.VSBYPASS);
	
	
	By serviceStartBy = By.xpath(CRConstants.VSSERVICESTART);
	By serviceEndBy = By.xpath(CRConstants.VSSERVICEEND);
	
	
	By authStartDateBy = By.xpath(CRConstants.VSAUTHSTARTDATE);
	By authEndDateBy = By.xpath(CRConstants.VSAUTHENDDATE);
	By vendorNameBy = By.xpath(CRConstants.VSVENDORNAME);
	
	By searchBy = By.xpath(CRConstants.VSSEARCH);
	By vendorCheckboxBy = By.xpath(CRConstants.VSVENCHECKBOX);
	
	By workerGenderBy = By.xpath(CRConstants.VSWORKERGENPRE);
	By specialNeedsBy = By.xpath(CRConstants.VSSPECIALNEEDS);
	By saveContinueBy = By.xpath(CRConstants.VSSAVECONT);
	
	By vsOfficeBy = By.xpath(CRConstants.VSOFFICESELECTION);
	By vsOfficeContBy = By.xpath(CRConstants.VSOFFICESAVECONT);
	
	By levelServiceBy = By.xpath(CRConstants.VSSERVICELEVEL);
	By hoursWeekBy = By.xpath(CRConstants.VSSERVICEHOURSPERWEEK);
	By selectDaysBy = By.xpath(CRConstants.VSSERVICESELECTDAYS);
	
	By startTimeBy = By.xpath(CRConstants.VSSERVICESTARTTIME);
	By endTimeBy = By.xpath(CRConstants.VSSERVICEENDTIME);
	
	By crossStreetsBy = By.xpath(CRConstants.VSSERVICECROSSST);
	By addDaysBy = By.xpath(CRConstants.VSSERVICEADD);
	
	
	
	By availableUnitsBy = By.xpath(CRConstants.VSAVAIUNITS);
	By requestedUnitsBy = By.xpath(CRConstants.VSSERVICEREQUNITS);
	By effecReqUnitsBy = By.xpath(CRConstants.VSSERVICEEFFREQUNITS);
	
	By finalSaveBy = By.xpath(CRConstants.VSSERVICEFINALSAVE);
	//By authorizeBy = By.xpath(CRConstants.VSSERVICEFINALAUTH);
	
	
	
	By sendBy = By.xpath(CRConstants.VSSERVICESEND);
	
	
	By venDropBy = By.xpath(CRConstants.VENDROP);
	
	
	
	By verifyStartDateBy = By.xpath(CRConstants.VSVERIFIEDSTARTDATE);
	By changeAuthBy = By.xpath(CRConstants.VSCHANGEAUTH);
	By viewHistoryBy = By.xpath(CRConstants.VSVERIFIEDVIEWHISTORY);
	
	
	
	public WebDriver doCreateAuthorizationStep(Map<String, String> data) {
		
		//String selectVendorStr = data.get("VENDOR");
		String workerGenderStr = data.get("WORKERGENDER");
		String specialNeedsStr = data.get("SPECIALNEEDS");
	
		String locationServiceStr = data.get("LOCATION");
		String hoursPerWeekStr = data.get("HOURS");
		String crossStreetsStr = data.get("CROSS");
		
		
		String AMorPMStart = data.get("AMorPMStart");
		String dateTimeHourStartStr = data.get("DATETIMEHOURStart");
		String dateTimeMinuteStartStr = data.get("DATETIMEMINUTEStart");
		
		String AMorPMEnd = data.get("AMorPMEnd");
		String dateTimeHourEndStr = data.get("DATETIMEHOUREnd");
		String dateTimeMinuteEndStr = data.get("DATETIMEMINUTEEnd");


			
			waitForPageToLoad();
			sleepTime(2);
			javaScriptClick(consumerMainMenuBy);
			waitForPageToLoad();
			javaScriptClick(venSelectionBy);
			waitForPageToLoad();
			javaScriptClick(createAuthLinkBy);
			waitForPageToLoad();
			sleepTime(2);
			
			writeText(authStartDateBy, getElement(serviceStartBy).getText());
			writeText(authEndDateBy, getElement(serviceEndBy).getText());
					
	
			javaScriptClick(searchBy);
			waitForPageToLoad();
			sleepTime(2);
			scrollIntoView(workerGenderBy);
			
			selectByVisibleText(workerGenderBy, workerGenderStr);
			By specialBy=By.xpath("(//span[text()='"+specialNeedsStr+"']//ancestor::tr)[4]/td[1]");
			javaScriptClick(specialBy);
			
			
			scrollIntoView(saveContinueBy);
			javaScriptClick(saveContinueBy);
			
			
			selectByVisibleText(levelServiceBy, locationServiceStr);
			waitForPageToLoad();
			sleepTime(3);
			writeText(hoursWeekBy, hoursPerWeekStr);
			
			
			
			/*By daysTableBy=By.xpath("(//table[@class='tblHabilitation'])[3]/tbody/tr");
			
			List<WebElement> rows = getElements(daysTableBy);
			//td:nth-of-type(1) span >input:nth-child(2)
			
			
		    for(WebElement row : rows){
		    	row.findElement(By.cssSelector("td:nth-of-type(1) span input")).click();
		    		    			    }
			*/

		//Sunday
		javaScriptClick(By.xpath("//input[@id='ContentPrimary_lvlservice_chkSunday']"));
		//Moday
		javaScriptClick(By.xpath("//input[@id='ContentPrimary_lvlservice_chkMonday']"));
		//Tuesday
		javaScriptClick(By.xpath("//input[@id='ContentPrimary_lvlservice_chkTuesday']"));
		//Wednesday
		javaScriptClick(By.xpath("//input[@id='ContentPrimary_lvlservice_chkWednesday']"));
		//Thursday
		javaScriptClick(By.xpath("//input[@id='ContentPrimary_lvlservice_chkThursday']"));
		//Friday
		javaScriptClick(By.xpath("//input[@id='ContentPrimary_lvlservice_chkFriday']"));
		//Saturday
		javaScriptClick(By.xpath("//input[@id='ContentPrimary_lvlservice_chkSaturday']"));

		    
		    //javaScriptClick(startTimeBy);
		    writeText(startTimeBy, "1");
		    sleepTime(2);
		    selectDateTimeHour(2,AMorPMStart, dateTimeHourStartStr);
		    selectDateTimeMinute(2,dateTimeMinuteStartStr);
		    
		    //javaScriptClick(endTimeBy);
		    writeText(endTimeBy, "1");
		    sleepTime(2);
		    selectDateTimeHour(3,AMorPMEnd, dateTimeHourEndStr);
		    selectDateTimeMinute(3,dateTimeMinuteEndStr);
		  
		    writeText(crossStreetsBy, crossStreetsStr);
		    javaScriptClick(addDaysBy);
		    waitForPageToLoad();
		    sleepTime(2);
		    
		    scrollIntoView(availableUnitsBy);
		    String availableUnits = getElement(availableUnitsBy).getText();
		    scrollIntoView(requestedUnitsBy);
		    writeText(requestedUnitsBy, availableUnits);
		    sleepTime(3);
		    keysEnter(requestedUnitsBy);
		    sleepTime(2);
		    
		    javaScriptClick(finalSaveBy);
		    sleepTime(2);
		    
		    javaScriptClick(sendBy);
		    isAlertPresent();
		    sleepTime(2);
		    
		    selectByVisibleText(venDropBy, "RESPONSIBLE PARTY");
		    ResponsiblePartyPage rp= new ResponsiblePartyPage(getDriver());
		    rp.vendorCallStep(data);
		  
			return getDriver();
	}
	
	public void selectDateTimeHour(int index,String AMorPM, String dateTimeHourStr) {
		 By dateTimeHourBy = By.xpath("(//div[@class='datetimepicker datetimepicker-dropdown-bottom-right dropdown-menu'])["+index+"]//div[@class='datetimepicker-hours']//legend[text()='"+AMorPM+"']//parent::fieldset//span");		
		  List<WebElement> elements = getElements(dateTimeHourBy);
		  for(WebElement ele:elements) {
			  if(ele.getText().equalsIgnoreCase(dateTimeHourStr)) {
				  javaScriptClick(ele);
				 // ele.click();
				  break;
			  }
		  }
	}
	
	
	public void selectDateTimeMinute(int index,String dateTimeMinuteStr) {
		By dateTimeMinutesBy = By.xpath("(//div[@class='datetimepicker datetimepicker-dropdown-bottom-right dropdown-menu'])["+index+"]//div[@class='datetimepicker-minutes']//span");
		List<WebElement> elements = getElements(dateTimeMinutesBy);
		  for(WebElement ele:elements) {
			  if(ele.getText().equalsIgnoreCase(dateTimeMinuteStr)) {
				  javaScriptClick(ele);
					 // ele.click();
				  break;
			  }
		  }
	}
	
}
	