package pages;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Constants.CRConstants;
import Constants.ExcelColumns;
import org.openqa.selenium.WebDriver;

public class CreateAuthorization extends BasePage {

	public WebDriver driver;

	public CreateAuthorization(WebDriver driver) {
		super(driver);
	}
	
	By consumerMainMenuBy= By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	By venSelectionBy = By.xpath(CRConstants.VSAUTHNEW);
	By createAuthLinkBy = By.xpath(CRConstants.VSAUTHNEWLINK);
	By byPassVendorBy = By.xpath(CRConstants.VSBYPASS);
	By authStartDateBy = By.xpath(CRConstants.VSAUTHSTARTDATE);
	By authEndDateBy = By.xpath(CRConstants.VSAUTHENDDATE);
	By vendorNameBy = By.xpath(CRConstants.VSVENDORNAME);
	
	By searchBy = By.xpath(CRConstants.VSSEARCH);
	By vendorCheckboxBy = By.xpath(CRConstants.VSVENCHECKBOX);
	
	By workerGenderBy = By.xpath(CRConstants.VSWORKERGENPRE);
	By specialNeedsBy = By.xpath(CRConstants.VSSPECIALNEEDS);
	By saveContinueBy = By.xpath(CRConstants.VSSAVECONT);
	
	By vsOfficeBy = By.xpath(CRConstants.VSOFFICESELECTION);
	By vsOfficeContBy = By.xpath(CRConstants.VSOFFICESAVECONT);
	
	By levelServiceBy = By.xpath(CRConstants.VSSERVICELEVEL);
	By hoursWeekBy = By.xpath(CRConstants.VSSERVICEHOURSPERWEEK);
	By selectDaysBy = By.xpath(CRConstants.VSSERVICESELECTDAYS);
	
	By startTimeBy = By.xpath(CRConstants.VSSERVICESTARTTIME);
	By endTimeBy = By.xpath(CRConstants.VSSERVICEENDTIME);
	
	By crossStreetsBy = By.xpath(CRConstants.VSSERVICECROSSST);
	By selectAddDaysBy = By.xpath(CRConstants.VSSERVICEADD);
	By requestedUnitsBy = By.xpath(CRConstants.VSSERVICEREQUNITS);
	
	By saveUnitsAllocaBy = By.xpath(CRConstants.VSSERVICEFINALSAVE);
	By authorizeBy = By.xpath(CRConstants.VSSERVICEFINALAUTH);
	
	By verifyStartDateBy = By.xpath(CRConstants.VSVERIFIEDSTARTDATE);
	By changeAuthBy = By.xpath(CRConstants.VSCHANGEAUTH);
	By viewHistoryBy = By.xpath(CRConstants.VSVERIFIEDVIEWHISTORY);
	
	
	
	public WebDriver doCreateAuthorizationStep(Map<String, String> data) {
		
		String selectVendorStr = data.get("VENDOR");
		String workerGenderStr = data.get("WORKERGENDER");
		String specialNeedsStr = data.get("SPECIALNEEDS");
		String officeSelectionStr = data.get("OFFICE");
		String locationServiceStr = data.get("LOCATION");
		String hoursPerWeekStr = data.get("HOURS");
		String crossStreetsStr = data.get("CROSS");
		String reqUnitsStr = data.get("UNITS");
		

			
			waitForPageToLoad();
			sleepTime(2);
			javaScriptClick(consumerMainMenuBy);
			waitForPageToLoad();
			javaScriptClick(venSelectionBy);
			javaScriptClick(createAuthLinkBy);
			waitForPageToLoad();
			sleepTime(2);
			javaScriptClick(byPassVendorBy);
			javaScriptClick(authStartDateBy);
			javaScriptClick(authEndDateBy);
			writeText(vendorNameBy, selectVendorStr);
			javaScriptClick(searchBy);
			javaScriptClick(vendorCheckboxBy);
			sleepTime(2);
			selectByVisibleText(workerGenderBy, workerGenderStr);
			selectByVisibleText(specialNeedsBy, specialNeedsStr);
			javaScriptClick(saveContinueBy);
			writeText(vsOfficeBy, officeSelectionStr);
			javaScriptClick(vsOfficeContBy);
			selectByVisibleText(levelServiceBy, locationServiceStr);
			writeText(hoursWeekBy, hoursPerWeekStr);
			
			javaScriptClick(selectDaysBy);
			sleepTime(2);
			
			javaScriptClick(startTimeBy);
			javaScriptClick(endTimeBy);
			
			
			writeText(crossStreetsBy, crossStreetsStr);
			
			javaScriptClick(selectAddDaysBy);
			
		
			writeText(requestedUnitsBy, reqUnitsStr);
			
			javaScriptClick(saveUnitsAllocaBy);
			
			sleepTime(2);
			
			javaScriptClick(authorizeBy);
			waitForPageToLoad();
			sleepTime(3);
			
			javaScriptClick(verifyStartDateBy);
			closeCurrentWindow();
			sleepTime(2);
			javaScriptClick(changeAuthBy);
			closeCurrentWindow();
			sleepTime(2);
			
						
			
			return getDriver();
	}
	
}
	
