package pages;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Constants.CRConstants;
import Constants.ExcelColumns;
import org.openqa.selenium.WebDriver;

public class CreateAuthorization extends BasePage {

	public WebDriver driver;

	public CreateAuthorization(WebDriver driver) {
		super(driver);
	}
	
	By consumerMainMenuBy= By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	By ispServicePlanBy = By.xpath(CRConstants.ISPSERVICE);
	By venSelectionBy = By.xpath(CRConstants.VSAUTHNEW);
	By createAuthLinkBy = By.xpath(CRConstants.VSAUTHNEWLINK);
	By byPassVendorBy = By.xpath(CRConstants.VSBYPASS);
	By authStartDateBy = By.xpath(CRConstants.VSAUTHSTARTDATE);
	By authEndDateBy = By.xpath(CRConstants.VSAUTHENDDATE);
	By searchBy = By.xpath(CRConstants.VSSEARCH);
	// Select "A Brighter Avenue, L.L.C." from Search results
	By workerGenderBy = By.xpath(CRConstants.VSWORKERGENPRE);
	By specialNeedsBy = By.xpath(CRConstants.VSSPECIALNEEDS);
	By saveContinueBy = By.xpath(CRConstants.VSSAVECONT);
	By vsOfficeBy = By.xpath(CRConstants.VSOFFICESELECTION);
	By vsOfficeContBy = By.xpath(CRConstants.VSOFFICESAVECONT);
	By levelServiceBy = By.xpath(CRConstants.VSSERVICELEVEL);
	By hoursWeekBy = By.xpath(CRConstants.VSSERVICEHOURSPERWEEK);
	By selectDaysBy = By.xpath(CRConstants.VSSERVICESELECTDAYS);
	By startTimeBy = By.xpath(CRConstants.VSSERVICESTARTTIME);
	By endTimeBy = By.xpath(CRConstants.VSSERVICEENDTIME);
	By crossStreetsBy = By.xpath(CRConstants.VSSERVICECROSSST);
	By selectAddDaysBy = By.xpath(CRConstants.VSSERVICEADD);
	By requestedUnitsBy = By.xpath(CRConstants.VSSERVICEREQUNITS);
	By saveUnitsAllocaBy = By.xpath(CRConstants.VSSERVICEFINALSAVE);
	By authorizeBy = By.xpath(CRConstants.VSSERVICEFINALAUTH);
	
	
	
	public CreateAuthorization doCreateAuthorizationStep(Map<String, String> data) {
		String selectVendorStr = data.get("VENDOR");
		String workerGenderStr = data.get("WORGENDER");
		String specialNeedsStr = data.get("SPECIALNEEDS");
		String officeSelectionStr = data.get("OFFICE");
		String locationServiceStr = data.get("LOCATION");
		String hoursPerWeekStr = data.get("HOURS");
		String crossStreetsStr = data.get("CROSS");
		String reqUnitsStr = data.get("UNITS");
		
		
			return this;
	}
	
}
	
