package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;
import Constants.CRConstants2;

public class VendorApprovalDeniedFinalAcknoledge extends BasePage {

	public WebDriver driver;

	public VendorApprovalDeniedFinalAcknoledge(WebDriver driver) {
		super(driver);
	}
	
	By consumerAdminBy = By.xpath(CRConstants.CONSUMER_ADMINISTRATION);

	By svcAuthlinkBy = By.xpath(CRConstants2.SERVICE_AUTHLINK);
	By svcNotiBy = By.xpath(CRConstants2.SERVICE_NOTIFICATIONS);
	By svcDDDBy = By.xpath(CRConstants2.SERVICE_DDD);
	By svcDropDownBy = By.xpath(CRConstants2.SERVICE_DROPDOWN);
	By svcSearchBy = By.xpath(CRConstants2.SERVICE_SEARCH);
	By svcViewDetailsBy = By.xpath(CRConstants2.SERVICE_VIEWDETAILS);
	By svcYesBy = By.xpath(CRConstants2.SERVICE_YES);
	By svcVenLevelBy = By.xpath(CRConstants2.SERVICE_VENDORLEVEL);
	By svcOfficeLevelBy = By.xpath(CRConstants2.SERVICE_OFFICELEVEL);
	By svcVendorEndDateBy = By.xpath(CRConstants2.SERVICE_VENDOR_CLOSE_DATE);
	By svcEstimateDateBy = By.xpath(CRConstants2.SERVICE_ESTIMATED_START);
	By svcSubmitBy = By.xpath(CRConstants2.SERVICE_SUBMIT);
	By svcMainMenuBy = By.xpath(CRConstants2.SERVICE_MAINMENU);
	By svcPendingBy = By.xpath(CRConstants2.SERVICE_PENDING_NOTI);
	By svcDetails2By = By.xpath(CRConstants2.SERVICE_VIEWDETAILS2);
	By svcReturnBy = By.xpath(CRConstants2.SERVICE_RETURN);

	By venSelectionBy = By.xpath(CRConstants.VSAUTHNEW);

	// Below is to find another way to consumer details from Consumer admin -> Vendor call queue with the help of Tracking number
	By scVendorCallQueue = By.xpath(CRConstants2.SC_CONS_VENDOR_CALLQUEUE);
	By scConsAssistId = By.xpath(CRConstants2.SC_CONS_ASSIST_ID);
	By scConsSearch = By.xpath(CRConstants2.SC_CONS_SEARCH);

	By svcDeclineBy = By.xpath(CRConstants2.SERVICE_DECLINE);

	By viewPendingCallsBy = By.xpath(CRConstants2.SERVICE_PEDNING_CALLS);
	By serVendorResBy = By.xpath(CRConstants2.SERVICE_VENDOR_RESPPONSE);
	By serAcceptBy = By.xpath(CRConstants2.SERVICE_ACCEPT);
	By serContinueBy = By.xpath(CRConstants2.SERVICE_CONTINUE);
	By serOfficeBy = By.xpath(CRConstants2.SERVICE_OFFICE);
	By serAuthBy = By.xpath(CRConstants2.SERVICE_AUTHORIZE);

	By serAcknowledAuth = By.xpath(CRConstants2.SERVICE_ACKNAUTH);
	By serCheckBoxBy = By.xpath(CRConstants2.SERVICE_CHECKBOX);
	By serAcknowBy = By.xpath(CRConstants2.SERVICE_ACKNOWLEDGE);
	By serFinalAuthBy = By.xpath(CRConstants2.SERVICE_FINALAUTHS);
	By serTrackingBy = By.xpath(CRConstants2.SERVICE_TRACKINGID);
	By serAuthSearchBy = By.xpath(CRConstants2.SERVICE_AUTHSEARCH);
	By serReturnFinalBy = By.xpath(CRConstants2.SERVICE_RETURN_FINAL);

	By serDeclineAuthBy = By.xpath(CRConstants2.SERVICE_DECLINE);
	By serDeclineReasonDropDownBy = By.xpath(CRConstants2.SERVICE_DECLINE_DROPDOWN);
	By serDeclineSubmitBy = By.xpath(CRConstants2.SERVICE_DECLINE_SUBMIT);

	// By.xpath(".//option[normalize-space(.) = " + escapeQuotes(text) + "]")
	// By.xpath('//path/to/select//option[contains(., "Partial text")]')

	// This is Vendor initial "Approve Service" request in Web2 environment
	public WebDriver doVendorApprovalStep(Map<String, String> data) {

		String serviceStr = data.get("SERVICETYPE").trim();

		sleepTime(2);
		javaScriptClick(svcAuthlinkBy);
		sleepTime(2);
		windowSwitch();
		waitForPageToLoad();
		javaScriptClick(svcNotiBy);
		sleepTime(2);
		javaScriptClick(svcDDDBy);
		sleepTime(2);
		javaScriptClick(svcDropDownBy);
		javaScriptClick(By.xpath("//option[contains(., '" + serviceStr + "')]"));

		sleepTime(2);
		javaScriptClick(svcSearchBy);
		sleepTime(2);
		CreateAuthorization createAuthorization = new CreateAuthorization(getDriver());

		// Also take "Vendor Call end date" (This will need to click on Calendar . Click
		// on "View details" hyperlink
		By viewDetailsBy = By.xpath(
				"(//td[text()='" + createAuthorization.getTrackingNumberFromAssistID(data) + "']//parent::tr//td)[2]");
		javaScriptClick(viewDetailsBy);
		sleepTime(2);

		javaScriptClick(svcYesBy);
		waitForPageToLoad();

		javaScriptClick(svcOfficeLevelBy);
		sleepTime(2);

		String svcVendorEndDate = getElement(svcVendorEndDateBy).getText();
		String svcEstimatedDate = CRCommon.addDaysToDate(svcVendorEndDate, "MM/dd/yyyy", 1);
		getElement(svcEstimateDateBy).clear();
		writeText(svcEstimateDateBy, svcEstimatedDate);

		javaScriptClick(svcSubmitBy);
		sleepTime(2);
		closeCurrentWindow();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();

		return getDriver();
	}

	// (//a[text()='202013124167']//parent::td//parent::tr//td)[2]

	public WebDriver getVendorResponseStatus(Map<String, String> data) {
		CreateAuthorization createAuthorization = new CreateAuthorization(getDriver());
		createAuthorization.clickOnVendorRespAssitID(data);
		String trackingNumber = createAuthorization.getTrackingNumberFromAssistID(data);
		By vendorResponses = By.xpath("(//a[text()='" + trackingNumber + "']//parent::td//parent::tr//td)[2]");
		if (getElement(vendorResponses).getText() == "1") {
			javaScriptClick(By.xpath("//a[text()='" + trackingNumber + "']"));
			javaScriptClick(serVendorResBy);
			sleepTime(2);
			javaScriptClick(serAcceptBy);
			sleepTime(2);
			javaScriptClick(serContinueBy);
			sleepTime(2);
			javaScriptClick(serOfficeBy);
			sleepTime(2);
			javaScriptClick(serAuthBy);
			closeCurrentWindow();
			waitForPageToLoad();
			navigateToBack();
			waitForPageToLoad();
			navigateToBack();
			waitForPageToLoad();

		} else {
			throw new RuntimeException("We don't find any vendor responses related to " + trackingNumber);
		}
		return getDriver();

	}


	// ************************************************************************************************************ //
	

//This is for "Vendor responses and authorization"  from Support CoOrdinator login - Web1
	public WebDriver doSCApprovalFinalAuthPages(Map<String, String> data) {
	
		CreateAuthorization createAuthorization = new CreateAuthorization(getDriver());
		createAuthorization.clickOnVendorRespAssitID(data);
		String trackingNumber = createAuthorization.getTrackingNumberFromAssistID(data);

javaScriptClick(consumerAdminBy);
waitForPageToLoad();	
javaScriptClick(scVendorCallQueue);
sleepTime(2);
writeText(scConsAssistId, trackingNumber);
sleepTime(2);
javaScriptClick(scConsSearch);
sleepTime(2);		
//Match tracking number and then click on "Vendor Responses" hyperlink
javaScriptClick(serVendorResBy);
sleepTime(2);
javaScriptClick(serAcceptBy);
sleepTime(2);
// Take Vendor name and this will be useful to match vendor/ office name before click on authorize
javaScriptClick(serContinueBy);
sleepTime(2);
javaScriptClick(serOfficeBy); // Click radio button by matching Office/ Site location from previous screen - Vendor name
sleepTime(2);
javaScriptClick(serAuthBy);


// Should take Vendor Call Tracking Number to match this number in Web2 actions - Vendor final auth/ acknowledge
 
return getDriver();	
}
	
	

	
// This is for vendor's "Final acknowledgement and Authorization" request in Web2
	
	
//		public WebDriver doVendorFinalAcknoAuthStep(Map<String, String> data) {
	
	//CreateAuthorization createAuthorization = new CreateAuthorization(getDriver());
	//createAuthorization.clickOnVendorRespAssitID(data);
	//String trackingNumber = createAuthorization.getTrackingNumberFromAssistID(data);
	//
//			waitForPageToLoad();
//			sleepTime(2);
//			javaScriptClick(serAcknowledAuth);
//			sleepTime(2);
//			// Match tracking number from Web1 (SC authorized) and then click on check box
//			javaScriptClick(serCheckBoxBy);
//			sleepTime(2);
//			javaScriptClick(serAcknowBy);
//			sleepTime(2);
//			javaScriptClick(serFinalAuthBy);
//			sleepTime(2);
//			// Fill tracking number in "Vendor Call Tracking ID" field
//			sleepTime(2);
//			javaScriptClick(serAuthSearchBy);
//			sleepTime(2);
//			
//			// Click on ConsumerName from right side search result and match Assist ID, Tracking number, Focus ID then print into console and test data sheet
//	        		
//			sleepTime(2);
//			javaScriptClick(serReturnFinalBy);
//			sleepTime(2);
//			return getDriver();		
//			// This is the line where end to end flow is completed for both Web1 and Web2 and close the browsers
//			
//		}
}




// This is Vendor "Deny request" in Web2 by matching Tracking number OR Assist ID
//public WebDriver doVendorDeclinedStep(Map<String, String> data) {

//CreateAuthorization createAuthorization = new CreateAuthorization(getDriver());
//createAuthorization.clickOnVendorRespAssitID(data);
//String trackingNumber = createAuthorization.getTrackingNumberFromAssistID(data);

//	String serviceStr = data.get("SERVICETYPE").trim();
//	String declineReasonStr = data.get("DECLINEDREASON").trim();
//	
//	waitForPageToLoad();
//	click(loginBy);
//	sleepTime(2);
//	javaScriptClick(svcAuthlinkBy);
//	sleepTime(2);
//	javaScriptClick(svcNotiBy);
//	sleepTime(2);
//	javaScriptClick(svcDDDBy);
//	sleepTime(2);
//	selectByValue(svcDropDownBy, serviceStr);
//	sleepTime(2);
//	javaScriptClick(svcSearchBy);
//	sleepTime(2);
//	Match tracking number in this page and click on "View details"
//	javaScriptClick(svcViewDetailsBy);
//	sleepTime(2);
//	javaScriptClick(serDeclineAuthBy);
//	sleepTime(2);
//	// Here to select drop down value
//	selectByValue(serDeclineReasonDropDownBy, declineReasonStr);
//	javaScriptClick(serDeclineSubmitBy);
//
//	return getDriver();
//}
//



