package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;
import Constants.CRConstants2;

public class VendorApprovalDeniedFinalAcknoledge extends BasePage {

	public WebDriver driver;

	public VendorApprovalDeniedFinalAcknoledge(WebDriver driver) {
		super(driver);
	}

	By consumerAdminBy = By.xpath(CRConstants.CONSUMER_ADMINISTRATION);
	By scloginClientBy = By.xpath(CRConstants2.SCLOGINCLIENTLINK);

	By scTrackingSearchBy = By.xpath(CRConstants2.SCTRACKINGNUMBERSEARCH);
	By vsAssistSearchBy = By.xpath(CRConstants.VSSEARCHASSISTID);
	By svcAuthlinkBy = By.xpath(CRConstants2.SERVICE_AUTHLINK);
	By svcNotiBy = By.xpath(CRConstants2.SERVICE_NOTIFICATIONS);
	By svcDDDBy = By.xpath(CRConstants2.SERVICE_DDD);
	By svcDropDownBy = By.xpath(CRConstants2.SERVICE_DROPDOWN);
	By svcSearchBy = By.xpath(CRConstants2.SERVICE_SEARCH);
	By svcViewDetailsBy = By.xpath(CRConstants2.SERVICE_VIEWDETAILS);
	By svcYesBy = By.xpath(CRConstants2.SERVICE_YES);
	By svcVenLevelBy = By.xpath(CRConstants2.SERVICE_VENDORLEVEL);
	By svcOfficeLevelBy = By.xpath(CRConstants2.SERVICE_OFFICELEVEL);
	By svcVendorEndDateBy = By.xpath(CRConstants2.SERVICE_VENDOR_CLOSE_DATE);
	By svcEstimateDateBy = By.xpath(CRConstants2.SERVICE_ESTIMATED_START);
	By svcSubmitBy = By.xpath(CRConstants2.SERVICE_SUBMIT);
	By svcMainMenuBy = By.xpath(CRConstants2.SERVICE_MAINMENU);
	By svcPendingBy = By.xpath(CRConstants2.SERVICE_PENDING_NOTI);
	By svcDetails2By = By.xpath(CRConstants2.SERVICE_VIEWDETAILS2);
	By svcReturnBy = By.xpath(CRConstants2.SERVICE_RETURN);

	By venSelectionBy = By.xpath(CRConstants.VSAUTHNEW);

	// Below is to find another way to consumer details from Consumer admin ->
	// Vendor call queue with the help of Tracking number
	By scVendorCallQueue = By.xpath(CRConstants2.SC_CONS_VENDOR_CALLQUEUE);
	By scConsAssistId = By.xpath(CRConstants2.SC_CONS_ASSIST_ID);
	By scConsSearch = By.xpath(CRConstants2.SC_CONS_SEARCH);

	By svcDeclineBy = By.xpath(CRConstants2.SERVICE_DECLINE);

	By viewPendingCallsBy = By.xpath(CRConstants2.SERVICE_PEDNING_CALLS);
	By serVendorResBy = By.xpath(CRConstants2.SERVICE_VENDOR_RESPPONSE);
	By serAcceptBy = By.xpath(CRConstants2.SERVICE_ACCEPT);
	By serContinueBy = By.xpath(CRConstants2.SERVICE_CONTINUE);
	By serOfficeBy = By.xpath(CRConstants2.SERVICE_OFFICE);
	By serAuthBy = By.xpath(CRConstants2.SERVICE_AUTHORIZE);

	By serMainLink = By.xpath(CRConstants2.SERVICE_AUTHLINK);
	By serAcknowledAuth = By.xpath(CRConstants2.SERVICE_ACKNAUTH);
	By serCheckBoxBy = By.xpath(CRConstants2.SERVICE_CHECKBOX);
	By serAcknowBy = By.xpath(CRConstants2.SERVICE_ACKNOWLEDGE);
	By serFinalAuthBy = By.xpath(CRConstants2.SERVICE_FINALAUTHS);
	By serTrackingBy = By.xpath(CRConstants2.SERVICE_TRACKINGID);
	By serAuthSearchBy = By.xpath(CRConstants2.SERVICE_AUTHSEARCH);
	By serFinalConsBy = By.xpath(CRConstants2.SERVICE_FINALCONSNAME);
	By serReturnFinalBy = By.xpath(CRConstants2.SERVICE_RETURN_FINAL);

	By serDeclineAuthBy = By.xpath(CRConstants2.SERVICE_DECLINE);
	By serDeclineReasonDropDownBy = By.xpath(CRConstants2.SERVICE_DECLINE_DROPDOWN);
	By serDeclineFooterBy = By.xpath(CRConstants2.SERVICE_DECLINE_FOOTER);
	By serDeclineSubmitBy = By.xpath(CRConstants2.SERVICE_DECLINE_SUBMIT);

	// By.xpath(".//option[normalize-space(.) = " + escapeQuotes(text) + "]")
	// By.xpath('//path/to/select//option[contains(., "Partial text")]')

	// This is Vendor initial "Approve Service" request in Web2 environment
	public WebDriver doVendorApprovalStep(Map<String, String> data) {

		String serviceStr = data.get("SERVICETYPE").trim();
		String trackingNumber = data.get("TRACKINGNUMBER").trim();

		sleepTime(2);
		javaScriptClick(svcAuthlinkBy);
		sleepTime(2);
		windowSwitch();
		waitForPageToLoad();
		javaScriptClick(svcNotiBy);
		sleepTime(2);
		javaScriptClick(svcDDDBy);
		sleepTime(2);
	
		selectByValue(svcDropDownBy, serviceStr + "         ");
		// javaScriptClick(By.xpath("//option[contains(., '" + serviceStr + "')]"));

		sleepTime(2);
		javaScriptClick(svcSearchBy);
		sleepTime(2);
				
		By viewDetailsBy = By.xpath("(//td[text()='" + trackingNumber + "']//parent::tr//td)[2]/a");

		javaScriptClick(viewDetailsBy);
		sleepTime(2);

		javaScriptClick(svcYesBy);
		waitForPageToLoad();

		javaScriptClick(svcOfficeLevelBy);
		sleepTime(2);

		String svcVendorEndDate = getElement(svcVendorEndDateBy).getText();
		String svcEstimatedDate = CRCommon.addDaysToDate(svcVendorEndDate, "MM/dd/yyyy", 1);
		getElement(svcEstimateDateBy).clear();
		writeText(svcEstimateDateBy, svcEstimatedDate);

		javaScriptClick(svcSubmitBy);
		sleepTime(2);
		closeCurrentWindow();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();

		return getDriver();
	}

	public WebDriver getVendorResponseStatus(Map<String, String> data) {
		String trackingNumber = data.get("TRACKINGNUMBER").trim();
		waitForPageToLoad();
		javaScriptClick(scloginClientBy);
		windowSwitch();
		waitForPageToLoad();
		javaScriptClick(consumerAdminBy);
		sleepTime(2);
		javaScriptClick(scVendorCallQueue);
		sleepTime(2);
		waitForPageToLoad();
		writeText(scTrackingSearchBy, trackingNumber);
		sleepTime(2);
		javaScriptClick(vsAssistSearchBy);
		waitForPageToLoad();
		// By trackingNumberBy= By.xpath("//a[text()='"+trackingNumber+"']");
		// javaScriptClick(trackingNumberBy);
		// waitForPageToLoad();
		By vendorResponses = By.xpath("(//a[text()='" + trackingNumber + "']//parent::td//parent::tr//td)[2]");

		// if (getElement(vendorResponses).getText() == "1") {
		javaScriptClick(By.xpath("//a[text()='" + trackingNumber + "']"));
		sleepTime(2);
		javaScriptClick(serVendorResBy);
		sleepTime(2);
		javaScriptClick(serAcceptBy);
		sleepTime(2);
		javaScriptClick(serContinueBy);
		sleepTime(2);
		javaScriptClick(serOfficeBy);
		sleepTime(2);
		javaScriptClick(serAuthBy);
		closeCurrentWindow();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();

//		} else {
//			throw new RuntimeException("We don't find any vendor responses related to " + trackingNumber);
//		}
		return getDriver();

	}



// This is for vendor's "Final acknowledgement and Authorization" request in Web2

	public WebDriver doVendorFinalAcknoAuthStep(Map<String, String> data) {

		String trackingNumber = data.get("TRACKINGNUMBER").trim();

		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(serMainLink);
		sleepTime(2);
		windowSwitch();
		waitForPageToLoad();
		javaScriptClick(serAcknowledAuth);
		waitForPageToLoad();
		sleepTime(2);
		By acknowAuthCheckBoxBy = By.xpath("//td[text()='" + trackingNumber + "']//parent::tr/td/input");
		// Match tracking number from Web1 (SC authorized) and then click on check box
		javaScriptClick(acknowAuthCheckBoxBy);
		sleepTime(2);
		javaScriptClick(serAcknowBy);
		sleepTime(2);
		javaScriptClick(serFinalAuthBy);
		sleepTime(2);
		waitForPageToLoad();
		writeText(serTrackingBy, trackingNumber);
		sleepTime(2);
		javaScriptClick(serAuthSearchBy);
		sleepTime(2);
		javaScriptClick(serFinalConsBy);
		waitForPageToLoad();
		sleepTime(2);
		closeCurrentWindow();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		return getDriver();

	}

// This is Vendor "Deny request" in Web2 by matching Tracking number OR Assist ID
	public WebDriver doVendorDeclinedStep(Map<String, String> data) {

		String serviceStr = data.get("SERVICETYPE").trim();
		String declineReasonStr = data.get("DECLINEDREASON").trim();
		String trackingNumber = data.get("TRACKINGNUMBER").trim();
		

		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(serMainLink);
		sleepTime(2);
		windowSwitch();
		waitForPageToLoad();
		javaScriptClick(svcNotiBy);
		sleepTime(2);
		javaScriptClick(svcDDDBy);
		sleepTime(2);
		selectByValue(svcDropDownBy, serviceStr + "         ");
		sleepTime(2);
		javaScriptClick(svcSearchBy);
		waitForPageToLoad();
		sleepTime(2);
		
		By viewDetailsBy = By.xpath("(//td[text()='" + trackingNumber + "']//parent::tr//td)[2]/a");
		javaScriptClick(viewDetailsBy);
		sleepTime(2);		
		
		javaScriptClick(serDeclineAuthBy);
		sleepTime(2);
		selectByVisibleText(serDeclineReasonDropDownBy, declineReasonStr);
		sleepTime(2);
		javaScriptClick(serDeclineFooterBy);
		sleepTime(2);
		javaScriptClick(serDeclineSubmitBy);

		return getDriver();
	}
}
