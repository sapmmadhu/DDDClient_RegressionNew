package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;
import Constants.ExcelColumns;

public class DocumentedDisabilitiesPage extends BasePage {

	public WebDriver driver;

	public DocumentedDisabilitiesPage(WebDriver driver) {
		super(driver);
	}
	By consumerAdminBy = By.xpath(CRConstants.CONSUMER_ADMINISTRATION);
	By addDiagnosisDropdownBy = By.xpath(CRConstants.DIAG_DROPDOWN);
	By addFLTableBy = By.xpath(CRConstants.FL_TABLE);
	By addFLOneBy = By.xpath(CRConstants.FL_ONE);
	By addFLTwoBy = By.xpath(CRConstants.FL_TWO);
	By addFLThreeBy = By.xpath(CRConstants.FL_THREE);
	By addERNameBy = By.xpath(CRConstants.ERNAME);
	By addERTitleBy = By.xpath(CRConstants.ERTITLE);
	//By addERPhoneBy = By.xpath(CRConstants.ERPHONE);
	By addERTypeBy = By.xpath(CRConstants.ERDROPDOWN);
	//By addERReasonBy = By.xpath(CRConstants.EROTHER);
	By addERReasonBy = By.xpath(CRConstants.EROTHER);
	By addERdorBy = By.xpath(CRConstants.ERDOR);
	By addERCommentsBy = By.xpath(CRConstants.ERCOMMENTS);
	By addERSaveBy = By.xpath(CRConstants.ERSAVE);	
	By addERCancelBy = By.xpath(CRConstants.ERCANCEL);
	//By addERCancelBy = By.xpath(CRConstants.ERCANCEL);
	By addDiagnosisDeleteBy = By.xpath(CRConstants.DIAG_DELETE);
	By addDiagnosisViewEditby = By.xpath(CRConstants.DIAG_VIEWEDIT);
	
	By addETTypeBy = By.xpath(CRConstants.ETI_DROPDOWN);
	By addETSaveBy = By.xpath(CRConstants.ETI_SAVE);
	
	

	public void writeIntoFLs(String FLName, String writeText) {
		javaScriptCLick(By.xpath("//textarea[@placeholder='" + FLName + "']"));
		clear(By.xpath("//textarea[@placeholder='" + FLName + "']"));
		writeText(By.xpath("//textarea[@placeholder='" + FLName + "']"), writeText);
	}

	public void navToDDPage() {
		javaScriptCLick(consumerAdminBy);
	}
	public void doConsumerDD(Map<String, String> data) {

		String diagnosisName = data.get(ExcelColumns.DIAGNOSIS_DROPDOWN);
		String FL1Name = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_ONE_NAME);
		String FL1Value = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_ONE_VALUE);
		String FL2Name = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_TWO_NAME);
		String FL2Value = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_TWO_VALUE);
		String FL3Name = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_THREE_NAME);
		String FL3Value = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_THREE_VALUE);		
		String ERNameStr= data.get(ExcelColumns.ER_FIRSTNAME);
		String ERTitleStr= data.get(ExcelColumns.ER_TITLE);
		String ERTypeStr= data.get(ExcelColumns.ER_EVALUATION_DROPDOWN);
		String ERReasonStr = data.get(ExcelColumns.ER_REASON);
		String ERDORStr = data.get(ExcelColumns.ER_DATE_OF_REPORT);
		
		
		String ETDropDownStr = data.get(ExcelColumns.ETIOLOGY_TYPE);

		sleepTime(3);
		javaScriptCLick(addDiagnosisDropdownBy);
		selectByValue(addDiagnosisDropdownBy, diagnosisName);
		writeIntoFLs(FL1Name, FL1Value);
		writeIntoFLs(FL2Name, FL2Value);
		writeIntoFLs(FL3Name, FL3Value);
		
		sleepTime(5);
		scrollIntoView(addERNameBy);
		writeText(addERNameBy, ERNameStr);
		writeText(addERTitleBy, ERTitleStr);
		javaScriptCLick(addERTypeBy);
		selectByValue(addERTypeBy, ERTypeStr);
		writeText(addERReasonBy, ERReasonStr);
		writeText(addERdorBy, currentDate());
		javaScriptCLick(addERSaveBy);
		javaScriptCLick(addETTypeBy);
		selectByValue(addETTypeBy, ETDropDownStr);
		javaScriptCLick(addETSaveBy);
	    
		
	    }}