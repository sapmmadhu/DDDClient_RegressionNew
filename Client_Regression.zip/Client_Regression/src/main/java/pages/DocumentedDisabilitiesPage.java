package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;
import Constants.ExcelColumns;

public class DocumentedDisabilitiesPage extends BasePage {

	public WebDriver driver;

	public DocumentedDisabilitiesPage(WebDriver driver) {
		super(driver);
	}
	By consumerAdminBy = By.xpath(CRConstants.CONSUMER_ADMINISTRATION);
	By addDiagnosisDropdownBy = By.xpath(CRConstants.DIAG_DROPDOWN);
	By addFLTableBy = By.xpath(CRConstants.FL_TABLE);
	By addFLOneBy = By.xpath(CRConstants.FL_ONE);
	By addFLTwoBy = By.xpath(CRConstants.FL_TWO);
	By addFLThreeBy = By.xpath(CRConstants.FL_THREE);
	By addERNameBy = By.xpath(CRConstants.ERNAME);
	By addERTitleBy = By.xpath(CRConstants.ERTITLE);
	By addERPhoneBy = By.xpath(CRConstants.ERPHONE);
	By addERTypeBy = By.xpath(CRConstants.ERDROPDOWN);
	By addERReasonBy = By.xpath(CRConstants.EROTHER);
	By addERdorBy = By.xpath(CRConstants.ERDOR);
	By addERCommentsBy = By.xpath(CRConstants.ERCOMMENTS);
	By addERSaveBy = By.xpath(CRConstants.ERSAVE);	// Qualifying diagnosis screen - Save
	By addERCancelBy = By.xpath(CRConstants.ERCANCEL);
	//By addERCancelBy = By.xpath(CRConstants.ERCANCEL);
	By addDiagnosisDeleteBy = By.xpath(CRConstants.DIAG_DELETE);
	By addDiagnosisViewEditby = By.xpath(CRConstants.DIAG_VIEWEDIT);
	
	By addETHeaderBy = By.xpath(CRConstants.ETI_SUMMARY_HEADER); // This is to click on Etiology  tab
	By addETAddBy = By.xpath(CRConstants.ETI_DROPDOWN);
	By addETSaveBy = By.xpath(CRConstants.ETI_SAVE);
	By addETCancelBy = By.xpath(CRConstants.ETI_CANCEL);
	By addETDeleteBy = By.xpath(CRConstants.ETI_DELETE);
	By addETHistoryBy = By.xpath(CRConstants.ETI_HISTORY);
	
	
	

	public void writeIntoFLs(String FLName, String writeText) {
		javaScriptClick(By.xpath("//textarea[@placeholder='" + FLName + "']"));
		clear(By.xpath("//textarea[@placeholder='" + FLName + "']"));
		writeText(By.xpath("//textarea[@placeholder='" + FLName + "']"), writeText);
	}

	public void navToDDPage() {
		javaScriptClick(consumerAdminBy);
	}
	
	//public void doConsumerDD(Map<String, String> data) {
	
	public DocumentedDisabilitiesPage doDiagnosisSteps(Map<String, String> data) {

	try
	{
		String diagnosisName = data.get(ExcelColumns.DIAGNOSIS_DROPDOWN);
		//String FLTableStr = data.get(CRConstants.FL_TABLE);
		String FL1Name = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_ONE_NAME);
		String FL1Value = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_ONE_VALUE);
		String FL2Name = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_TWO_NAME);
		String FL2Value = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_TWO_VALUE);
		String FL3Name = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_THREE_NAME);
		String FL3Value = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_THREE_VALUE);
		//String FL4Name = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_THREE_NAME);
		//String FL4Value = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_THREE_VALUE);
		//String FL5Name = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_THREE_NAME);
		//String FL5Value = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_THREE_VALUE);
		//String FL6Name = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_THREE_NAME);
		//String FL6Value = data.get(ExcelColumns.FUNCTIONAL_LIMITATIONS_THREE_VALUE);
		String ERNameStr = data.get(ExcelColumns.ER_FIRSTNAME);
		String ERTitleStr = data.get(ExcelColumns.ER_TITLE);
		String ERPhoneStr = data.get(ExcelColumns.ER_PHONE);
		String ERTypeStr = data.get(ExcelColumns.ER_EVALUATION_DROPDOWN);
		String ERReasonStr = data.get(ExcelColumns.ER_REASON);
		String ERDORStr = data.get(ExcelColumns.ER_DATEOFREPORT);
		String ERCommentsStr = data.get(ExcelColumns.ER_COMMENTS);
		
		
		String ETDropDownStr = data.get(ExcelColumns.ETIOLOGY_TYPE);

		sleepTime(3);
		javaScriptClick(addDiagnosisDropdownBy);
		selectByValue(addDiagnosisDropdownBy, diagnosisName);
		//writeText(addFLTableBy, FLTableStr);
		writeIntoFLs(FL1Name, FL1Value);
		writeIntoFLs(FL2Name, FL2Value);
		writeIntoFLs(FL3Name, FL3Value);
		//writeIntoFLs(FL4Name, FL4Value);
		//writeIntoFLs(FL5Name, FL5Value);
		//writeIntoFLs(FL6Name, FL6Value);
		
		
		sleepTime(5);
		scrollIntoView(addERNameBy);
		writeText(addERNameBy, ERNameStr);
		writeText(addERTitleBy, ERTitleStr);
		writeText(addERPhoneBy, ERPhoneStr);
		javaScriptClick(addERTypeBy);
		selectByValue(addERTypeBy, ERTypeStr);
		writeText(addERReasonBy, ERReasonStr);
		writeText(addERdorBy, currentDate());
		writeText(addERCommentsBy, ERCommentsStr);
		javaScriptClick(addERSaveBy);
		javaScriptClick(addETHeaderBy);
		javaScriptClick(addETAddBy);
		selectByValue(addETAddBy, ETDropDownStr);
		javaScriptClick(addETSaveBy);  
		//javaScriptClick(addETHistoryBy);
		
		}	
	    catch(Exception e) {
			e.printStackTrace();
			//takeScreenShot(data);			
		}
			return this;
		}
	}