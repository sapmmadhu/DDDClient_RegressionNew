package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;
import Constants.ExcelColumns;

public class DocumentedDisabilitiesPage extends BasePage {

	public WebDriver driver;

	public DocumentedDisabilitiesPage(WebDriver driver) {
		super(driver);
	}
	
	By consumerMainMenuBy= By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	By documentedDisabilitiesBy = By.xpath(CRConstants.DOCUMENTED_DISABILITIES);
	
	// Qualifying Diagnosis tab
	By consumerAdminBy = By.xpath(CRConstants.CONSUMER_ADMINISTRATION);
	By addDiagnosisDropdownBy = By.xpath(CRConstants.DIAG_DROPDOWN);
	By addFLTableBy = By.xpath(CRConstants.FL_TABLE);
	By addFLOneBy = By.xpath(CRConstants.FL_ONE);
	By addFLTwoBy = By.xpath(CRConstants.FL_TWO);
	By addFLThreeBy = By.xpath(CRConstants.FL_THREE);
	By addERNameBy = By.xpath(CRConstants.ERNAME);
	By addERTitleBy = By.xpath(CRConstants.ERTITLE);
	By addERorgBy = By.xpath(CRConstants.ERORGA);
	By addERPhoneBy = By.xpath(CRConstants.ERPHONE);
	By addERAddressBy = By.xpath(CRConstants.ERADDRESS);
	By addERTypeBy = By.xpath(CRConstants.ERDROPDOWN);
	By addERReasonBy = By.xpath(CRConstants.EROTHER);
	By addERdorBy = By.xpath(CRConstants.ERDOR);
	By addERCommentsBy = By.xpath(CRConstants.ERCOMMENTS);
	By addSaveBy = By.xpath(CRConstants.DOCSAVE);	// Qualifying diagnosis screen - Save
	By addCancelBy = By.xpath(CRConstants.DOCCANCEL);
	//By addERCancelBy = By.xpath(CRConstants.ERCANCEL);
	By addDiagnosisDeleteBy = By.xpath(CRConstants.DIAG_DELETE);
	By addDiagnosisViewEditby = By.xpath(CRConstants.DIAG_VIEWEDIT);	
	
	
	// Etiology tab
	By addETHeaderBy = By.xpath(CRConstants.ETI_SUMMARY_HEADER); // This is to click on Etiology  tab
	By addETAddBy = By.xpath(CRConstants.ETI_DROPDOWN);
	By addETSaveBy = By.xpath(CRConstants.ETI_SAVE);
	By addETCancelBy = By.xpath(CRConstants.ETI_CANCEL);
	By addETDeleteBy = By.xpath(CRConstants.ETI_DELETEALL_SUM);
	By addETHistoryBy = By.xpath(CRConstants.ETI_HISTORY); // This will include after delete one Etiology
	
	//By addETTotalBy = By.xpath(CRConstans.ETI_TOTAL);
		

	public void writeIntoFLs(String FLName, String writeText) {
		javaScriptClick(By.xpath("//textarea[@placeholder='" + FLName + "']"));
		clear(By.xpath("//textarea[@placeholder='" + FLName + "']"));
		writeText(By.xpath("//textarea[@placeholder='" + FLName + "']"), writeText);
	}

	public void navToDDPage() {
		javaScriptClick(consumerAdminBy);
	}
	
	//public void doConsumerDD(Map<String, String> data) {
	
	public DocumentedDisabilitiesPage doDiagnosisSteps() {

		//sleepTime(3);
		javaScriptClick(consumerMainMenuBy);
		//sleepTime(2);
		javaScriptClick(documentedDisabilitiesBy);
		//sleepTime(2);
		javaScriptClick(addSaveBy);
			
			return this;
		}

}



