package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;
import Constants.ExcelColumns;

public class DocumentedDisabilitiesPage extends BasePage {

	public WebDriver driver;

	public DocumentedDisabilitiesPage(WebDriver driver) {
		super(driver);
	}

	By addDiagnosiDropdownBy = By.xpath(CRConstants.ADD_DIAGNOSIS_DROPDOWN);
	By addFLTableBy = By.xpath(CRConstants.FL_TABLE);
	By addFLOneBy = By.xpath(CRConstants.FL_ONE);
	By addFLTwoBy = By.xpath(CRConstants.FL_TWO);
	By addFLThreeBy = By.xpath(CRConstants.FL_THREE);
	By addERNameBy = By.xpath(CRConstants.ERNAME);
	By addERTitleBy = By.xpath(CRConstants.ERTITLE);
	By addERTypeBy = By.xpath(CRConstants.ERDROPDOWN);
	By addERdorBy = By.xpath(CRConstants.ERDOR);
	By addERCommentsBy = By.xpath(CRConstants.ERCOMMENTS);
	By addERSaveBy = By.xpath(CRConstants.ERSAVE);
	
	

	public void writeIntoFLs(String FLName, String writeText) {
		javaScriptCLick(By.xpath("//textarea[@placeholder='" + FLName + "']"));
		clear(By.xpath("//textarea[@placeholder='" + FLName + "']"));
		writeText(By.xpath("//textarea[@placeholder='" + FLName + "']"), writeText);
	}

	public void doConsumerDD(Map<String, String> data) {
		// String disabilityName, String functionalLimit, String functionalLimitOne,
		// String functionalLimitTwo, String ERName, String ERTitle, String
		// typeOFEvaluation

		String diagnosisName = data.get(ExcelColumns.DIAGNOSIS_DROPDOWN);
		String FL1Name = data.get("");
		String FL1Value = data.get("");
		String FL2Name = data.get("");
		String FL2Value = data.get("");
		String FL3Name = data.get("");
		String FL3Value = data.get("");
		String ERNameStr= data.get("");
		String ERTitleStr= data.get("");
		String ERTypeStr= data.get("");

		sleepTime(3);
		javaScriptCLick(addDiagnosiDropdownBy);
		selectByValue(addDiagnosiDropdownBy, diagnosisName);
		writeIntoFLs(FL1Name, FL1Value);
		writeIntoFLs(FL2Name, FL2Value);
		writeIntoFLs(FL3Name, FL3Value);
		scrollIntoView(addERNameBy);
		writeText(addERNameBy, ERNameStr);
		writeText(addERTitleBy, ERTitleStr);
		javaScriptCLick(addERTypeBy);
		selectByValue(addERTypeBy, ERTypeStr);
		javaScriptCLick(addERdorBy);
		writeText(addERdorBy, currentDate());
		javaScriptCLick(addERSaveBy);
	}
}