package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;
import Constants.ExcelColumns;

public class DocumentedDisabilitiesPage extends BasePage {

	public WebDriver driver;

	public DocumentedDisabilitiesPage(WebDriver driver) {
		super(driver);
	}
	
	By consumerMainMenuBy= By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	By documentedDisabilitiesBy = By.xpath(CRConstants.DOCUMENTED_DISABILITIES);
	By atRiskBy=By.xpath("//span[text()='At Risk']");
	// Qualifying Diagnosis tab
	By consumerAdminBy = By.xpath(CRConstants.CONSUMER_ADMINISTRATION);
	By addDiagnosisDropdownBy = By.xpath(CRConstants.DIAG_DROPDOWN);
	By addDiagnosisDropdownLevelBy = By.xpath(CRConstants.DIAG_LEVEL_DROPDOWN);
	By addFLTableBy = By.xpath(CRConstants.FL_TABLE);
	By addFLOneBy = By.xpath(CRConstants.FL_ONE);
	By addFLTwoBy = By.xpath(CRConstants.FL_TWO);
	By addFLThreeBy = By.xpath(CRConstants.FL_THREE);
	By addERNameBy = By.xpath(CRConstants.ER_NAME);
	By addERTitleBy = By.xpath(CRConstants.ER_TITLE);
	By addERorgBy = By.xpath(CRConstants.ER_ORGA);
	By addERPhoneBy = By.xpath(CRConstants.ER_PHONE);
	By addERTypeBy = By.xpath(CRConstants.ER_TYPE_DROPDOWN);
	By addEROtherBy = By.xpath(CRConstants.ER_OTHER);
	By addEROtherTextBy = By.xpath(CRConstants.ER_OTHER_TEXT);
	By addERdorCalanderBy = By.xpath(CRConstants.ER_DOR_CALANDER);
	By addERdorTodayBy = By.xpath(CRConstants.ER_DOR_TODAY);
	By addERCommentsBy = By.xpath(CRConstants.ERCOMMENTS);
	By addSaveBy = By.xpath(CRConstants.DOCSAVE);	// Qualifying diagnosis screen - Save
	By addCancelBy = By.xpath(CRConstants.DOCCANCEL);
	By addDiagnosisDeleteBy = By.xpath(CRConstants.DIAG_DELETE);
	By addDiagnosisViewEditby = By.xpath(CRConstants.DIAG_VIEWEDIT);	
	
	
	By etiologyBy = By.xpath(CRConstants.ETI_ETIOLOGY);
	By ET_ListBy= By.xpath(CRConstants.LIST_ETI_DROPDOWN);
	By ETSaveBy = By.xpath(CRConstants.ETI_SAVE);
	//By ETCancelBy = By.xpath(CRConstants.ETI_CANCEL);
	By ETDeleteBy = By.xpath(CRConstants.ETI_DELETEALL_SUM);
	By ETHistoryBy = By.xpath(CRConstants.ETI_HISTORY); // This will include after delete one Etiology
	
    By DDDEligibilityBy = By.xpath(CRConstants.ELIGIDDDBUTTON);
	
	//By addETTotalBy = By.xpath(CRConstans.ETI_TOTAL);
		

	public void writeIntoFLs(String FLName, String writeText) {
		javaScriptClick(By.xpath("//textarea[@placeholder='" + FLName + "']"));
		clear(By.xpath("//textarea[@placeholder='" + FLName + "']"));
		writeText(By.xpath("//textarea[@placeholder='" + FLName + "']"), writeText);
	}

	public void navToDDPage() {
		javaScriptClick(consumerAdminBy);
	}
	
	//public void doConsumerDD(Map<String, String> data) {
	
	public DocumentedDisabilitiesPage doDiagnosisSteps(Map<String, String> data) {
		String diagnosisDD = data.get(ExcelColumns.DIAGNOSIS_DROPDOWN).trim();
		String diagnosisLevelDD = data.get(ExcelColumns.DIAGNOSIS_DROPDOWNLEVEL).trim();
		String FL1_Name = data.get(ExcelColumns.DAIGNOSIS_FL1_NAME).trim();
		String FL2_Name = data.get(ExcelColumns.DAIGNOSIS_FL2_NAME).trim();
		String FL3_Name = data.get(ExcelColumns.DAIGNOSIS_FL3_NAME).trim();
		String FL1_Value = data.get(ExcelColumns.DAIGNOSIS_FL1_VALUE).trim();
		String FL2_Value = data.get(ExcelColumns.DAIGNOSIS_FL2_VALUE).trim();
		String FL3_Value = data.get(ExcelColumns.DAIGNOSIS_FL3_VALUE).trim();
		String ER_FirstName = data.get(ExcelColumns.ER_FIRSTNAME).trim();
		String ER_Title = data.get(ExcelColumns.ER_TITLE).trim();
		String ER_Phone = data.get(ExcelColumns.ER_PHONE).trim();
		String ER_Evaluation_Type = data.get(ExcelColumns.ER_EVALUATION_TYPE_DROPDOWN).trim();
		String ER_Reason = data.get(ExcelColumns.ER_REASON).trim();
		String ER_Comments = data.get(ExcelColumns.ER_COMMENTS).trim();
		
		
		sleepTime(3);
		javaScriptClick(consumerMainMenuBy);
		sleepTime(2);
		javaScriptClick(documentedDisabilitiesBy);
		sleepTime(2);
		scrollIntoView(addSaveBy);
		javaScriptClick(addSaveBy);
		javaScriptClick(addCancelBy);
		scrollIntoView(addDiagnosisDropdownBy);
		javaScriptClick(addDiagnosisDropdownBy);
		Boolean boo=isElementPresent(atRiskBy);
			if(boo==true) {
				System.out.println("At Risk available");
			}else {
				System.out.println("At Risk not available in Diagnosis DropDown");
			}
		javaScriptClick(By.xpath("//span[text()='"+diagnosisDD+"']"));
		scrollIntoView(addSaveBy);
		javaScriptClick(addSaveBy);
		scrollIntoView(addDiagnosisDropdownLevelBy);
		javaScriptClick(addDiagnosisDropdownLevelBy);
		javaScriptClick(By.xpath("//span[text()='"+diagnosisLevelDD+"']"));
		scrollIntoView(addSaveBy);
		javaScriptClick(addSaveBy);	
		
		writeIntoFLs(FL1_Name, FL1_Value);
		writeIntoFLs(FL2_Name, FL2_Value);
		writeIntoFLs(FL3_Name, FL3_Value);
		
		scrollIntoView(addSaveBy);
		javaScriptClick(addSaveBy);
		
		writeText(addERNameBy, ER_FirstName);
		javaScriptClick(addSaveBy);
		
		scrollIntoView(addERTitleBy);
		writeText(addERTitleBy, ER_Title);
		javaScriptClick(addSaveBy);
		
		scrollIntoView(addERPhoneBy);		
		writeText(addERPhoneBy, ER_Phone);		
		javaScriptClick(addSaveBy);
		
		scrollIntoView(addERTypeBy);		
		javaScriptClick(addERTypeBy);
		javaScriptClick(By.xpath("//span[text()='"+ER_Evaluation_Type+"']"));
		if(ER_Evaluation_Type.contains("Other")) {
		writeText(addEROtherTextBy, ER_Reason);}
		javaScriptClick(addSaveBy);
		
		javaScriptClick(addERdorCalanderBy);
		javaScriptClick(addERdorTodayBy);		
		javaScriptClick(addSaveBy);
		
		scrollIntoView(addERCommentsBy);		
		writeText(addERCommentsBy, ER_Comments);
		javaScriptClick(addSaveBy);
		
		doDiagnosisSteps(data);
		dddeligibilityReq_Steps();
		
			return this;
		}
	
	public void doEtiologySteps(Map<String ,String>data) {
		
		String ET_List_SelectStr = data.get(ExcelColumns.ETIOLOGY_TYPE).trim();
		
		
		javaScriptClick(etiologyBy);
		javaScriptClick(ET_ListBy);
        javaScriptClick(By.xpath("//span[text()='"+ET_List_SelectStr+"']"));
        javaScriptClick(ETSaveBy);
        
		
	}
	
	
	public void dddeligibilityReq_Steps() {
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(DDDEligibilityBy);
		
	}

}



