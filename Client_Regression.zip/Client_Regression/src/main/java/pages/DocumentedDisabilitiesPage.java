package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;
import Constants.ExcelColumns;

public class DocumentedDisabilitiesPage extends BasePage {

	public WebDriver driver;

	public DocumentedDisabilitiesPage(WebDriver driver) {
		super(driver);
	}

	By addDiagnosiDropdownBy = By.xpath(CRConstants.DIAG_DROPDOWN);
	By addFLTableBy = By.xpath(CRConstants.FL_TABLE);
	By addFLOneBy = By.xpath(CRConstants.FL_ONE);
	By addFLTwoBy = By.xpath(CRConstants.FL_TWO);
	By addFLThreeBy = By.xpath(CRConstants.FL_THREE);
	By addERNameBy = By.xpath(CRConstants.ERNAME);
	By addERTitleBy = By.xpath(CRConstants.ERTITLE);
	By addERTypeBy = By.xpath(CRConstants.ERDROPDOWN);
	By addERdorBy = By.xpath(CRConstants.ERDOR);
	By addERCommentsBy = By.xpath(CRConstants.ERCOMMENTS);
	By addERSaveBy = By.xpath(CRConstants.ERSAVE);	
	

	public void writeIntoFLs(String FLName, String writeText) {
		javaScriptCLick(By.xpath("//textarea[@placeholder='" + FLName + "']"));
		clear(By.xpath("//textarea[@placeholder='" + FLName + "']"));
		writeText(By.xpath("//textarea[@placeholder='" + FLName + "']"), writeText);
	}

	public void doConsumerDD(Map<String, String> data) {

		//try {
		String diagnosisName = data.get(ExcelColumns.DIAGNOSIS_DROPDOWN);
		String FL1Name = data.get("");
		String FL1Value = data.get("");
		String FL2Name = data.get("");
		String FL2Value = data.get("");
		String FL3Name = data.get("");
		String FL3Value = data.get("");
		//String FL4Name = data.get("");
		//String FL4Value = data.get("");
		//String FL5Name = data.get("");
		//String FL5Value = data.get("");
		//String FL6Name = data.get("");
		//String FL6Value = data.get("");
		//String FL7Name = data.get("");
		//String FL7Value = data.get("");
		String ERNameStr= data.get("");
		String ERTitleStr= data.get("");
		String ERTypeStr= data.get("");

		sleepTime(3);
		javaScriptCLick(addDiagnosiDropdownBy);
		selectByValue(addDiagnosiDropdownBy, diagnosisName);
		writeIntoFLs(FL1Name, FL1Value);
		writeIntoFLs(FL2Name, FL2Value);
		writeIntoFLs(FL3Name, FL3Value);
		//writeIntoFLs(FL4Name, FL4Value);
		//writeIntoFLs(FL5Name, FL5Value);
		//writeIntoFLs(FL6Name, FL6Value);
		//writeIntoFLs(FL7Name, FL7Value);
	//	Thread.sleep(5000);
		sleepTime(5);
		scrollIntoView(addERNameBy);
		writeText(addERNameBy, ERNameStr);
		writeText(addERTitleBy, ERTitleStr);
		javaScriptCLick(addERTypeBy);
		selectByValue(addERTypeBy, ERTypeStr);
		javaScriptCLick(addERdorBy);
		writeText(addERdorBy, currentDate());
		javaScriptCLick(addERSaveBy);
	  //  }catch(Exception e) {
	//	e.printStackTrace();
		//takeScreenShot(data);
				
			
			/*
			 * System.out.println("Message Saved Successfully"); 
			 * System.out.println("This member is DDD eligible. You cannot delete the Primary Diagnosis!");
			 * System.out.println("Please select at least 3 Functional Limitations to add!");
			 * System.out.println("Please select Type of Evaluation Report!");
			 * System.out.println("Please select a Qualifying Diagnosis to add!");
			 * System.out.println("Please Select Level of Cognitive/Intellectual Disability.");
			 * System.out.println("Please select Name!");
			 * System.out.println("Please select Title!");
			 * System.out.println("Please select Organization!");
			 * System.out.println("Please select Date Of Report!");
			 * System.out.println("Please select Phone Number");
			 * System.out.println("Please select Address!");
			 * System.out.println("Please select Comments!");
			 * System.out.println("Please Click View/ Edit button!");
			 * System.out.println("Summary, Add, Diagnosis, Functional Limitations, Evaluation/Report displayed");
			   System.out.println("Aug Comm Diagnosis is displayed");
		        System.out.println("Etiology is displayed");
		*/
		//}
	    }}