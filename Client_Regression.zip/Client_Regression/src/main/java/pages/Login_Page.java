package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import drivers.CRConstants;

public class Login_Page extends Base_Page {

	public WebDriver driver;

	@FindBy(xpath = CRConstants.USER_NAME)  WebElement userName;
	@FindBy(xpath = CRConstants.PASSWORD)   WebElement password;
	@FindBy(xpath = CRConstants.LOGIN) WebElement login;

	public Login_Page(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public WebDriver loginStep(String userNameStr, String passwordStr) {
		/*
		 * userName.sendKeys(userNameStr); password.sendKeys(passwordStr);
		 * login.click();
		 */

		
		  sendWebElements(userName, userNameStr); 
		  sendWebElements(password,passwordStr); 
		  webEleClick(login);
		 
		
		return driver;
	}
}
