package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import drivers.CRConstants;

public class Login_Page extends Base_Page {

	public WebDriver driver;

	By userNameBy = By.xpath(CRConstants.USER_NAME);
	By passwordBy = By.xpath(CRConstants.PASSWORD);
	By loginBy = By.xpath(CRConstants.LOGIN);

	public Login_Page(WebDriver driver) {
		super(driver);
	}

	public WebDriver loginStep(String userNameStr, String passwordStr) {

		sendWebElements(userNameBy, userNameStr);
		sendWebElements(passwordBy, passwordStr);
		webEleClick(loginBy);

		return driver;
	}
}
