package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Constants.CRConstants;
import Constants.ExcelColumns;
import dataProviders.ConfigFileReader;

public class ClientApplicationPage extends BasePage {

	public WebDriver driver;
	ConfigFileReader reader = new ConfigFileReader();

	By consumerAdminBy = By.xpath(CRConstants.CONSUMER_ADMINISTRATION);
	By viewMyConsumerBy = By.xpath(CRConstants.VIEW_MY_CONSUMERS);
	By clientApplicationBy = By.xpath(CRConstants.CLIENT_APPLICATION);
	By addConsBy = By.xpath(CRConstants.ADD_CONSUMER);
	By lastNameBy = By.xpath(CRConstants.LAST_NAME);
	By firstNameBy = By.xpath(CRConstants.FIRST_NAME);
	// By ssnBy = By.xpath(CRConstants.SSN);
	By genderBy = By.xpath(CRConstants.GENDER);
	By dateOfBirthBy = By.xpath(CRConstants.DATE_OF_BIRTH);
	By continueBy = By.xpath(CRConstants.CONTINUE);
	By addAndContinueBy = By.xpath(CRConstants.ADD_AND_CONTINUE);
	By addContinueBy = By.id("ContentPrimary_dgNewAdd_Linkbutton2_0");
	By popupBy = By.xpath(CRConstants.POPUP);
	By pop1By = By.cssSelector("#myModal > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > button");
	By sel_GenderBy = By.xpath("//div[contains(text(),'SELECT')]");
	By sel_Gender_MaleBy = By.xpath("//span[contains(text(),'Male')]");
	By sel_Gender_FemaleBy = By.xpath("//span[contains(text(),'Female')]");
	By sel_Gender_UnknownBy = By.xpath("//span[contains(text(),'Unknown')]");
	By duplicateRecordsBy = By.id("ContentPrimary_Label4");
	
	By workerDropBy = By.xpath(CRConstants.ELIGIWORKERDROPDOWN);
	By clientDropBy = By.xpath(CRConstants.ELIGICLIENTDROPDOWN);
	By myConsumerBy = By.xpath(CRConstants.ELIGIMYCONSUMERS);
	

	
	By secondListBy = By.xpath("//a[text()='2']");
	By clientSearchBy = By.xpath(CRConstants.CLIENT_SEARCH);
	By clientNameDropBy = By.xpath(CRConstants.CLIENT_SEARCH_NAME_DROPDOWN);
	By clientAssistBy = By.xpath(CRConstants.CLIENT_SEARCH_ASSIST_ID);
	By clientSearchFinalBy = By.xpath(CRConstants.CLIENT_SEARCH_BUTTON);

	By eliDeterRedeterBy = By.xpath(CRConstants.ELIGIDETERREDETER);
	By eliDeterRedeterYesBy = By.xpath(CRConstants.ELIGIYESBUTTON);
	By eliDeterRedeterSaveBy = By.xpath(CRConstants.ELIGIFINALSAVE);
    By eliDeterSuccessMsgBy = By.xpath(CRConstants.ELIGISUCCESSMSG);
    
    
    

	By myConsumersBy = By.xpath(CRConstants.ELIGIMYCONSUMERS);
	By eligiStatusBy = By.xpath(CRConstants.ELIGISTATUS);	
	By consumerMainMenuBy= By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	By ispServicePlanBy = By.xpath(CRConstants.ISPSERVICE);
	By ispAnnualDateBy = By.xpath(CRConstants.ISPANNUALDATE);
	By ispAnnualTodayBy = By.xpath(CRConstants.ISPTODAYDATE);
	By ispCreateNewBy = By.xpath(CRConstants.ISPCREATENEW);
	By ispSuccessMsgBy = By.xpath(CRConstants.ISPSUCCESSFULMSG);
    
	public ClientApplicationPage(WebDriver driver) {

		super(driver);
	}

	public ResponsiblePartyPage doAddConsumersStep(Map<String, String> data) {
		// try {
		String firstNameStr = data.get("CFN");
		String lastNameStr = data.get("CLN");
		String genderStr = data.get("CG");
		String dobStr = data.get("CDOB");

		// sleepTime(3);
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(3);
		javaScriptClick(consumerAdminBy);
		// MaximizeWindow();
		// sleepTime(4);
		javaScriptClick(viewMyConsumerBy);
		// sleepTime(4);
		javaScriptClick(addConsBy);
		sleepTime(2);
		writeText(lastNameBy, lastNameStr);
		writeText(firstNameBy, firstNameStr);
		sleepTime(4);
		click(genderBy);
		// sleepTime(3);
		javaScriptClick(sel_GenderBy);

		if (genderStr.equalsIgnoreCase("M") || genderStr.equalsIgnoreCase("Male")) {
			javaScriptClick(sel_Gender_MaleBy);
		} else if (genderStr.equalsIgnoreCase("F") || genderStr.equalsIgnoreCase("Female")) {
			javaScriptClick(sel_Gender_FemaleBy);
		} else if (genderStr.equalsIgnoreCase("U") || genderStr.equalsIgnoreCase("Unknown")) {
			javaScriptClick(sel_Gender_UnknownBy);
		} else
			throw new RuntimeException("Gender not specified in the Excel file for the Key:Gender");

		// selectByValue(genderBy, genderStr);
		sleepTime(2);
		// clickwithoutWait(dateOfBirthBy);
		System.out.println("dobstr: " + dobStr);
		writeText(dateOfBirthBy, dobStr);
		// sleepTime(4);
		javaScriptClick(continueBy);
		// sleepTime(4);
		MaximizeWindow();
		sleepTime(4);
		scrollIntoView(addContinueBy);

		if (isElementPresent(duplicateRecordsBy) == true) {
			scrollIntoView(addAndContinueBy);
		}

		// doubleClick(addAndContinueBy);
		sleepTime(2);
		doubleClick(addContinueBy);
		sleepTime(4);
		waitForAlertToAppear();
		sleepTime(4);
		waitForElementToClick(popupBy);
		sleepTime(4);
		javaScriptClick(popupBy);

		// }catch(Exception e) {
		// e.printStackTrace();
		// takeScreenShot(data);8

		// }
		return new ResponsiblePartyPage(getDriver());
	}

	public String getClientID(String assistId) {

		javaScriptClick(clientSearchBy);
		waitForPageToLoad();
		
		System.out.println(getDriver().getTitle());
		windowSwitch();
		sleepTime(3);
		selectByVisibleText(clientNameDropBy, "Assists Id");
		writeText(clientAssistBy, assistId);
		javaScriptClick(clientSearchFinalBy);
		waitForPageToLoad();
		String clientId = getElement(By.xpath("(//td[text()='" + assistId + "']//following::td)[1]")).getText();
		closeCurrentWindow();
		sleepTime(5);
		navigateToBack();
		sleepTime(5);
		navigateToBack();

		return clientId;
	}

	
	
	// The below is DDD Eligibility approval from SC Supervisor
	public void dddeligibilityApp_Steps() {
		// To Match consumer name below
		javaScriptClick(eliDeterRedeterYesBy);
		javaScriptClick(eliDeterRedeterSaveBy);
	}

	
	
	public WebDriver clickOn_Supervisor_CA(String clientId) {
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(2);
		javaScriptClick(consumerAdminBy);
		sleepTime(2);
		javaScriptClick(eliDeterRedeterBy);
        waitForPageToLoad();
        By clientIdBy=By.xpath("(//a[text()='"+clientId+"']//following::a)[1]");
       // if(getElements(clientIdBy).size()!=0) {
       // 	 javaScriptClick(clientIdBy);
       // }else {
        	javaScriptClick(secondListBy);
        	 javaScriptClick(clientIdBy);
        //}
       
        sleepTime(3);
        javaScriptClick(eliDeterRedeterYesBy);
        sleepTime(4);
        javaScriptClick(eliDeterRedeterSaveBy);
        String successMsgBy = getElement(eliDeterSuccessMsgBy).getText();
        System.out.println(successMsgBy);
        closeCurrentWindow();
        waitForPageToLoad();
        navigateToBack();
        waitForPageToLoad();
        navigateToBack();
        waitForPageToLoad();
        return getDriver();
	}
	
	

	public void ISPPlanCreation(String clientId, Map<String, String>data) {
		
		String lastName=data.get(ExcelColumns.LASTNAME);
		String firstName=data.get(ExcelColumns.FIRSTNAME);
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(2);
		javaScriptClick(consumerAdminBy);
		MaximizeWindow();
		javaScriptClick(viewMyConsumerBy);
		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(clientDropBy);
		sleepTime(2);
		By clientBy=By.xpath("//span[text()='"+lastName+" "+firstName+"']");
		int clientSize=getElements(clientBy).size();
		By clientLastIndexBy=By.xpath("(//span[text()='"+lastName+" "+firstName+"'])["+clientSize+"]");
		scrollIntoView(clientLastIndexBy);
		javaScriptClick(clientLastIndexBy);
		javaScriptClick(myConsumersBy);
		
	
		By elligibilityBy=By.xpath("(//td[text()='"+lastName+" "+firstName+"']//parent::tr//td)[4]");
		String elligibilityText=getElement(elligibilityBy).getText();
		By selectIdBy=By.xpath("//td[text()='"+lastName+" "+ firstName+"']//parent::tr//a[@data-original-title='"+clientId+"']");
		if(getElements(selectIdBy).size()!=0&& elligibilityText.equalsIgnoreCase("DDD")) {
			javaScriptClick(selectIdBy);
			waitForPageToLoad();
			javaScriptClick(consumerMainMenuBy);
			javaScriptClick(ispServicePlanBy);
			waitForPageToLoad();
			javaScriptClick(ispAnnualDateBy);
			javaScriptClick(ispAnnualTodayBy);
			javaScriptClick(ispCreateNewBy);			
		}else {
			System.out.println(clientId+" not available");
			 throw new RuntimeException(clientId+" you are searching for not available or elligiblity not approved");	
		}
		
	}
}
