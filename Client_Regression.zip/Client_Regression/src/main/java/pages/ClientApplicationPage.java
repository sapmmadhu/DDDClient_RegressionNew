package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;
import dataProviders.ConfigFileReader;

public class ClientApplicationPage extends BasePage {

	public WebDriver driver;
	ConfigFileReader reader = new ConfigFileReader();

	By consumerAdminBy = By.xpath(CRConstants.CONSUMER_ADMINISTRATION);
	By viewMyConsumerBy = By.xpath(CRConstants.VIEW_MY_CONSUMERS);
	By clientApplicationBy = By.xpath(CRConstants.CLIENT_APPLICATION);
	By addConsBy = By.xpath(CRConstants.ADD_CONSUMER);
	By lastNameBy = By.xpath(CRConstants.LAST_NAME);
	By firstNameBy = By.xpath(CRConstants.FIRST_NAME);
	//By ssnBy = By.xpath(CRConstants.SSN);
	By genderBy = By.xpath(CRConstants.GENDER);
	By dateOfBirthBy = By.xpath(CRConstants.DATE_OF_BIRTH);
	By continueBy = By.xpath(CRConstants.CONTINUE);
	By addAndContinueBy = By.xpath(CRConstants.ADD_AND_CONTINUE);
	By addContinueBy=By.id("ContentPrimary_dgNewAdd_Linkbutton2_0");
	By popupBy = By.xpath(CRConstants.POPUP);
	By pop1By=By.cssSelector("#myModal > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > button");
	By sel_GenderBy=By.xpath("//div[contains(text(),'SELECT')]");
	By sel_Gender_MaleBy=By.xpath("//span[contains(text(),'Male')]");
	By sel_Gender_FemaleBy=By.xpath("//span[contains(text(),'Female')]");
	By sel_Gender_UnknownBy=By.xpath("//span[contains(text(),'Unknown')]");
	By duplicateRecordsBy=By.id("ContentPrimary_Label4");
	
	public ClientApplicationPage(WebDriver driver) {
		
		super(driver);
	}

	public ResponsiblePartyPage doAddConsumersStep(Map<String, String> data) {
		//try {
		String firstNameStr = data.get("CFN");
		String lastNameStr = data.get("CLN");
		String genderStr = data.get("CG");
		String dobStr = data.get("CDOB");
		
		//sleepTime(3);
		javaScriptClick(clientApplicationBy);
		windowSwitch();
		//sleepTime(4);
		javaScriptClick(consumerAdminBy);
		//MaximizeWindow();
		//sleepTime(4);
		javaScriptClick(viewMyConsumerBy);
		//sleepTime(4);
		javaScriptClick(addConsBy);
		sleepTime(2);
		writeText(lastNameBy, lastNameStr);
		writeText(firstNameBy, firstNameStr);
		sleepTime(4);
		click(genderBy);
		//sleepTime(3);
		javaScriptClick(sel_GenderBy);
		
		if(genderStr.equalsIgnoreCase("M")||genderStr.equalsIgnoreCase("Male")) {
			javaScriptClick(sel_Gender_MaleBy);
		}else if(genderStr.equalsIgnoreCase("F")||genderStr.equalsIgnoreCase("Female")) {
			javaScriptClick(sel_Gender_FemaleBy);
		}else if(genderStr.equalsIgnoreCase("U")||genderStr.equalsIgnoreCase("Unknown")){
				javaScriptClick(sel_Gender_UnknownBy);
		}else throw new RuntimeException("Gender not specified in the Excel file for the Key:Gender");
		
		//selectByValue(genderBy, genderStr);
		sleepTime(2);
		//clickwithoutWait(dateOfBirthBy);
		System.out.println("dobstr: "+dobStr);
		writeText(dateOfBirthBy, dobStr);
		//sleepTime(4);
		javaScriptClick(continueBy);
		//sleepTime(4);
		MaximizeWindow();
		sleepTime(4);
		scrollIntoView(addContinueBy);
		if(isElementPresent(duplicateRecordsBy)==true) {
		scrollIntoView(addAndContinueBy);
		}
		//doubleClick(addAndContinueBy);
		sleepTime(2);
		doubleClick(addContinueBy);
		//sleepTime(4);
		waitForAlertToAppear();
		sleepTime(4);
		waitForElementToClick(popupBy);
		sleepTime(4);
		javaScriptClick(popupBy);

		
		//}catch(Exception e) {
			//e.printStackTrace();
			//takeScreenShot(data);8
			
		//}
		return new ResponsiblePartyPage(getDriver());
	}

}
