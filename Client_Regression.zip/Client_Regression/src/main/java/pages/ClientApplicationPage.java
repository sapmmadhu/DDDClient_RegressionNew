package pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import Constants.CRConstants;
import Constants.CRConstants2;

import Constants.ExcelColumns;
import dataProviders.ConfigFileReader;
import dataProviders.DataProvider_IN_OUT;

public class ClientApplicationPage extends BasePage {

	public static WebDriver browser;
	public WebDriver driver;
	ConfigFileReader reader = new ConfigFileReader();

	By consumerAdminBy = By.xpath(CRConstants.CONSUMER_ADMINISTRATION);
	By viewMyConsumerBy = By.xpath(CRConstants.VIEW_MY_CONSUMERS);
	By clientApplicationBy = By.xpath(CRConstants.CLIENT_APPLICATION);
	By addConsBy = By.xpath(CRConstants.ADD_CONSUMER);
	By lastNameBy = By.xpath(CRConstants.LAST_NAME);
	By firstNameBy = By.xpath(CRConstants.FIRST_NAME);
	// By ssnBy = By.xpath(CRConstants.SSN);
	By genderBy = By.xpath(CRConstants.GENDER);
	By dateOfBirthBy = By.xpath(CRConstants.DATE_OF_BIRTH);
	By continueBy = By.xpath(CRConstants.CONTINUE);
	By addAndContinueBy = By.xpath(CRConstants.ADD_AND_CONTINUE);
	By addContinueBy = By.id("ContentPrimary_dgNewAdd_Linkbutton2_0");
	By popupBy = By.xpath(CRConstants.POPUP);
	By pop1By = By.cssSelector("#myModal > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > button");
	By sel_GenderBy = By.xpath("//div[contains(text(),'SELECT')]");
	By sel_Gender_MaleBy = By.xpath("//span[contains(text(),'Male')]");
	By sel_Gender_FemaleBy = By.xpath("//span[contains(text(),'Female')]");
	By sel_Gender_UnknownBy = By.xpath("//span[contains(text(),'Unknown')]");
	By duplicateRecordsBy = By.id("ContentPrimary_Label4");

	By workerDropBy = By.xpath(CRConstants.ELIGIWORKERDROPDOWN);
	By clientDropBy = By.xpath(CRConstants.ELIGICLIENTDROPDOWN);
	By myConsumerBy = By.xpath(CRConstants.ELIGIMYCONSUMERS);

	By firstListBy = By.xpath("//span[text()='1']");
	By secondListBy = By.xpath("//a[text()='2']");
	By clientSearchBy = By.xpath(CRConstants.CLIENT_SEARCH);
	By clientNameDropBy = By.xpath(CRConstants.CLIENT_SEARCH_NAME_DROPDOWN);
	By clientAssistBy = By.xpath(CRConstants.CLIENT_SEARCH_ASSIST_ID);
	By clientSearchFinalBy = By.xpath(CRConstants.CLIENT_SEARCH_BUTTON);

	By eliDeterRedeterBy = By.xpath(CRConstants.ELIGIDETERREDETER);
	By eliDeterRedeterYesBy = By.xpath(CRConstants.ELIGIYESBUTTON);
	By eliDeterRedeterSaveBy = By.xpath(CRConstants.ELIGIFINALSAVE);
	By eliDeterSuccessMsgBy = By.xpath(CRConstants.ELIGISUCCESSMSG);

	By myConsumersBy = By.xpath(CRConstants.ELIGIMYCONSUMERS);
	By ispSearchDropBy = By.xpath(CRConstants.ISPSEARCHDROP);
	By eligiStatusBy = By.xpath(CRConstants.ELIGISTATUS);
	By consumerMainMenuBy = By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	By ispServicePlanBy = By.xpath(CRConstants.ISPSERVICE);
	By ispAnnualDateBy = By.xpath(CRConstants.ISPANNUALDATE);
	By ispAnnualTodayBy = By.xpath(CRConstants.ISPTODAYDATE);
	By ispCreateNewBy = By.xpath(CRConstants.ISPCREATENEW);
	By ispSuccessMsgBy = By.xpath(CRConstants.ISPSUCCESSFULMSG);

	By supervisorServiceBy = By.xpath(CRConstants.SRVCAPPLINK);
	By serviceUnitsBy = By.xpath(CRConstants.SRVCEREQUUNITS);
	By serviceSaveBy = By.xpath(CRConstants.SRVCESAVE);

	By redetermineEligibilityBy = By.xpath(CRConstants.REDETERMINATION);
	By redetermineReasonBy = By.xpath(CRConstants.REDETERMINATIONREASON);
	By redetermineNotesBy = By.xpath(CRConstants.REDETERMINATIONNOTES);
	By redetermineSaveBy = By.xpath(CRConstants.REDETERMINATIONSAVE);

	private By serviceApprovalsById = By.id("lnkServiceApprovals");
	private By serviceApprovedUnitsById = By.id("ContentPrimary_txtApprovedUnits");
	private By serviceAppSaveById = By.id("ContentPrimary_btnSave");

	private By ispDateHistoryById = By.id("ContentPrimary_lnkIspHistory");
	private By ispStartDateValueById = By.id("ContentPrimary_lblISPStart");
	private By ispAnnualValueById = By.id("lblAnnualISPValue");
	private By ispSchedulerById = By.id("ContentPrimary_ISPScheduler");
	private By ispSchedulerInfoById = By.id("infoSchedule");
	private By ispSchedulerHeaderById = By.id("ContentPrimary_Label7");
	private By ispSchedulerInfoCloseByXpath = By.xpath("//button[@id='popupBoxClose']");
	private By ispCoverPageById = By.id("ContentPrimary_ISPCoverPage");

	private By ispManagedRiskAgreementById = By.id("ContentPrimary_MRA");
	private By ispManagedRiskAgreementSubLinkById = By.id("ContentPrimary_MRA_History");
	private By ispManagedRiskAgreementCancelById = By.id("ContentPrimary_btnCancel");

	private By linkMedicalCoverageByXpath = By.xpath("//a[text()=' Medical Coverage']");
	private By linkMedicalCoverageAddByXpath = By.xpath("//a[text()='Add TPL/Medicare Coverage']");

	private By venSelectionByXpath = By.xpath("//a[text()='Vendor Selection & Authorization']");
	private By createAuthLinkByXpath = By.xpath("//a[text()='Create New Authorization']");

	private By addressBookAddEditById = By.id("lnkAddEditConsumerAddr");
	private By addressBookAddContById = By.id("lnkAddAdditionalContact");
	private By addressBookViewContById = By.id("lnkViewPrintAddressBook");

	private By progressNotesId = By.id("lnkProcessNotes");

	private By aliasesById = By.id("lnkConsumerAliases");

	private By aliasesAddById = By.id("ContentPrimary_lnkAddNew");

	private By benefitsById = By.id("lnkSocialServices");
	private By benefitsAddById = By.id("ContentPrimary_lnkAddNewBenefitRecord");

	private By caseStatusById = By.id("lnkCaseStatus");
	private By caseStatusAddById = By.id("ContentPrimary_lnkAddNew");

	private By demegraphicsById = By.id("lnkConsumerDemographics");

	private By educationalHistoryById = By.id("lnkEducationalHistory");
	private By educationalHistoryAddById = By.id("ContentPrimary_lnkAddNew");

	private By fosterCareById = By.id("lnkFosterCare");

	private By taskListById = By.id("lnkTaskList");

	private By behaviourById = By.id("lnkBehavior");

	private By birthHistoryById = By.id("lnkBirthhistory");

	private By developmentById = By.id("lnkDevelopment");

	private By hospitalizationById = By.id("lnkHospitalizationsIllnesses");
	private By hospitalizationAddById = By.id("ContentPrimary_lnkAddNew");

	private By medicalConcernsById = By.id("lnkMedicalConcerns");

	private By prenatalById = By.id("lnkPrenatal");

	private By behavioralById = By.id("Hyperlink6");

	private By placementResidentById = By.id("lnkPlacementDetails");

	private By providerNotById = By.id("lnkProviderNotAvailable");

	private By progressNotesById = By.id("lnkProcessNotes");

	// Below variables are from Constants2 in order to finish Web2 links validations		
	private By adminToolslinkByXpath = By.xpath("//a[text()='ADMIN TOOLS']");
	private By incidentMgmntlinkByXpath = By.xpath("//a[text()='INCIDENT MANAGEMENT']");
	private By olcrTracklinklinkByXpath = By.xpath("//a[text()='OLCR TRACKING APPLICATION']");
	private By qualifiedVendorlinkByXpath = By.xpath("//a[text()='QUALIFIED VENDOR CONTRACT']");
	private By serviceAuthlinkByXpath = By.xpath("//a[text()='SERVICE AUTHORIZATIONS']");
	private By vendorRBSlinkByXpath = By.xpath("//a[text()='VENDOR PBS REPORTS']");
	
	private By mainMenulinkByXpath = By.xpath("//a[text()='Main Menu']");
	private By serviceNotilinkByXpath = By.xpath("//a[text()='Service Notifications']");
	private By pendingAuthlinkByXpath = By.xpath("//a[text()='Pending Auths']");
	private By declinedlinkByXpath = By.xpath("//a[text()='Declined Requests']");
	private By acknowledgelinkByXpath = By.xpath("//a[text()='Acknowledge Auths']");
	private By finalAuthlinkByXpath = By.xpath("//a[text()='Final Auths']");
	private By withoutResponselinkByXpath = By.xpath("//a[text()='Service Notifications without responses']");
	
	

	private Calendar data;

	public ClientApplicationPage(WebDriver driver) {
		super(driver);
	}

	public void Web1commonlinksnavigationflow(String lastName, String firstName) {

		waitForPageToLoad();
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(2);
		javaScriptClick(consumerAdminBy);
		MaximizeWindow();
		javaScriptClick(viewMyConsumerBy);
		sleepTime(5);
		waitForPageToLoad();

		javaScriptClick(clientDropBy);
		sleepTime(2);
		// javaScriptClick(clientDropBy);
		// sleepTime(2);
		waitForPageToLoad();
		writeText(ispSearchDropBy, lastName + " " + firstName);
		By clientBy = By.xpath("//span[text()='" + lastName + " " + firstName + "']");
		int clientSize = getElements(clientBy).size();
		By clientLastIndexBy = By.xpath("(//span[text()='" + lastName + " " + firstName + "'])[" + clientSize + "]");
		scrollIntoView(clientLastIndexBy);
		javaScriptClick(clientLastIndexBy);
		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(myConsumersBy);
	}

	public WebDriver doCAWeb1EndToEndLinks(String clientId, Map<String, String> data, DataProvider_IN_OUT dp1,
			String filePath, String sheetName, String ColName, int DR) throws Exception {

		String lastName = data.get(ExcelColumns.LASTNAME).toUpperCase();
		String firstName = data.get(ExcelColumns.FIRSTNAME).toUpperCase();
		Web1commonlinksnavigationflow(lastName, firstName);

		By elligibilityBy = By.xpath("(//td[text()='" + lastName + " " + firstName + "']//parent::tr//td)[4]");
		String elligibilityText = getElement(elligibilityBy).getText();
		By selectIdBy = By.xpath("//td[text()='" + lastName + " " + firstName
				+ "']//parent::tr//a[@data-original-title='" + clientId + "']");
		if (getElements(selectIdBy).size() != 0 && elligibilityText.equalsIgnoreCase("DDD")) {
			javaScriptClick(selectIdBy);
			waitForPageToLoad();
			javaScriptClick(consumerMainMenuBy);
			javaScriptClick(ispServicePlanBy);
			waitForPageToLoad();
			sleepTime(2);
			validateISPDateHistoryLink(dp1, filePath, sheetName, ColName, DR);
			validateISPSchedulerLink(dp1, filePath, sheetName, ColName, DR + 1);
			validateISPCoverPageLink(dp1, filePath, sheetName, ColName, DR + 2);
			validateMRALink(dp1, filePath, sheetName, ColName, DR + 3);
			validateAddressBookLink(dp1, filePath, sheetName, ColName, DR + 4);
			validateMedicalCoverageLink(dp1, filePath, sheetName, ColName, DR + 5);
			validateVendorSelectionLink(dp1, filePath, sheetName, ColName, DR + 6);

			validateAliasesLink(dp1, filePath, sheetName, ColName, DR + 7);
			validateBenefitsLink(dp1, filePath, sheetName, ColName, DR + 8);
			validatecaseStatusLink(dp1, filePath, sheetName, ColName, DR + 9);
			validateDemographicsLink(dp1, filePath, sheetName, ColName, DR + 10);
			validateEducationHistoryLink(dp1, filePath, sheetName, ColName, DR + 11);
			validateFosterCareLink(dp1, filePath, sheetName, ColName, DR + 12);
			validateTasklistLink(dp1, filePath, sheetName, ColName, DR + 13);
			validateBehaviorLink(dp1, filePath, sheetName, ColName, DR + 14);
			validateBehaviorLink(dp1, filePath, sheetName, ColName, DR + 15);
			validateDevelopmentLink(dp1, filePath, sheetName, ColName, DR + 16);
			validatehospitalizationLink(dp1, filePath, sheetName, ColName, DR + 17);
			validateMedicalConcernLink(dp1, filePath, sheetName, ColName, DR + 18);
			validatePrenatalLink(dp1, filePath, sheetName, ColName, DR + 19);
			validateBehavioralLink(dp1, filePath, sheetName, ColName, DR + 20);
			validatePlacementResidentLink(dp1, filePath, sheetName, ColName, DR + 21);
			validateProviderNotAvailableLink(dp1, filePath, sheetName, ColName, DR + 22);
			validateProgressNotesLink(dp1, filePath, sheetName, ColName, DR + 23);

		}
		return getDriver();
	}

	// progressNotesById
	public void validateProgressNotesLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(progressNotesById);
		waitForPageToLoad();
		String result;
		String status;

		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Progress Notes")) {
			result = "PROGRESSNOTES LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "PROGRESSNOTES LINK IS NOT WORKING";
			status = "FAIL";
		}
		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}
	

	// providerNotById
	public void validateProviderNotAvailableLink(DataProvider_IN_OUT dp1, String filePath, String sheetName,
			String ColName, int DR) throws Exception {
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(providerNotById);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Provider Not Available")) {
			result = "PROVIDERNOTAVAILABLE LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "PROVIDERNOTAVAILABLE LINK IS NOT WORKING";
			status = "FAIL";
		}
		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	// placementResidentById
	public void validatePlacementResidentLink(DataProvider_IN_OUT dp1, String filePath, String sheetName,
			String ColName, int DR) throws Exception {
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(placementResidentById);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Placement Residence Code History")) {
			result = "PLACEMENTRESIDENT LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "PLACEMENTRESIDENT LINK IS NOT WORKING";
			status = "FAIL";
		}
		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	public void validateBehavioralLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(behavioralById);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Behavioral Health Codes")) {
			result = "BEHAVIORAL LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "BEHAVIORAL LINK IS NOT WORKING";
			status = "FAIL";
		}
		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	// prenatalById
	public void validatePrenatalLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName, int DR)
			throws Exception {
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(prenatalById);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Consumer Prenatal")) {
			result = "PRENATAL LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "PRENATAL LINK IS NOT WORKING";
			status = "FAIL";
		}
		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	public void validateMedicalConcernLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(medicalConcernsById);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Consumer Medical Concerns")) {
			result = "MEDICALCONCERN LIST IS WORKING";
			status = "PASS";
		}

		else {
			result = "MEDICALCONCERN LINK IS NOT WORKING";
			status = "FAIL";
		}
		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	public void validatehospitalizationLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(hospitalizationById);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Hospitalizations/Illnessess")) {
			result = "HOSPITALIZATION LIST IS WORKING";
			status = "PASS";
		}

		else {
			result = "HOSPITALIZATION LINK IS NOT WORKING";
			status = "FAIL";
		}
		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	// validateTasklistLink
	public void validateTasklistLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName, int DR)
			throws Exception {
		
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(taskListById);
		waitForPageToLoad();
		waitForElementToAppear(By.id("ContentPrimary_btnAddTask"));
		System.out.println("TASKLIST LINK IS WORKING");
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, "PASS", ColName, DR);
	}

	// validateBehaviorLink
	public void validateBehaviorLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName, int DR)
			throws Exception {

		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(behaviourById);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Consumer Behavior")) {

			result = "BEHAVIOR IS WORKING";
			status = "PASS";
		}

		else {
			result = "BEHAVIOR LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	// birthHistoryById
	//
	public void validateBirthHistoryLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(birthHistoryById);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Birth History")) {
			result = "BIRTHHISTORY IS WORKING";
			status = "PASS";
		}

		else {
			result = "BIRTHHISTORY LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	// developmentById

	public void validateDevelopmentLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(developmentById);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Development")) {
			result = "DEVELOPMENT LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "DEVELOPMENT LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	public void validateTaskLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName, int DR)
			throws Exception {
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(taskListById);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("ContentPrimary_btnAddTask")).getText().trim().equalsIgnoreCase("View Task Type :")) {

			result = "TASKLIST IS WORKING";
			status = "PASS";
		}

		else {
			result = "TASKLIST LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	public void validateDemographicsLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {
		
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(demegraphicsById);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Consumer Demographics - ICAP Scores")) {

			result = "DEMOGRAPHICS LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "DEMOGRAPHICS LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	public void validateEducationHistoryLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {
		
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(educationalHistoryById);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Education")) {

			result = "EDUCATIONHISTORY LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "EDUCATIONHISTORY LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	// validateFosterCareLink
	public void validateFosterCareLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(fosterCareById);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Foster Care")) {

			result = "FOSTERCARE LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "FOSTERCARE LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	public void validatecaseStatusLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(caseStatusById);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Case Status")) {

			result = "CASESTATUS LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "CASESTATUS LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	public void validateBenefitsLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName, int DR)
			throws Exception {
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(benefitsById);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Benefits/Evaluations/Social Services")) {

			result = "BENEFITS LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "BENEFITS LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	public void validateAliasesLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName, int DR)
			throws Exception {
		
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(aliasesById);
		waitForPageToLoad();

		String result;
		String status;
		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Consumer Aliases")) {
			result = "ALIASES LINK IS WORKING";
			status = "PASS";
		} else {
			result = "ALIASES LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	public void validateVendorSelectionLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {
		javaScriptClick(consumerMainMenuBy);
		waitForPageToLoad();
		javaScriptClick(venSelectionByXpath);
		waitForPageToLoad();
		sleepTime(2);
		By tableCreateAuthorizationByXpath = By
				.xpath("//table[@id='ContentPrimary_dbgAvailableServices']//span[text()='" + CRCommon.getServiceCode()
						+ "       ']//parent::td//parent::tr//a[text()='Create New Authorization']");
		waitForElementToAppear(tableCreateAuthorizationByXpath);
		System.out.println("Vendor slection link is working");
		dp1.WriteVariant(filePath, sheetName, "PASS", ColName, DR);

	}

	public void validateMedicalCoverageLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {
		javaScriptClick(consumerMainMenuBy);
		sleepTime(2);
		javaScriptClick(linkMedicalCoverageByXpath);
		waitForPageToLoad();
		String result;
		String status;
		if (getElement(By.id("lblPage")).getText().trim().equalsIgnoreCase("Medical Coverage")) {
			result = "Medical Coverage LINK IS WORKING";
			status = "PASS";
		} else {
			result = "Medical Coverage LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
	}

	public void validateAddressBookLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {
		javaScriptClick(consumerMainMenuBy);
		sleepTime(2);
		javaScriptClick(addressBookViewContById);
		waitForPageToLoad();
		scrollIntoView(By.id("ContentPrimary_btnPrintAddressBook"));
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, "PASS", ColName, DR);

	}

	public void validateMRALink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName, int DR)
			throws Exception {
		javaScriptClick(consumerMainMenuBy);
		javaScriptClick(ispManagedRiskAgreementById);

		String ispMRAsublink = getElement(ispManagedRiskAgreementSubLinkById).getText();
		String result;
		String status;
		if (ispMRAsublink.equalsIgnoreCase("View Managed Risk Agreements")) {
			result = "MRA LINK IS WORKING";
			status = "PASS";
		} else {
			result = "MRA LINK IS NOT WORKING";
			status = "FAIL";
		}

		waitForPageToLoad();
		System.out.println(result);
		scrollIntoView(ispManagedRiskAgreementCancelById);
		javaScriptClick(ispManagedRiskAgreementCancelById);
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
		waitForPageToLoad();
	}

	public void validateISPCoverPageLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {
		waitForElementToAppear(ispCoverPageById);
		dp1.WriteVariant(filePath, sheetName, "PASS", ColName, DR);
	}

	public void validateISPSchedulerLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {

		javaScriptClick(ispSchedulerById);
		sleepTime(2);
		waitForElementToAppear(By.id("infoSchedule"));
		if (getDriver().findElements(By.id("ispSchedulerHeaderById")).size() == 0)
		{
			javaScriptClick(ispSchedulerById);	
		}

		String ispSchedPopupHeaderText = getElement(ispSchedulerHeaderById).getText();
		String result;
		String status;
		if (ispSchedPopupHeaderText.trim().equalsIgnoreCase("ISP SCHEDULER")) {
			result = "ISP SCHEDULER LINK IS WORKING";
			status = "PASS";
		} else {
			result = "ISP SCHEDULER LINK IS NOT WORKING";
			status = "FAIL";
		}
		System.out.println(result);
		javaScriptClick(ispSchedulerInfoCloseByXpath);
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);

		sleepTime(2);
	}

	public void validateISPDateHistoryLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String ColName,
			int DR) throws Exception {
		String ispStartDate = getElement(ispStartDateValueById).getText();
		javaScriptClick(ispDateHistoryById);

		ArrayList<String> allWindows = new ArrayList<String>(getDriver().getWindowHandles());
		getDriver().switchTo().window(allWindows.get(2));
		waitForPageToLoad();
		scrollIntoView(ispAnnualValueById);

		String annualValue = getElement(ispAnnualValueById).getText();
		String result;
		String status;
		if (ispStartDate.equalsIgnoreCase(annualValue)) {
			result = "ISP DATE HISTORY LINK IS WORKING";
			status = "PASS";
		} else {
			result = "ISP DATE HISTORY LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		dp1.WriteVariant(filePath, sheetName, status, ColName, DR);
		getDriver().close();
		getDriver().switchTo().window(allWindows.get(1));
		sleepTime(2);
	}

	
	// Web 2 End to End links validations
	public void Web2commonlinksnavigationflow(String lastName, String firstName, Map<String, String> data) {
		By svcAuthlinkBy = By.xpath(CRConstants2.SERVICE_AUTHLINK);
		By svcNotiBy = By.xpath(CRConstants2.SERVICE_NOTIFICATIONS);
		By svcDDDBy = By.xpath(CRConstants2.SERVICE_DDD);
		By svcDropDownBy = By.xpath(CRConstants2.SERVICE_DROPDOWN);
		By svcSearchBy = By.xpath(CRConstants2.SERVICE_SEARCH);

		String serviceStr = data.get("SERVICETYPE").trim();
		String trackingNumber = data.get("TRACKINGNUMBER").trim();

		sleepTime(2);
		javaScriptClick(svcAuthlinkBy);
		sleepTime(2);
		windowSwitch();
		waitForPageToLoad();
		javaScriptClick(svcNotiBy);
		sleepTime(2);
		javaScriptClick(svcDDDBy);
		sleepTime(2);
		selectByValue(svcDropDownBy, serviceStr + "         ");
		sleepTime(2);
		javaScriptClick(svcSearchBy);
		sleepTime(2);

		By viewDetailsBy = By.xpath("(//td[text()='" + trackingNumber + "']//parent::tr//td)[2]/a");

		javaScriptClick(viewDetailsBy);
		sleepTime(2);
	}

	public WebDriver doCAWeb2EndToEndLinks(Map<String, String> data, DataProvider_IN_OUT dp1,
			String filePath, String sheetName, String ColName, int DR) throws Exception {

		String lastName = data.get(ExcelColumns.LASTNAME).toUpperCase();
		String firstName = data.get(ExcelColumns.FIRSTNAME).toUpperCase();
		Web2commonlinksnavigationflow(lastName, firstName, data);		
		
		validateServiceAuthlink(dp1, filePath, sheetName, ColName, DR + 5);
		validateMainMenulink(dp1, filePath, sheetName, ColName, DR + 6);
		validateServiceNotilink(dp1, filePath, sheetName, ColName, DR + 7);
		validatePendingAuthsLink(dp1, filePath, sheetName, ColName, DR + 8);
		validateDeclinedRequestsLink(dp1, filePath, sheetName, ColName, DR + 9);
		validateAcknowledgeAuthLink(dp1, filePath, sheetName, ColName, DR + 10);
		validateFinalAuthsLink(dp1, filePath, sheetName, ColName, DR + 11);
		validateWithoutResponsesLink(dp1, filePath, sheetName, ColName, DR + 12);
		
		validateAdminToolslink(dp1, filePath, sheetName, ColName, DR);
		validateIncidentMgmntlink(dp1, filePath, sheetName, ColName, DR + 1);
		validateOlcrTracklinklink(dp1, filePath, sheetName, ColName, DR + 2);
		validateQualifiedVendorlink(dp1, filePath, sheetName, ColName, DR + 3);
		validateVendorRBSlink(dp1, filePath, sheetName, ColName, DR + 4);


		return driver;

	}	
	
	private void validateAdminToolslink(DataProvider_IN_OUT dp1, String filePath, String sheetName,
			String colName, int DR) throws Exception {
		
		javaScriptClick(adminToolslinkByXpath);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("MainContent_lnkAdminTools")).getText().trim().equalsIgnoreCase("ADMIN TOOLS")) {
			
			result = "ADMINTOOLS LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "ADMINTOOLS LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, colName, DR);

	}
	
	private void validateIncidentMgmntlink(DataProvider_IN_OUT dp1, String filePath, String sheetName,
			String colName, int DR) throws Exception {
		
		javaScriptClick(incidentMgmntlinkByXpath);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("MainContent_rptUserApps_lnkUserAppName_0")).getText().trim().equalsIgnoreCase("INCIDENT MANAGEMENT")) {

			result = "INCIDENTMANAGEMENT LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "INCIDENTMANAGEMENT LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, colName, DR);

	}
	
	private void validateOlcrTracklinklink(DataProvider_IN_OUT dp1, String filePath, String sheetName,
			String colName, int DR) throws Exception {
		
		javaScriptClick(olcrTracklinklinkByXpath);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("MainContent_rptUserApps_lnkUserAppName_1")).getText().trim().equalsIgnoreCase("OLCR TRACKING APPLICATION")) {

			result = "OLCRTRACKING LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "OLCRTRACKING LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, colName, DR);

	}
	
	private void validateQualifiedVendorlink(DataProvider_IN_OUT dp1, String filePath, String sheetName,
			String colName, int DR) throws Exception {
		
		javaScriptClick(qualifiedVendorlinkByXpath);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("MainContent_rptUserApps_lnkUserAppName_2")).getText().trim().equalsIgnoreCase("QUALIFIED VENDOR CONTRACT")) {

			result = "QUALIFIEDVENDOR LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "QUALIFIEDVENDOR LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, colName, DR);

	}
	

	private void validateVendorRBSlink(DataProvider_IN_OUT dp1, String filePath, String sheetName,
			String colName, int DR) throws Exception {
		
		javaScriptClick(vendorRBSlinkByXpath);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("MainContent_rptUserApps_lnkUserAppName_4")).getText().trim().equalsIgnoreCase("VENDOR PBS REPORTS")) {

			result = "VENDORRBS LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "VENDORRBS LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, colName, DR);

	}
	
	
	private void validateServiceAuthlink(DataProvider_IN_OUT dp1, String filePath, String sheetName,
			String colName, int DR) throws Exception {
		
		javaScriptClick(serviceAuthlinkByXpath);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("MainContent_rptUserApps_lnkUserAppName_3")).getText().trim().equalsIgnoreCase("SERVICE AUTHORIZATIONS")) {

			result = "SERVICEAUTH LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "SERVICEAUTH LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, colName, DR);

	}
	
	private void validateMainMenulink(DataProvider_IN_OUT dp1, String filePath, String sheetName,
			String colName, int DR) throws Exception {
		
		javaScriptClick(mainMenulinkByXpath);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.xpath("//a[text()='Main Menu']")).getText().trim().equalsIgnoreCase("Main Menu")) {
			
			result = "MAINMENU LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "MAINMENU LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, colName, DR);

	}

	
	private void validateServiceNotilink(DataProvider_IN_OUT dp1, String filePath, String sheetName,
			String colName, int DR) throws Exception {
		
		javaScriptClick(serviceNotilinkByXpath);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("//a[text()='Service Notifications']")).getText().trim().equalsIgnoreCase("Service Notifications")) {

			result = "SERVICENOTIFICATION LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "SERVICENOTIFICATION LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, colName, DR);
	}
	

	private void validatePendingAuthsLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String colName,
			int DR) throws Exception {
		javaScriptClick(pendingAuthlinkByXpath);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("//a[text()='Pending Auths']")).getText().trim().equalsIgnoreCase("Pending Auths")) {

			result = "PENDINGAUTH LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "PENDINGAUTH LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, colName, DR);

	}

	private void validateDeclinedRequestsLink(DataProvider_IN_OUT dp1, String filePath, String sheetName,
			String colName, int DR) throws Exception {
		javaScriptClick(declinedlinkByXpath);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("//a[text()='Declined Requests']")).getText().trim().equalsIgnoreCase("Declined Requests")) {

			result = "DECLINEDREQUESTS LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "DECLINEDREQUESTS LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, colName, DR);
	}

	private void validateAcknowledgeAuthLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String colName,
			int DR) throws Exception {
				
		javaScriptClick(acknowledgelinkByXpath);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("//a[text()='Acknowledge Auths']")).getText().trim().equalsIgnoreCase("Acknowledge Auths")) {

			result = "ACKNOWLEDGEAUTH LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "ACKNOWLEDGEAUTH LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, colName, DR);

	}

	private void validateFinalAuthsLink(DataProvider_IN_OUT dp1, String filePath, String sheetName, String colName,
			int DR) throws Exception {
		javaScriptClick(finalAuthlinkByXpath);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("//a[text()='Final Auths']")).getText().trim().equalsIgnoreCase("Final Auths")) {

			result = "FINALAUTH LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "FINALAUTH LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, colName, DR);

	}

	private void validateWithoutResponsesLink(DataProvider_IN_OUT dp1, String filePath, String sheetName,
			String colName, int DR) throws Exception {
		
		javaScriptClick(withoutResponselinkByXpath);
		waitForPageToLoad();

		String result;
		String status;

		if (getElement(By.id("//a[text()='Service Notifications without responses']")).getText().trim().equalsIgnoreCase("Service Notifications without responses")) {

			result = "WITHOUTRESPONSE LINK IS WORKING";
			status = "PASS";
		}

		else {
			result = "WITHOUTRESPONSE LINK IS NOT WORKING";
			status = "FAIL";
		}

		System.out.println(result);
		waitForPageToLoad();
		dp1.WriteVariant(filePath, sheetName, status, colName, DR);

	}

	public ResponsiblePartyPage doAddConsumersStep(Map<String, String> data) {
		// try {
		String firstNameStr = data.get("CFN");
		String lastNameStr = data.get("CLN");
		String genderStr = data.get("CG");
		String dobStr = data.get("CDOB");

		// sleepTime(3);
		waitForPageToLoad();
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(3);
		javaScriptClick(consumerAdminBy);
		// MaximizeWindow();
		// sleepTime(4);
		javaScriptClick(viewMyConsumerBy);
		// sleepTime(4);
		javaScriptClick(addConsBy);
		sleepTime(2);
		writeText(lastNameBy, lastNameStr);
		writeText(firstNameBy, firstNameStr);
		sleepTime(4);
		click(genderBy);
		// sleepTime(3);
		javaScriptClick(sel_GenderBy);

		if (genderStr.equalsIgnoreCase("M") || genderStr.equalsIgnoreCase("Male")) {
			javaScriptClick(sel_Gender_MaleBy);
		} else if (genderStr.equalsIgnoreCase("F") || genderStr.equalsIgnoreCase("Female")) {
			javaScriptClick(sel_Gender_FemaleBy);
		} else if (genderStr.equalsIgnoreCase("U") || genderStr.equalsIgnoreCase("Unknown")) {
			javaScriptClick(sel_Gender_UnknownBy);
		} else
			throw new RuntimeException("Gender not specified in the Excel file for the Key:Gender");

		// selectByValue(genderBy, genderStr);
		sleepTime(2);
		// clickwithoutWait(dateOfBirthBy);

		System.out.println("dobstr: " + dobStr);
		JavascriptExecutor jse = (JavascriptExecutor) getDriver();
		jse.executeScript("arguments[0].value='" + dobStr.trim() + "';", getDriver().findElement(dateOfBirthBy));
		// writeText(dateOfBirthBy, dobStr);
		// sleepTime(4)

		javaScriptClick(continueBy);
		// sleepTime(4);
		MaximizeWindow();
		waitForPageToLoad();
		sleepTime(4);
		scrollIntoView(addContinueBy);

		if (isElementPresent(duplicateRecordsBy) == true) {
			scrollIntoView(addAndContinueBy);
		}

		// doubleClick(addAndContinueBy);
		sleepTime(2);
		doubleClick(addContinueBy);
		sleepTime(4);
		// waitForPageToLoad(CheckAlertPresent();
		CheckAlertPresent();

		sleepTime(2);
		// waitForElementToClick(popupBy);
		sleepTime(2);
		waitForElementToAppear(By.xpath("//button[@class='btn btn-default']"));
		javaScriptClick(By.xpath("//button[@class='btn btn-default']"));

		// }catch(Exception e) {
		// e.printStackTrace();
		// takeScreenShot(data);8

		// }
		return new ResponsiblePartyPage(getDriver());
	}

	// This is after "Add Service" to click consumer admin -> consumer main menu
	public WebDriver doclientIDForCreateAuthSteps(String clientId, Map<String, String> data) {

		String lastName = data.get(ExcelColumns.LASTNAME).toUpperCase();
		String firstName = data.get(ExcelColumns.FIRSTNAME).toUpperCase();

		waitForPageToLoad();
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(3);
		javaScriptClick(consumerAdminBy);
		javaScriptClick(viewMyConsumerBy);
		waitForPageToLoad();
		javaScriptClick(clientDropBy);
		sleepTime(2);
		waitForPageToLoad();
		By clientBy = By.xpath("//span[text()='" + lastName + " " + firstName + "']");
		int clientSize = getElements(clientBy).size();
		By clientLastIndexBy = By.xpath("(//span[text()='" + lastName + " " + firstName + "'])[" + clientSize + "]");
		scrollIntoView(clientLastIndexBy);
		javaScriptClick(clientLastIndexBy);
		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(myConsumersBy);
		By elligibilityBy = By.xpath("(//td[text()='" + lastName + " " + firstName + "']//parent::tr//td)[4]");
		String elligibilityText = getElement(elligibilityBy).getText();
		By selectIdBy = By.xpath("//td[text()='" + lastName + " " + firstName
				+ "']//parent::tr//a[@data-original-title='" + clientId + "']");
		if (getElements(selectIdBy).size() != 0 && elligibilityText.equalsIgnoreCase("DDD")) {
			javaScriptClick(selectIdBy);
			waitForPageToLoad();
			// javaScriptClick(consumerMainMenuBy);
		}
		return getDriver();

	}

	public String getClientID(String AssistId) {

		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(clientSearchBy);
		waitForPageToLoad();

		System.out.println(getDriver().getTitle());
		windowSwitch();
		sleepTime(3);
		selectByVisibleText(clientNameDropBy, "Assists Id");
		waitForPageToLoad();
		sleepTime(2);
		writeText(clientAssistBy, AssistId);
		waitForPageToLoad();
		javaScriptClick(clientSearchFinalBy);
		waitForPageToLoad();
		String clientId = getElement(By.xpath("(//td[text()='" + AssistId + "']//following::td)[1]")).getText();
		sleepTime(2);
		closeCurrentWindow();
		sleepTime(5);
		navigateToBack();
		sleepTime(5);
		navigateToBack();

		return clientId;
	}

	// The below is DDD Eligibility approval from SC Supervisor
	public void dddeligibilityApp_Steps() {
		// To Match consumer name below
		javaScriptClick(eliDeterRedeterYesBy);
		javaScriptClick(eliDeterRedeterSaveBy);
	}

	public WebDriver clickOn_Supervisor_CA(String clientId) {
		waitForPageToLoad();
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(2);
		javaScriptClick(consumerAdminBy);
		sleepTime(2);
		javaScriptClick(eliDeterRedeterBy);
		waitForPageToLoad();
		By clientIdBy = By.xpath("//a[text()='" + clientId + "']//parent::td//parent::tr//a[text()='Edit']");

		Boolean status = searchClientID(clientId, clientIdBy);
		if (!status) {
			javaScriptClick(secondListBy);
			waitForPageToLoad();
			searchClientID(clientId, clientIdBy);
		}

		sleepTime(3);
		javaScriptClick(eliDeterRedeterYesBy);
		sleepTime(4);
		javaScriptClick(eliDeterRedeterSaveBy);
		String successMsgBy = getElement(eliDeterSuccessMsgBy).getText();
		System.out.println(successMsgBy);
		closeCurrentWindow();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		return getDriver();
	}

	public WebDriver clickOn_Supervisor_ForService(Map<String, String> data, String clientId) {
		String approvedUnitsStr = data.get("APPROVEDUNITS");

		waitForPageToLoad();
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(2);
		javaScriptClick(consumerAdminBy);
		sleepTime(2);
		javaScriptClick(serviceApprovalsById);
		sleepTime(2);
		By editTableByXpath = By.xpath("//a[text()='" + clientId + "']//ancestor::tr//a[text()='Edit']");
		sleepTime(2);
		javaScriptClick(editTableByXpath);
		writeText(serviceApprovedUnitsById, approvedUnitsStr);
		javaScriptClick(serviceAppSaveById);
		waitForPageToLoad();
		closeCurrentWindow();
		navigateToBack();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		return getDriver();
	}

	public boolean searchClientID(String clientId, By clientIdBy) {
		boolean isFound = false;
		List<WebElement> rows = getElements(By.xpath("//table[@id=\"ContentPrimary_dbgEligibilityDates\"]/tbody/tr"));
		for (WebElement row : rows) {
			if (row.findElement(By.cssSelector("td:nth-of-type(1)")).getText().equals(clientId)) {
				isFound = true;
				javaScriptClick(clientIdBy);
				break;
			}
		}
		return isFound;
	}

	public WebDriver ISPPlanCreation(String clientId, Map<String, String> data) {

		String lastName = data.get(ExcelColumns.LASTNAME).toUpperCase();
		String firstName = data.get(ExcelColumns.FIRSTNAME).toUpperCase();

		waitForPageToLoad();
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(2);
		javaScriptClick(consumerAdminBy);
		MaximizeWindow();
		javaScriptClick(viewMyConsumerBy);
		sleepTime(5);
		waitForPageToLoad();

		javaScriptClick(clientDropBy);
		sleepTime(2);
		// javaScriptClick(clientDropBy);
		// sleepTime(2);
		waitForPageToLoad();
		writeText(ispSearchDropBy, lastName + " " + firstName);
		By clientBy = By.xpath("//span[text()='" + lastName + " " + firstName + "']");
		int clientSize = getElements(clientBy).size();
		By clientLastIndexBy = By.xpath("(//span[text()='" + lastName + " " + firstName + "'])[" + clientSize + "]");
		scrollIntoView(clientLastIndexBy);
		javaScriptClick(clientLastIndexBy);
		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(myConsumersBy);

		By elligibilityBy = By.xpath("(//td[text()='" + lastName + " " + firstName + "']//parent::tr//td)[4]");
		String elligibilityText = getElement(elligibilityBy).getText();
		By selectIdBy = By.xpath("//td[text()='" + lastName + " " + firstName
				+ "']//parent::tr//a[@data-original-title='" + clientId + "']");
		if (getElements(selectIdBy).size() != 0 && elligibilityText.equalsIgnoreCase("DDD")) {
			javaScriptClick(selectIdBy);
			waitForPageToLoad();
			javaScriptClick(consumerMainMenuBy);
			javaScriptClick(ispServicePlanBy);
			waitForPageToLoad();
			sleepTime(2);
			javaScriptClick(ispAnnualDateBy);
			javaScriptClick(ispAnnualTodayBy);
			javaScriptClick(ispCreateNewBy);
			isAlertPresent();
			// waitForAlertToAppear();

			// Boolean b=isAlertPresent();
			// if(b==true) {
			// System.out.println("Successfully clicked on alert");
			// }
		} else {
			System.out.println(clientId + " not available");
			throw new RuntimeException(clientId + " you are searching for not available or elligiblity not approved");
		}

		return getDriver();
	}

	public WebDriver supervisor_ServiceSteps(String clientId, Map<String, String> data) {

		String reqUnitsStr = data.get("SRVCEREQUUNITS").trim();

		waitForPageToLoad();
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(2);
		javaScriptClick(consumerAdminBy);
		javaScriptClick(supervisorServiceBy);
		waitForPageToLoad();
		MaximizeWindow();
		By editBy = By.xpath("//a[text()='" + clientId + "']//ancestor::tr//a[text()='Edit']");
		javaScriptClick(editBy);
		waitForPageToLoad();
		writeText(serviceUnitsBy, reqUnitsStr);
		sleepTime(2);
		waitForPageToLoad();
		javaScriptClick(serviceSaveBy);
		closeCurrentWindow();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		return getDriver();

	}

	public WebDriver redeterminationSteps(Map<String, String> data) {

		String lastName = data.get(ExcelColumns.LASTNAME).toUpperCase();
		String firstName = data.get(ExcelColumns.FIRSTNAME).toUpperCase();
		String redeterReason = data.get("REDETREASON").toUpperCase().trim();
		String redeterNotes = data.get("REDETREASONNOTES").toUpperCase().trim();

		waitForPageToLoad();
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(3);
		javaScriptClick(consumerAdminBy);
		javaScriptClick(viewMyConsumerBy);
		waitForPageToLoad();
		javaScriptClick(clientDropBy);
		sleepTime(2);
		waitForPageToLoad();
		writeText(ispSearchDropBy, lastName + " " + firstName);
		By clientBy = By.xpath("//span[text()='" + lastName + " " + firstName + "']");
		int clientSize = getElements(clientBy).size();
		By clientLastIndexBy = By.xpath("(//span[text()='" + lastName + " " + firstName + "'])[" + clientSize + "]");
		scrollIntoView(clientLastIndexBy);
		javaScriptClick(clientLastIndexBy);
		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(myConsumersBy);
		sleepTime(2);
		javaScriptClick(consumerMainMenuBy);
		sleepTime(2);
		javaScriptClick(redetermineEligibilityBy);
		sleepTime(2);
		selectByValue(redetermineReasonBy, redeterReason);
		writeText(redetermineNotesBy, redeterNotes);
		javaScriptClick(redetermineSaveBy);
		closeCurrentWindow();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		return getDriver();
	}
}

//	// This is Vendor initial "Deny request" in Web2
//	public WebDriver doVendorDeclinedStep(Map<String, String> data) {
//		String serviceStr = data.get("SERVICETYPE").trim();
//		String declineReasonStr = data.get("DECLINEDREASON").trim();
//		
//		waitForPageToLoad();
//		click(loginBy);
//		sleepTime(2);
//		javaScriptClick(svcAuthlinkBy);
//		sleepTime(2);
//		javaScriptClick(svcNotiBy);
//		sleepTime(2);
//		javaScriptClick(svcDDDBy);
//		sleepTime(2);
//		selectByValue(svcDropDownBy, serviceStr);
//		sleepTime(2);
//		javaScriptClick(svcSearchBy);
//		sleepTime(2);
//		// Match tracking number in this page and click on "View details"
//		javaScriptClick(svcViewDetailsBy);
//		sleepTime(2);
//		javaScriptClick(serDeclineAuthBy);
//		sleepTime(2);
//		// Here to select drop down value
//		selectByValue(serDeclineReasonDropDownBy, declineReasonStr);
//		javaScriptClick(serDeclineSubmitBy);
//
//		return getDriver();
//	}
//	

// This is first way to give "Vendor responses and authorization" from SC end -
// Web1
//	public WebDriver doSCApprovalFinalAuthPages(Map<String, String> data) {
//
//		waitForPageToLoad();
//		sleepTime(2);
//		javaScriptClick(consumerAdminBy);
//		waitForPageToLoad();		
//		javaScriptClick(viewMyConsumerBy);
//		waitForPageToLoad();
//		javaScriptClick(workerDropBy);
//		waitForPageToLoad();
//		sleepTime(2);
//		javaScriptClick(clientDropBy);
//		waitForPageToLoad();
//		sleepTime(2);
//		// scrollIntoView(workerGenderBy);
//		javaScriptClick(myConsumerBy);
//		// eligiStatusBy
//		javaScriptClick(consumerMainMenuBy);
//		sleepTime(2);
//		javaScriptClick(venSelectionBy);
//		sleepTime(2);
//		javaScriptClick(viewPendingCallsBy);
//		sleepTime(2);
//		//Match tracking number and then click on "Vendor Responses" hyperlink
//		javaScriptClick(serVendorResBy);
//		sleepTime(2);
//		javaScriptClick(serAcceptBy);
//		sleepTime(2);
//		// Take Vendor name
//		javaScriptClick(serContinueBy);
//		sleepTime(2);
//		javaScriptClick(serOfficeBy); // Click radio button by matching Office/ Site location from previous screen - Vendor name
//		sleepTime(2);
//		// javaScriptClick(serAuthBy);
//
//		// Should take Vendor Call Tracking Number to match this number in Web2 actions - Vendor final auth/ acknowledge
//
//		return getDriver();		
//	}		

// Another way to give "Vendor responses and authorization" from SC end -Web1 -
// Consumer Administration -> Vendor Call Queue

/*
 * String AssistIDStr = data.get("ASSIST_ID").trim();
 * 
 * javaScriptClick(consumerAdminBy); waitForPageToLoad();
 * javaScriptClick(scVendorCallQueue); sleepTime(2); writeText(scConsAssistId,
 * AssistIDStr); sleepTime(2); javaScriptClick(scConsSearch); sleepTime(2);
 * //Match tracking number and then click on "Vendor Responses" hyperlink
 * javaScriptClick(serVendorResBy); sleepTime(2); javaScriptClick(serAcceptBy);
 * sleepTime(2); // Take Vendor name javaScriptClick(serContinueBy);
 * sleepTime(2); javaScriptClick(serOfficeBy); // Click radio button by matching
 * Office/ Site location from previous screen - Vendor name sleepTime(2);
 * javaScriptClick(serAuthBy);
 * 
 * 
 * // Should take Vendor Call Tracking Number to match this number in Web2
 * actions - Vendor final auth/ acknowledge
 * 
 * return getDriver(); }
 */

// This is vendor's "Final acknowledgement and Authorization" request in Web2
//	public WebDriver doVendorFinalAcknoAuthStep(Map<String, String> data) {
//
//		waitForPageToLoad();
//		sleepTime(2);
//		javaScriptClick(serAcknowledAuth);
//		sleepTime(2);
//		// Match tracking number from Web1 (SC authorized) and then click on check box
//		javaScriptClick(serCheckBoxBy);
//		sleepTime(2);
//		javaScriptClick(serAcknowBy);
//		sleepTime(2);
//		javaScriptClick(serFinalAuthBy);
//		sleepTime(2);
//		// Fill tracking number in "Vendor Call Tracking ID" field
//		sleepTime(2);
//		javaScriptClick(serAuthSearchBy);
//		sleepTime(2);
//		
//		// Click on ConsumerName from right side search result and match Assist ID, Tracking number, Focus ID then print into console and test data sheet
//        		
//		sleepTime(2);
//		javaScriptClick(serReturnFinalBy);
//		sleepTime(2);
//		return getDriver();		
//		// This is the line where end to end flow is completed for both Web1 and Web2 and close the browsers
//		
//	}
//}
