package pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Constants.CRConstants;
import Constants.CRConstants2;
import Constants.ExcelColumns;
import dataProviders.ConfigFileReader;

public class ClientApplicationPage extends BasePage {

	public WebDriver driver;
	ConfigFileReader reader = new ConfigFileReader();

	By consumerAdminBy = By.xpath(CRConstants.CONSUMER_ADMINISTRATION);
	By viewMyConsumerBy = By.xpath(CRConstants.VIEW_MY_CONSUMERS);
	By clientApplicationBy = By.xpath(CRConstants.CLIENT_APPLICATION);
	By addConsBy = By.xpath(CRConstants.ADD_CONSUMER);
	By lastNameBy = By.xpath(CRConstants.LAST_NAME);
	By firstNameBy = By.xpath(CRConstants.FIRST_NAME);
	// By ssnBy = By.xpath(CRConstants.SSN);
	By genderBy = By.xpath(CRConstants.GENDER);
	By dateOfBirthBy = By.xpath(CRConstants.DATE_OF_BIRTH);
	By continueBy = By.xpath(CRConstants.CONTINUE);
	By addAndContinueBy = By.xpath(CRConstants.ADD_AND_CONTINUE);
	By addContinueBy = By.id("ContentPrimary_dgNewAdd_Linkbutton2_0");
	By popupBy = By.xpath(CRConstants.POPUP);
	By pop1By = By.cssSelector("#myModal > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > button");
	By sel_GenderBy = By.xpath("//div[contains(text(),'SELECT')]");
	By sel_Gender_MaleBy = By.xpath("//span[contains(text(),'Male')]");
	By sel_Gender_FemaleBy = By.xpath("//span[contains(text(),'Female')]");
	By sel_Gender_UnknownBy = By.xpath("//span[contains(text(),'Unknown')]");
	By duplicateRecordsBy = By.id("ContentPrimary_Label4");

	By workerDropBy = By.xpath(CRConstants.ELIGIWORKERDROPDOWN);
	By clientDropBy = By.xpath(CRConstants.ELIGICLIENTDROPDOWN);
	By myConsumerBy = By.xpath(CRConstants.ELIGIMYCONSUMERS);

	By firstListBy = By.xpath("//span[text()='1']");
	By secondListBy = By.xpath("//a[text()='2']");
	By clientSearchBy = By.xpath(CRConstants.CLIENT_SEARCH);
	By clientNameDropBy = By.xpath(CRConstants.CLIENT_SEARCH_NAME_DROPDOWN);
	By clientAssistBy = By.xpath(CRConstants.CLIENT_SEARCH_ASSIST_ID);
	By clientSearchFinalBy = By.xpath(CRConstants.CLIENT_SEARCH_BUTTON);

	By eliDeterRedeterBy = By.xpath(CRConstants.ELIGIDETERREDETER);
	By eliDeterRedeterYesBy = By.xpath(CRConstants.ELIGIYESBUTTON);
	By eliDeterRedeterSaveBy = By.xpath(CRConstants.ELIGIFINALSAVE);
	By eliDeterSuccessMsgBy = By.xpath(CRConstants.ELIGISUCCESSMSG);

	By myConsumersBy = By.xpath(CRConstants.ELIGIMYCONSUMERS);
	By ispSearchDropBy = By.xpath(CRConstants.ISPSEARCHDROP);
	By eligiStatusBy = By.xpath(CRConstants.ELIGISTATUS);
	By consumerMainMenuBy = By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	By ispServicePlanBy = By.xpath(CRConstants.ISPSERVICE);
	By ispAnnualDateBy = By.xpath(CRConstants.ISPANNUALDATE);
	By ispAnnualTodayBy = By.xpath(CRConstants.ISPTODAYDATE);
	By ispCreateNewBy = By.xpath(CRConstants.ISPCREATENEW);
	By ispSuccessMsgBy = By.xpath(CRConstants.ISPSUCCESSFULMSG);

	By supervisorServiceBy = By.xpath(CRConstants.SRVCAPPLINK);
	By serviceUnitsBy = By.xpath(CRConstants.SRVCEREQUUNITS);
	By serviceSaveBy = By.xpath(CRConstants.SRVCESAVE);
	
	
	//  Below variables are from Constants2 in order to finish Web2 end to end flow

	By userNameBy = By.xpath(CRConstants2.USER_NAME2);
	By passwordBy = By.xpath(CRConstants2.PASSWORD2);
	By loginBy = By.xpath(CRConstants2.LOGIN2);
	By svcAuthlinkBy = By.xpath(CRConstants2.SERVICE_AUTHLINK);
	By svcNotiBy = By.xpath(CRConstants2.SERVICE_NOTIFICATIONS);
	By svcDDDBy = By.xpath(CRConstants2.SERVICE_DDD);
	By svcDropDownBy = By.xpath(CRConstants2.SERVICE_DROPDOWN);
	By svcSearchBy = By.xpath(CRConstants2.SERVICE_SEARCH);
	By svcViewDetailsBy = By.xpath(CRConstants2.SERVICE_VIEWDETAILS);
	By svcYesBy = By.xpath(CRConstants2.SERVICE_YES);
	By svcVenLevelBy = By.xpath(CRConstants2.SERVICE_VENDORLEVEL);
	By svcOfficeLevelBy = By.xpath(CRConstants2.SERVICE_OFFICELEVEL);
	By svcSubmitBy = By.xpath(CRConstants2.SERVICE_SUBMIT);
	By svcMainMenuBy = By.xpath(CRConstants2.SERVICE_MAINMENU);
	By svcPendingBy = By.xpath(CRConstants2.SERVICE_PENDING_NOTI);
	By svcDetails2By = By.xpath(CRConstants2.SERVICE_VIEWDETAILS2);
	By svcReturnBy = By.xpath(CRConstants2.SERVICE_RETURN);
	
	
	By venSelectionBy = By.xpath(CRConstants.VSAUTHNEW);
	
	// Below is to find another way to consumer details from Consumer admin -> Vendor call queue with the help of Tracking number
	By scVendorCallQueue = By.xpath(CRConstants2.SC_CONS_VENDOR_CALLQUEUE);
	By scConsAssistId = By.xpath(CRConstants2.SC_CONS_ASSIST_ID);
	By scConsSearch = By.xpath(CRConstants2.SC_CONS_SEARCH);
	
	
   
	    
	

	By svcDeclineBy = By.xpath(CRConstants2.SERVICE_DECLINE);

	By viewPendingCallsBy = By.xpath(CRConstants2.SERVICE_PEDNING_CALLS);
	By serVendorResBy = By.xpath(CRConstants2.SERVICE_VENDOR_RESPPONSE);
	By serAcceptBy = By.xpath(CRConstants2.SERVICE_ACCEPT);
	By serContinueBy = By.xpath(CRConstants2.SERVICE_CONTINUE);
	By serOfficeBy = By.xpath(CRConstants2.SERVICE_OFFICE);
	By serAuthBy = By.xpath(CRConstants2.SERVICE_AUTHORIZE);

	By serAcknowledAuth = By.xpath(CRConstants2.SERVICE_ACKNAUTH);
	By serCheckBoxBy = By.xpath(CRConstants2.SERVICE_CHECKBOX);
	By serAcknowBy = By.xpath(CRConstants2.SERVICE_ACKNOWLEDGE);
	By serFinalAuthBy = By.xpath(CRConstants2.SERVICE_FINALAUTHS);
	By serTrackingBy = By.xpath(CRConstants2.SERVICE_TRACKINGID);
	By serAuthSearchBy = By.xpath(CRConstants2.SERVICE_AUTHSEARCH);
	By serReturnFinalBy = By.xpath(CRConstants2.SERVICE_RETURN_FINAL);

	By serDeclineAuthBy = By.xpath(CRConstants2.SERVICE_DECLINE);
	By serDeclineReasonDropDownBy = By.xpath(CRConstants2.SERVICE_DECLINE_DROPDOWN);
	By serDeclineSubmitBy = By.xpath(CRConstants2.SERVICE_DECLINE_SUBMIT);
	
	private Calendar data;

	public ClientApplicationPage(WebDriver driver) {
		super(driver);
	}
	
	

	public ResponsiblePartyPage doAddConsumersStep(Map<String, String> data) {
		// try {
		String firstNameStr = data.get("CFN");
		String lastNameStr = data.get("CLN");
		String genderStr = data.get("CG");
		String dobStr = data.get("CDOB");

		// sleepTime(3);
		waitForPageToLoad();
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(3);
		javaScriptClick(consumerAdminBy);
		// MaximizeWindow();
		// sleepTime(4);
		javaScriptClick(viewMyConsumerBy);
		// sleepTime(4);
		javaScriptClick(addConsBy);
		sleepTime(2);
		writeText(lastNameBy, lastNameStr);
		writeText(firstNameBy, firstNameStr);
		sleepTime(4);
		click(genderBy);
		// sleepTime(3);
		javaScriptClick(sel_GenderBy);

		if (genderStr.equalsIgnoreCase("M") || genderStr.equalsIgnoreCase("Male")) {
			javaScriptClick(sel_Gender_MaleBy);
		} else if (genderStr.equalsIgnoreCase("F") || genderStr.equalsIgnoreCase("Female")) {
			javaScriptClick(sel_Gender_FemaleBy);
		} else if (genderStr.equalsIgnoreCase("U") || genderStr.equalsIgnoreCase("Unknown")) {
			javaScriptClick(sel_Gender_UnknownBy);
		} else
			throw new RuntimeException("Gender not specified in the Excel file for the Key:Gender");

		// selectByValue(genderBy, genderStr);
		sleepTime(2);
		// clickwithoutWait(dateOfBirthBy);
		System.out.println("dobstr: " + dobStr);
		writeText(dateOfBirthBy, dobStr);
		// sleepTime(4);
		javaScriptClick(continueBy);
		// sleepTime(4);
		MaximizeWindow();
		waitForPageToLoad();
		sleepTime(4);
		scrollIntoView(addContinueBy);

		if (isElementPresent(duplicateRecordsBy) == true) {
			scrollIntoView(addAndContinueBy);
		}

		// doubleClick(addAndContinueBy);
		sleepTime(2);
		doubleClick(addContinueBy);
		sleepTime(4);
		isAlertPresent();

		/*
		 * if(checkAlert()==true) {
		 * 
		 * alert = getDriver().switchTo().alert(); alert.accept(); }
		 */

		// waitForAlertToAppear();
		sleepTime(2);
		waitForElementToClick(popupBy);
		sleepTime(2);
		javaScriptClick(popupBy);

		// }catch(Exception e) {
		// e.printStackTrace();
		// takeScreenShot(data);8

		// }
		return new ResponsiblePartyPage(getDriver());
	}

	public String getClientID(String assistId) {

		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(clientSearchBy);
		waitForPageToLoad();

		System.out.println(getDriver().getTitle());
		windowSwitch();
		sleepTime(3);
		selectByVisibleText(clientNameDropBy, "Assists Id");
		writeText(clientAssistBy, assistId);
		javaScriptClick(clientSearchFinalBy);
		waitForPageToLoad();
		String clientId = getElement(By.xpath("(//td[text()='" + assistId + "']//following::td)[1]")).getText();
		closeCurrentWindow();
		sleepTime(5);
		navigateToBack();
		sleepTime(5);
		navigateToBack();

		return clientId;
	}

	// The below is DDD Eligibility approval from SC Supervisor
	public void dddeligibilityApp_Steps() {
		// To Match consumer name below
		javaScriptClick(eliDeterRedeterYesBy);
		javaScriptClick(eliDeterRedeterSaveBy);
	}

	public WebDriver clickOn_Supervisor_CA(String clientId) {
		waitForPageToLoad();
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(2);
		javaScriptClick(consumerAdminBy);
		sleepTime(2);
		javaScriptClick(eliDeterRedeterBy);
		waitForPageToLoad();
		By clientIdBy = By.xpath("(//a[text()='" + clientId + "']//following::a)[1]");

		Boolean status = searchClientID(clientId, clientIdBy);
		if (!status) {
			javaScriptClick(secondListBy);
			waitForPageToLoad();
			searchClientID(clientId, clientIdBy);

		}
		
//		 if(getElements(clientIdBy).size()!=0) {
//		 javaScriptClick(clientIdBy);
//		 }else {
//
//		 
//		
//		
//		
//		javaScriptClick(secondListBy);
//
//		sleepTime(2);
//		waitForPageToLoad();
//		javaScriptClick(clientIdBy);
//	}

		sleepTime(3);
		javaScriptClick(eliDeterRedeterYesBy);
		sleepTime(4);
		javaScriptClick(eliDeterRedeterSaveBy);
		String successMsgBy = getElement(eliDeterSuccessMsgBy).getText();
		System.out.println(successMsgBy);
		closeCurrentWindow();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		return getDriver();
	}

	public boolean searchClientID(String clientId, By clientIdBy) {
		boolean isFound = false;
		List<WebElement> rows = getElements(By.xpath("//table[@id=\"ContentPrimary_dbgEligibilityDates\"]/tbody/tr"));
		for (WebElement row : rows) {
			if (row.findElement(By.cssSelector("td:nth-of-type(1)")).getText().equals(clientId)) {
				isFound = true;
				javaScriptClick(clientIdBy);
				break;
			}
		}
		return isFound;
	}

	public WebDriver ISPPlanCreation(String clientId, Map<String, String> data) {

		String lastName = data.get(ExcelColumns.LASTNAME).toUpperCase();
		String firstName = data.get(ExcelColumns.FIRSTNAME).toUpperCase();
		
		waitForPageToLoad();
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(2);
		javaScriptClick(consumerAdminBy);
		MaximizeWindow();
		javaScriptClick(viewMyConsumerBy);
		sleepTime(5);
		waitForPageToLoad();

		javaScriptClick(clientDropBy);
		sleepTime(2);
		// javaScriptClick(clientDropBy);
		// sleepTime(2);
		waitForPageToLoad();
		writeText(ispSearchDropBy, lastName + " " + firstName);
		By clientBy = By.xpath("//span[text()='" + lastName + " " + firstName + "']");
		int clientSize = getElements(clientBy).size();
		By clientLastIndexBy = By.xpath("(//span[text()='" + lastName + " " + firstName + "'])[" + clientSize + "]");
		scrollIntoView(clientLastIndexBy);
		javaScriptClick(clientLastIndexBy);
		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(myConsumersBy);

		By elligibilityBy = By.xpath("(//td[text()='" + lastName + " " + firstName + "']//parent::tr//td)[4]");
		String elligibilityText = getElement(elligibilityBy).getText();
		By selectIdBy = By.xpath("//td[text()='" + lastName + " " + firstName
				+ "']//parent::tr//a[@data-original-title='" + clientId + "']");
		if (getElements(selectIdBy).size() != 0 && elligibilityText.equalsIgnoreCase("DDD")) {
			javaScriptClick(selectIdBy);
			waitForPageToLoad();
			javaScriptClick(consumerMainMenuBy);
			javaScriptClick(ispServicePlanBy);
			waitForPageToLoad();
			sleepTime(2);
			javaScriptClick(ispAnnualDateBy);
			javaScriptClick(ispAnnualTodayBy);
			javaScriptClick(ispCreateNewBy);
			isAlertPresent();
			// waitForAlertToAppear();

			// Boolean b=isAlertPresent();
			// if(b==true) {
			// System.out.println("Successfully clicked on alert");
			// }
		} else {
			System.out.println(clientId + " not available");
			throw new RuntimeException(clientId + " you are searching for not available or elligiblity not approved");
		}

		return getDriver();
	}

	
	public WebDriver supervisor_ServiceSteps(String clientId, Map<String, String> data) {
		
		String reqUnitsStr = data.get("SRVCEREQUUNITS").trim();

		waitForPageToLoad();
		javaScriptClick(clientApplicationBy);
		waitForPageToLoad();
		windowSwitch();
		sleepTime(2);
		javaScriptClick(consumerAdminBy);
		javaScriptClick(supervisorServiceBy);
		waitForPageToLoad();
		MaximizeWindow();
		By editBy = By.xpath("//a[text()='" + clientId + "']//ancestor::tr//a[text()='Edit']");
		javaScriptClick(editBy);
		waitForPageToLoad();
		writeText(serviceUnitsBy, reqUnitsStr);
		sleepTime(2);
		waitForPageToLoad();
		javaScriptClick(serviceSaveBy);
		closeCurrentWindow();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		navigateToBack();
		waitForPageToLoad();
		return getDriver();

	}

	
   // This is Vendor initial approve service request in Web2
	public WebDriver doVendorApprovalStep(Map<String, String> data) {
		// String usernameStr = data.get(ExcelColumns.USER_NAME2);
		// String passwordStr = data.get(ExcelColumns.PASSWORD2);
		// String serviceStr = data.get(ExcelColumns.SERVICE);
		// writeText(userNameBy, usernameStr);
		// writeText(passwordBy, passwordStr);
		
		
		String serviceStr = data.get("SERVICETYPE").trim();

		waitForPageToLoad();
		click(loginBy);
		sleepTime(2);
		javaScriptClick(svcAuthlinkBy);
		sleepTime(2);
		javaScriptClick(svcNotiBy);
		sleepTime(2);
		javaScriptClick(svcDDDBy);
		sleepTime(2);
		selectByValue(svcDropDownBy, serviceStr);
		sleepTime(2);
		javaScriptClick(svcSearchBy);
		sleepTime(2);
		// Match tracking number in this page (From "Create authorization" ) 
		// Also take "Vendor Call end date" (This will need to click on Calendar . Click on "View details" hyperlink
		javaScriptClick(svcViewDetailsBy);
		sleepTime(2);
		javaScriptClick(svcYesBy);
		sleepTime(2);
		// javaScriptClick(svcVenLevelBy);
		javaScriptClick(svcOfficeLevelBy);
		sleepTime(2);

		// Should select date from Calendar -This date is 5 days after Vendor call end date
		// Vendor should give response "Estimated start date" after Vendor Call end date

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DATE, 6);
		String newDate = dateFormat.format(cal.getTime());

		javaScriptClick(svcSubmitBy);
		sleepTime(2);
		javaScriptClick(svcMainMenuBy);
		sleepTime(2);
		javaScriptClick(svcPendingBy);
		sleepTime(2);
		// Match tracking number from Web1 and click on "View Details"
		javaScriptClick(svcDetails2By);
		sleepTime(2);
		javaScriptClick(svcReturnBy);
		waitForPageToLoad();

		return getDriver();
	}
	
	

	// This is Vendor initial "Deny request" in Web2
	public WebDriver doVendorDeclinedStep(Map<String, String> data) {
		String serviceStr = data.get("SERVICETYPE").trim();
		String declineReasonStr = data.get("DECLINEDREASON").trim();
		
		waitForPageToLoad();
		click(loginBy);
		sleepTime(2);
		javaScriptClick(svcAuthlinkBy);
		sleepTime(2);
		javaScriptClick(svcNotiBy);
		sleepTime(2);
		javaScriptClick(svcDDDBy);
		sleepTime(2);
		selectByValue(svcDropDownBy, serviceStr);
		sleepTime(2);
		javaScriptClick(svcSearchBy);
		sleepTime(2);
		// Match tracking number in this page and click on "View details"
		javaScriptClick(svcViewDetailsBy);
		sleepTime(2);
		javaScriptClick(serDeclineAuthBy);
		sleepTime(2);
		// Here to select drop down value
		selectByValue(serDeclineReasonDropDownBy, declineReasonStr);
		javaScriptClick(serDeclineSubmitBy);

		return getDriver();
	}

	
	// This is first way to give "Vendor responses and authorization"  from SC end - Web1
	public WebDriver doSCApprovalFinalAuthPages(Map<String, String> data) {

		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(consumerAdminBy);
		waitForPageToLoad();		
		javaScriptClick(viewMyConsumerBy);
		waitForPageToLoad();
		javaScriptClick(workerDropBy);
		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(clientDropBy);
		waitForPageToLoad();
		sleepTime(2);
		// scrollIntoView(workerGenderBy);
		javaScriptClick(myConsumerBy);
		// eligiStatusBy
		javaScriptClick(consumerMainMenuBy);
		sleepTime(2);
		javaScriptClick(venSelectionBy);
		sleepTime(2);
		javaScriptClick(viewPendingCallsBy);
		sleepTime(2);
		//Match tracking number and then click on "Vendor Responses" hyperlink
		javaScriptClick(serVendorResBy);
		sleepTime(2);
		javaScriptClick(serAcceptBy);
		sleepTime(2);
		// Take Vendor name
		javaScriptClick(serContinueBy);
		sleepTime(2);
		javaScriptClick(serOfficeBy); // Click radio button by matching Office/ Site location from previous screen - Vendor name
		sleepTime(2);
		javaScriptClick(serAuthBy);

		// Should take Vendor Call Tracking Number to match this number in Web2 actions - Vendor final auth/ acknowledge

		return getDriver();		
	}
		
		
		
		
		// Another way to give "Vendor responses and authorization" from SC end -Web1 -  Consumer Administration -> Vendor Call Queue
		
	/*		
		String AssistIDStr = data.get("ASSIST_ID").trim();

		javaScriptClick(consumerAdminBy);
		waitForPageToLoad();	
		javaScriptClick(scVendorCallQueue);
		sleepTime(2);
		writeText(scConsAssistId, AssistIDStr);
		sleepTime(2);
		javaScriptClick(scConsSearch);
		sleepTime(2);		
		//Match tracking number and then click on "Vendor Responses" hyperlink
		javaScriptClick(serVendorResBy);
		sleepTime(2);
		javaScriptClick(serAcceptBy);
		sleepTime(2);
		// Take Vendor name
		javaScriptClick(serContinueBy);
		sleepTime(2);
		javaScriptClick(serOfficeBy); // Click radio button by matching Office/ Site location from previous screen - Vendor name
		sleepTime(2);
		javaScriptClick(serAuthBy);
		
		
		// Should take Vendor Call Tracking Number to match this number in Web2 actions - Vendor final auth/ acknowledge
		 
		return getDriver();	
	}
	*/	
	
	
	
    // This is vendor's "Final acknowledgement and Authorization" request in Web2
	public WebDriver doVendorFinalAcknoAuthStep(Map<String, String> data) {

		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(serAcknowledAuth);
		sleepTime(2);
		// Match tracking number from Web1 (SC authorized) and then click on check box
		javaScriptClick(serCheckBoxBy);
		sleepTime(2);
		javaScriptClick(serAcknowBy);
		sleepTime(2);
		javaScriptClick(serFinalAuthBy);
		sleepTime(2);
		// Fill tracking number in "Vendor Call Tracking ID" field
		sleepTime(2);
		javaScriptClick(serAuthSearchBy);
		sleepTime(2);
		
		// Click on ConsumerName from right side search result and match Assist ID, Tracking number, Focus ID then print into console and test data sheet
        		
		sleepTime(2);
		javaScriptClick(serReturnFinalBy);
		sleepTime(2);
		return getDriver();
		
		// This is the line where end to end flow is completed for both Web1 and Web2 and close the browsers
		
	}
}


