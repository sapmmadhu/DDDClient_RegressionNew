package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import dataProviders.ConfigFileReader;
import drivers.CRConstants;

public class ClientApplicationPage extends BasePage {

	public WebDriver driver;
	ConfigFileReader reader = new ConfigFileReader();

	By consumerAdminBy = By.xpath(CRConstants.CONSUMER_ADMINISTRATION);
	By viewMyConsumerBy = By.xpath(CRConstants.VIEW_MY_CONSUMERS);
	By clientApplicationBy = By.xpath(CRConstants.CLIENT_APPLICATION);
	By addConsBy = By.xpath(CRConstants.ADD_CONSUMER);
	By lastNameBy = By.xpath(CRConstants.LAST_NAME);
	By firstNameBy = By.xpath(CRConstants.FIRST_NAME);
	By genderBy = By.xpath(CRConstants.GENDER);
	By dateOfBirthBy = By.xpath(CRConstants.DATE_OF_BIRTH);
	By continueBy = By.xpath(CRConstants.CONTINUE);
	By addAndContinueBy = By.xpath(CRConstants.ADD_AND_CONTINUE);
	By popupBy = By.xpath(CRConstants.POPUP);

	public ClientApplicationPage(WebDriver driver) {
		super(driver);
	}

	public WebDriver addConsumersStep(String firstNameStr, String lastNameStr, String genderStr, String dobStr) {

		sleepTime(3);
		click(clientApplicationBy);
		windowSwitch();
		sleepTime(4);
		click(consumerAdminBy);
		sleepTime(4);
		click(viewMyConsumerBy);
		sleepTime(4);
		javaScriptCLick(addConsBy);
		sleepTime(2);
		writeText(lastNameBy, lastNameStr);
		writeText(firstNameBy, firstNameStr);
		sleepTime(4);
		javaScriptCLick(genderBy);
		selectByValue(genderBy, genderStr);
		sleepTime(2);
		javaScriptCLick(dateOfBirthBy);
		writeText(dateOfBirthBy, dobStr);
		sleepTime(4);
		doubleClick(continueBy);
		sleepTime(4);
		javaScriptCLick(addAndContinueBy);
		waitForAlertToAppear();
		sleepTime(3);		
		
		
		// click(popupBy);

		/*
		 * //reader.getImplicitlyWait(); threadWait(); //this.webEleClick(CA);
		 * this.windowSwitch(); webEleClick(AddConsBy); sendWebElements(LastNameBy,
		 * lastNameStr); sendWebElements(FirstNameBy, firstNameStr); threadWait();
		 * selectByValue(GenderBy, genderStr); waitVisibility(DateOfBirthBy);
		 * sendWebElements(DateOfBirthBy, dobStr); doubleClickEle(ContinueBy);
		 * javaScriptEleCLick(ADD_AND_CONTINUE); waitAlert(); threadWait();
		 * waitClickable(PopupBy);
		 */

		return driver;

	}

}
