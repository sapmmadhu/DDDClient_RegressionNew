package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import Constants.CRConstants;
import Constants.CRConstants2;
import Constants.ExcelColumns;
import dataProviders.ConfigFileReader;

public class VendorApprovalRejectionPages extends BasePage {

	public WebDriver driver;
	public static ConfigFileReader reader = new ConfigFileReader();

	By userNameBy = By.xpath(CRConstants2.USER_NAME2);
	By passwordBy = By.xpath(CRConstants2.PASSWORD2);
	By loginBy = By.xpath(CRConstants2.LOGIN2);
	By svcAuthlinkBy = By.xpath(CRConstants2.SERVICE_AUTHLINK);
	By svcNotiBy = By.xpath(CRConstants2.SERVICE_NOTIFICATIONS);
	By svcDDDBy = By.xpath(CRConstants2.SERVICE_DDD);
	By svcDropDownBy = By.xpath(CRConstants2.SERVICE_DROPDOWN);
	By svcSearchBy = By.xpath(CRConstants2.SERVICE_SEARCH);
	By svcViewDetailsBy = By.xpath(CRConstants2.SERVICE_VIEWDETAILS);
	By svcYesBy = By.xpath(CRConstants2.SERVICE_YES);
	By svcVenLevelBy = By.xpath(CRConstants2.SERVICE_VENDORLEVEL);
	By svcSubmitBy = By.xpath(CRConstants2.SERVICE_SUBMIT);
	By svcPendingBy = By.xpath(CRConstants2.SERVICE_PENDING_NOTI);
	By svcDetails2By = By.xpath(CRConstants2.SERVICE_VIEWDETAILS2);
	By svcReturnBy = By.xpath(CRConstants2.SERVICE_RETURN);

	public VendorApprovalRejectionPages(WebDriver driver) {
		super(driver);
	}

	public VendorApprovalRejectionPages doWeb2LoginStep(Map<String, String> data) {

		//String usernameStr = data.get(ExcelColumns.USER_NAME2);
		//String passwordStr = data.get(ExcelColumns.PASSWORD2);
		//String serviceStr  = data.get(ExcelColumns.SERVICE);
		
		//writeText(userNameBy, usernameStr);
		//writeText(passwordBy, passwordStr);
		
		click(loginBy);
		sleepTime(2);
		javaScriptClick(svcAuthlinkBy);
		sleepTime(2);
		javaScriptClick(svcNotiBy);
		sleepTime(2);
		javaScriptClick(svcDDDBy);
		//selectByValue(serviceDropDownBy, serviceStr);
		javaScriptClick(svcSearchBy);
		sleepTime(2);
		javaScriptClick(svcViewDetailsBy);
		sleepTime(2);
		javaScriptClick(svcYesBy);
		sleepTime(2);
		javaScriptClick(svcVenLevelBy);
		javaScriptClick(svcSubmitBy);
		sleepTime(2);
		javaScriptClick(svcPendingBy);
		sleepTime(2);
		javaScriptClick(svcDetails2By);
		sleepTime(2);
		javaScriptClick(svcReturnBy);
		waitForPageToLoad();		

		return new VendorApprovalRejectionPages(getDriver());
	}	
	
	}


