package pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;

import org.apache.poi.hpsf.Date;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import Constants.CRConstants;
import Constants.CRConstants2;
import Constants.ExcelColumns;
import dataProviders.ConfigFileReader;

public class VendorApprovalRejectionPages extends BasePage {

	public WebDriver driver;
	public static ConfigFileReader reader = new ConfigFileReader();

	By userNameBy = By.xpath(CRConstants2.USER_NAME2);
	By passwordBy = By.xpath(CRConstants2.PASSWORD2);
	By loginBy = By.xpath(CRConstants2.LOGIN2);
	By svcAuthlinkBy = By.xpath(CRConstants2.SERVICE_AUTHLINK);
	By svcNotiBy = By.xpath(CRConstants2.SERVICE_NOTIFICATIONS);
	By svcDDDBy = By.xpath(CRConstants2.SERVICE_DDD);
	By svcDropDownBy = By.xpath(CRConstants2.SERVICE_DROPDOWN);
	By svcSearchBy = By.xpath(CRConstants2.SERVICE_SEARCH);
	By svcViewDetailsBy = By.xpath(CRConstants2.SERVICE_VIEWDETAILS);
	By svcYesBy = By.xpath(CRConstants2.SERVICE_YES);
	By svcVenLevelBy = By.xpath(CRConstants2.SERVICE_VENDORLEVEL);
	By svcOfficeLevelBy = By.xpath(CRConstants2.SERVICE_OFFICELEVEL);
	By svcSubmitBy = By.xpath(CRConstants2.SERVICE_SUBMIT);
	By svcMainMenuBy = By.xpath(CRConstants2.SERVICE_MAINMENU);
	By svcPendingBy = By.xpath(CRConstants2.SERVICE_PENDING_NOTI);
	By svcDetails2By = By.xpath(CRConstants2.SERVICE_VIEWDETAILS2);
	By svcReturnBy = By.xpath(CRConstants2.SERVICE_RETURN);
	
	By svcDeclineBy = By.xpath(CRConstants2.SERVICE_DECLINE);

	public VendorApprovalRejectionPages(WebDriver driver) {
		super(driver);
	}

	public VendorApprovalRejectionPages doWeb2LoginStep(Map<String, String> data) {

		//String usernameStr = data.get(ExcelColumns.USER_NAME2);
		//String passwordStr = data.get(ExcelColumns.PASSWORD2);
		//String serviceStr  = data.get(ExcelColumns.SERVICE);
		
		//writeText(userNameBy, usernameStr);
		//writeText(passwordBy, passwordStr);
		
		click(loginBy);
		sleepTime(2);
		javaScriptClick(svcAuthlinkBy);
		sleepTime(2);
		javaScriptClick(svcNotiBy);
		sleepTime(2);
		javaScriptClick(svcDDDBy);
		//selectByValue(serviceDropDownBy, serviceStr);
		javaScriptClick(svcSearchBy);
		sleepTime(2);
		// Match tracking number in this page and click on "View details"
		javaScriptClick(svcViewDetailsBy);
		sleepTime(2);
		javaScriptClick(svcYesBy);
		sleepTime(2);
		//javaScriptClick(svcVenLevelBy);
		javaScriptClick(svcOfficeLevelBy);
		sleepTime(2);
		// Should select date from Calendar -This date is 5 days after Vendor call close date
		// Vendor should give response within 5 days from current date
		
		
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	    Calendar cal = Calendar.getInstance();
	    //cal.setTime(new Date());
	    cal.add(Calendar.DATE, 2);
	    String newDate = dateFormat.format(cal.getTime());
	    
	    
		
		javaScriptClick(svcSubmitBy);
		sleepTime(2);
		javaScriptClick(svcMainMenuBy);
		sleepTime(2);
		javaScriptClick(svcPendingBy);
		sleepTime(2);
		// Match tracking number from Web1 and click on "View Details"
		javaScriptClick(svcDetails2By);
		sleepTime(2);
		javaScriptClick(svcReturnBy);
		waitForPageToLoad();				
		
		
		// Below is to Deny request from Vendor side
		javaScriptClick(svcDeclineBy);
		sleepTime(2);
		// Here to select drop down value
		
		javaScriptClick(svcSubmitBy);
		sleepTime(2);		
		
		return new VendorApprovalRejectionPages(getDriver());
	}	
	
	}


