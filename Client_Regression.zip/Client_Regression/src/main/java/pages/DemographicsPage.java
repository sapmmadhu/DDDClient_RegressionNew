package pages;

import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import Constants.CRConstants;
import Constants.ExcelColumns;

public class DemographicsPage extends BasePage {

	public WebDriver driver;

	public DemographicsPage(WebDriver driver) {
		super(driver);
	}

	By elligibilityDDButtonBy=By.xpath(CRConstants.ELIGIDDDBUTTON);
	By consumerMainMenuBy = By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	By demoLinkBy = By.xpath(CRConstants.DEMO_LINK);
	By demoLangDropDownby = By.xpath(CRConstants.DEMO_LANGUAGE_DROPDOWN);
	By demoEthniDropDownBy = By.xpath(CRConstants.DEMO_ETHNICITY_DROPDOWN);
	By demoTribeDropDownBy = By.xpath(CRConstants.DEMO_TRIBE_DROPDOWN);
	By demoIncontDropDownBy = By.xpath(CRConstants.DEMO_INCONT_DROPDOWN);
	By demoEmerPlanDropDownBy = By.xpath(CRConstants.DEMO_EMERGENCY_PLAN_DROPDOWN);
	By demoCommentsBy = By.xpath(CRConstants.DEMO_COMMENTS);
	By demoReasonBy = By.xpath(CRConstants.DEMO_REASON);
	By demoSaveBy = By.xpath(CRConstants.DEMO_SAVE);

	public void elementClick(String stringValue) {
		getDriver().findElement(By.xpath("//span[contains(text(),'" + stringValue + "')]")).click();
	}

	public DocumentedDisabilitiesPage doDemographicsSteps(Map<String, String> data) {
		try {
		String languageStr = data.get(ExcelColumns.DEMO_LANGUAGE_DROPDOWN);
		String ethinicityStr = data.get(ExcelColumns.DEMO_ETHNICITY_DROPDOWN);
		String tribeStr = data.get(ExcelColumns.DEMO_TRIBE_DROPDOWN);
		String incontinentStr = data.get(ExcelColumns.DEMO_INCONT_DROPDOWN);
		String emergencyStr = data.get(ExcelColumns.DEMO_EMERGENCY_PLAN_DROPDOWN);
		String commentsStr = data.get(ExcelColumns.DEMO_COMMENTS);

		//sleepTime(4);
		javaScriptClick(consumerMainMenuBy);
		//sleepTime(4);
		javaScriptClick(demoLinkBy);
		//sleepTime(4);
		mouseClick(demoLangDropDownby);
		elementClick(languageStr);
		mouseClick(demoEthniDropDownBy);
		elementClick(ethinicityStr);
		mouseClick(demoTribeDropDownBy);
		elementClick(tribeStr);
		mouseClick(demoIncontDropDownBy);
		getDriver().findElement(By.xpath("//button[@data-id='ContentPrimary_Incontinent_Dropdownlist']//following::div//span[contains(text(),'"
						+ incontinentStr + "')]"))
				.click();
		mouseClick(demoEmerPlanDropDownBy);
		getDriver().findElement(By.xpath("//span[contains(text(),'Emergency Planning:')]//following::div//following::div//span[contains(text(),'"
						+ emergencyStr + "')]"))
				.click();
		//sleepTime(4);
		waitForElementToAppear(demoCommentsBy);
		writeText(demoCommentsBy, commentsStr);
		//sleepTime(4);
		javaScriptClick(demoSaveBy);
		//javaScriptClick(consumerMainMenuBy);
		//sleepTime(2);
		//javaScriptClick(elligibilityDDButtonBy);
		
	}catch(Exception e) {
		e.printStackTrace();
		//takeScreenShot(data);
		
	}
		return new DocumentedDisabilitiesPage(getDriver());
	}
}
