package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import drivers.CRConstants;

public class Demographics_Page extends Base_Page{

	public WebDriver driver;
	
	@FindBy(xpath = CRConstants.CONSUMER_MAIN_MENU) WebElement CONSUMER_MAIN_MENU;
	@FindBy(xpath = CRConstants.DEMOGRAPHICS_LINK) WebElement DEMOGRAPHICS_LINK;
	@FindBy(xpath = CRConstants.LANGUAGE_DROPDOWN) WebElement LANGUAGE_DROPDOWN;
	@FindBy(xpath = CRConstants.ETHNICITY_DROPDOWN) WebElement ETHNICITY_DROPDOWN;
	@FindBy(xpath = CRConstants.TRIBE_DROPDOWN) WebElement TRIBE_DROPDOWN;
	@FindBy(xpath = CRConstants.INCONTINENT_DROPDOWN) WebElement INCONTINENT_DROPDOWN;
	@FindBy(xpath = CRConstants.EMERGENCY_PLAN_DROPDOWN) WebElement EMERGENCY_PLAN_DROPDOWN;
	@FindBy(xpath = CRConstants.COMMENTS) WebElement COMMENTS;
	@FindBy(xpath = CRConstants.REASON) WebElement REASON;
	@FindBy(xpath = CRConstants.DEMO_SAVE) WebElement DEMO_SAVE;
	
	public Demographics_Page(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public void eleClick(String stringValue) {
		driver.findElement(By.xpath("//span[contains(text(),'"+stringValue+"')]")).click();
	}

	public WebDriver demographics_Steps(String languageStr, String ethinicityStr, String tribeStr, String incontinentStr, String emergencyStr, String commentsStr) {
		
		this.webEleClick(CONSUMER_MAIN_MENU);
		this.threadWait();
		this.webEleClick(DEMOGRAPHICS_LINK);
		this.threadWait();
		this.moveToElementActions(LANGUAGE_DROPDOWN);
		this.threadWait();
		this.eleClick(languageStr);		
		this.moveToElementActions(ETHNICITY_DROPDOWN);
		this.eleClick(ethinicityStr);
		this.moveToElementActions(TRIBE_DROPDOWN);
		this.eleClick(tribeStr);
		this.moveToElementActions(INCONTINENT_DROPDOWN);
		driver.findElement(By.xpath("//button[@data-id='ContentPrimary_Incontinent_Dropdownlist']//following::div//span[contains(text(),'"+incontinentStr+"')]")).click();
		this.moveToElementActions(EMERGENCY_PLAN_DROPDOWN);
		WebElement  emergencyWebEle=	driver.findElement(By.xpath("//span[contains(text(),'Emergency Planning:')]//following::div//following::div//span[contains(text(),'"+emergencyStr+"')]"));
		this.doubleClickEle(emergencyWebEle);
		this.threadWait();
		this.sendWebElements(this.returnVisibilityEle(COMMENTS),commentsStr);
		this.threadWait();
		this.webEleClick(this.returnVisibilityEle(DEMO_SAVE));
		this.threadWait();
		return driver;
	}
}
