package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import drivers.CRConstants;

public class Demographics_Page extends Base_Page{

	public WebDriver driver;
	
	By ConsumerMainMenuBy = By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	By DemoLinkBy = By.xpath(CRConstants.DEMO_LINK);
	By DemoLangDropDownby = By.xpath(CRConstants.DEMO_LANGUAGE_DROPDOWN);
	By DemoEthniDropDownBy = By.xpath(CRConstants.DEMO_ETHNICITY_DROPDOWN);
	By DemoTribeDropDownBy = By.xpath(CRConstants.DEMO_TRIBE_DROPDOWN);
	By DemoIncontDropDownBy = By.xpath(CRConstants.DEMO_INCONT_DROPDOWN); 
	By DemoEmerPlanDropDownBy = By.xpath(CRConstants.DEMO_EMERGENCY_PLAN_DROPDOWN);
	By DemoCommentsBy = By.xpath(CRConstants.DEMO_COMMENTS);
	By DemoReasonBy = By.xpath(CRConstants.DEMO_REASON);
	By DemoSaveBy = By.xpath(CRConstants.DEMO_SAVE);
	
		
	public Demographics_Page(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public void eleClick(String stringValue) {
		driver.findElement(By.xpath("//span[contains(text(),'"+stringValue+"')]")).click();
	}

	public WebDriver demographics_Steps(String languageStr, String ethinicityStr, String tribeStr, String incontinentStr, String emergencyStr, String commentsStr) {
		
		   sendWebElements(DemoLangDropDownby, languageStr);
		   sendWebElements(DemoEthniDropDownBy, ethinicityStr);
		   sendWebElements(DemoTribeDropDownBy, tribeStr);
		   sendWebElements(DemoIncontDropDownBy, incontinentStr);
		   sendWebElements(DemoEmerPlanDropDownBy, emergencyStr);
		   sendWebElements(DemoCommentsBy, commentsStr);
		   
		/*
		 * this.moveToElementActions(DEMO_LANGUAGE_DROPDOWN); this.threadWait();
		 * this.eleClick(languageStr);
		 * this.moveToElementActions(DEMO_ETHNICITY_DROPDOWN);
		 * this.eleClick(ethinicityStr); this.moveToElementActions(DEMO_TRIBE_DROPDOWN);
		 * this.eleClick(tribeStr); this.moveToElementActions(DEMO_INCONT_DROPDOWN);
		 * driver.findElement(By.xpath(
		 * "//button[@data-id='ContentPrimary_Incontinent_Dropdownlist']//following::div//span[contains(text(),'"
		 * +incontinentStr+"')]")).click();
		 * this.moveToElementActions(DEMO_EMERGENCY_PLAN_DROPDOWN); WebElement
		 * emergencyWebEle= driver.findElement(By.
		 * xpath("//span[contains(text(),'Emergency Planning:')]//following::div//following::div//span[contains(text(),'"
		 * +emergencyStr+"')]")); this.doubleClickEle(emergencyWebEle);
		 * this.threadWait();
		 * this.sendWebElements(this.returnVisibilityEle(DEMO_COMMENTS),commentsStr);
		 * this.threadWait(); this.webEleClick(this.returnVisibilityEle(DEMO_SAVE));
		 * this.threadWait(); return driver;
		 */
		   return driver;
	}
}
