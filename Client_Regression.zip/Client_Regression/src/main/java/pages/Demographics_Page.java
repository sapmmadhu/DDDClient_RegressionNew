package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import drivers.CRConstants;

public class Demographics_Page extends Base_Page{

	public WebDriver driver;
	
	@FindBy(xpath = CRConstants.CONSUMER_MAIN_MENU) WebElement CONSUMER_MAIN_MENU;
	@FindBy(xpath = CRConstants.DEMO_LINK) WebElement DEMO_LINK;
	@FindBy(xpath = CRConstants.DEMO_LANGUAGE_DROPDOWN) WebElement DEMO_LANGUAGE_DROPDOWN;
	@FindBy(xpath = CRConstants.DEMO_ETHNICITY_DROPDOWN) WebElement DEMO_ETHNICITY_DROPDOWN;
	@FindBy(xpath = CRConstants.DEMO_TRIBE_DROPDOWN) WebElement DEMO_TRIBE_DROPDOWN;
	@FindBy(xpath = CRConstants.DEMO_INCONT_DROPDOWN) WebElement DEMO_INCONT_DROPDOWN;
	@FindBy(xpath = CRConstants.DEMO_EMERGENCY_PLAN_DROPDOWN) WebElement DEMO_EMERGENCY_PLAN_DROPDOWN;
	@FindBy(xpath = CRConstants.DEMO_COMMENTS) WebElement DEMO_COMMENTS;
	@FindBy(xpath = CRConstants.DEMO_REASON) WebElement DEMO_REASON;
	@FindBy(xpath = CRConstants.DEMO_SAVE) WebElement DEMO_SAVE;
	
	public Demographics_Page(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public void eleClick(String stringValue) {
		driver.findElement(By.xpath("//span[contains(text(),'"+stringValue+"')]")).click();
	}

	public WebDriver demographics_Steps(String languageStr, String ethinicityStr, String tribeStr, String incontinentStr, String emergencyStr, String commentsStr) {
		
		this.webEleClick(CONSUMER_MAIN_MENU);
		this.threadWait();
		this.webEleClick(DEMO_LINK);
		this.threadWait();
		this.moveToElementActions(DEMO_LANGUAGE_DROPDOWN);
		this.threadWait();
		this.eleClick(languageStr);		
		this.moveToElementActions(DEMO_ETHNICITY_DROPDOWN);
		this.eleClick(ethinicityStr);
		this.moveToElementActions(DEMO_TRIBE_DROPDOWN);
		this.eleClick(tribeStr);
		this.moveToElementActions(DEMO_INCONT_DROPDOWN);
		driver.findElement(By.xpath("//button[@data-id='ContentPrimary_Incontinent_Dropdownlist']//following::div//span[contains(text(),'"+incontinentStr+"')]")).click();
		this.moveToElementActions(DEMO_EMERGENCY_PLAN_DROPDOWN);
		WebElement  emergencyWebEle=	driver.findElement(By.xpath("//span[contains(text(),'Emergency Planning:')]//following::div//following::div//span[contains(text(),'"+emergencyStr+"')]"));
		this.doubleClickEle(emergencyWebEle);
		this.threadWait();
		this.sendWebElements(this.returnVisibilityEle(DEMO_COMMENTS),commentsStr);
		this.threadWait();
		this.webEleClick(this.returnVisibilityEle(DEMO_SAVE));
		this.threadWait();
		return driver;
	}
}
