package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;

public class ResponsiblePartyPage extends BasePage {

	public WebDriver driver;

	public ResponsiblePartyPage(WebDriver driver) {
		super(driver);
	}

	By rpFirstNameBy = By.xpath(CRConstants.RP_FIRST_NAME);
	By rpLastNameBy = By.xpath(CRConstants.RP_LAST_NAME);
	By rpCheckBoxListBy = By.xpath(CRConstants.CHECK_BOX_LIST);
	By rpHomeCheckBoxBy = By.xpath(CRConstants.HOME_CHECK_BOX);
	By rpAddLineOneBy = By.xpath(CRConstants.ADD_LINE_ONE);
	By rpAddLineTwoBy = By.xpath(CRConstants.ADD_LINE_TWO);
	By rpCityBy = By.xpath(CRConstants.CITY);
	By rpStateBy = By.xpath(CRConstants.STATE);
	By rpZipBy = By.xpath(CRConstants.ZIP);
	By rpHomePhoneBy = By.xpath(CRConstants.HOME_PHONE);
	By rpFooterScrollBy = By.xpath(CRConstants.FOOTER_SCROLL);
	By rpStartDateBy = By.xpath(CRConstants.START_DATE);
	By rpTodayDateBy = By.xpath(CRConstants.TODAY_DATE);
	By rpSaveBy = By.xpath(CRConstants.SAVE);
	By rpUseAsEntBy = By.xpath(CRConstants.USE_AS_ENTERED);
	By rpCloseBy = By.xpath(CRConstants.CLOSE);
	By rpFinalCloseBy = By.xpath(CRConstants.FINAL_CLOSE);

	public WebDriver doAddRPStep(Map<String, String> data) {

		String rpFirstNameStr = data.get("RFN");
		String rpLastNameStr = data.get("RLN");
		String rpSelectBoxStr = data.get("RSB");
		String rpAddlineoneStr = data.get("RA1");
		String rpAddlinetwoStr = data.get("RA2");
		String rpCityStr = data.get("RCTY");
		String rpStateStr = data.get("RS");
		String rpZipStr = data.get("RZ");
		String rpHomePhoneStr = data.get("RHP");

		sleepTime(4);
		writeText(rpFirstNameBy, rpFirstNameStr);
		writeText(rpLastNameBy, rpLastNameStr);
		sleepTime(4);
		elementTobeClickFromList(rpCheckBoxListBy, rpSelectBoxStr);
		sleepTime(4);
		writeText(rpAddLineOneBy, rpAddlineoneStr);
		writeText(rpAddLineTwoBy, rpAddlinetwoStr);
		writeText(rpCityBy, rpCityStr);
		selectByValue(rpStateBy, rpStateStr);
		writeText(rpZipBy, rpZipStr);
		writeText(rpHomePhoneBy, rpHomePhoneStr);
		MaximizeWindow();
		javaScriptCLick(rpFooterScrollBy);
		sleepTime(4);
		waitForElementToAppear(rpStartDateBy);
		javaScriptCLick(rpStartDateBy);
		javaScriptCLick(rpTodayDateBy);
		sleepTime(4);
		waitForElementToAppear(rpSaveBy);
		click(rpSaveBy);
		waitForElementToAppear(rpUseAsEntBy);
		javaScriptCLick(rpUseAsEntBy);
		sleepTime(4);
		javaScriptCLick(rpFinalCloseBy);

		return driver;

	}
}
