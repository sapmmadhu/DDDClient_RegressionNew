package pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;

import org.apache.poi.hpsf.Date;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;

public class ResponsiblePartyPage extends BasePage {

	public WebDriver driver;

	public ResponsiblePartyPage(WebDriver driver) {
		super(driver);
	}

	By rpFirstNameBy = By.xpath(CRConstants.RP_FIRST_NAME);
	By rpLastNameBy = By.xpath(CRConstants.RP_LAST_NAME);
	By rpCheckBoxListBy = By.xpath(CRConstants.CHECK_BOX_LIST);
	By rpHomeCheckBoxBy = By.xpath(CRConstants.HOME_CHECK_BOX);
	By rpAddLineOneBy = By.xpath(CRConstants.ADD_LINE_ONE);
	By rpAddLineTwoBy = By.xpath(CRConstants.ADD_LINE_TWO);
	By rpCityBy = By.xpath(CRConstants.CITY);
	By rpStateBy = By.xpath(CRConstants.STATE);
	By rpZipBy = By.xpath(CRConstants.ZIP);
	By rpHomePhoneBy = By.xpath(CRConstants.HOME_PHONE);
	By rpFooterScrollBy = By.xpath(CRConstants.FOOTER_SCROLL);
	By rpStartDateBy = By.xpath(CRConstants.START_DATE);
	By rpStartDateSelectBy = By.xpath(CRConstants.START_DATE_SELECT);
	By rpTodayDateBy = By.xpath(CRConstants.TODAY_DATE);
	By rpSaveBy = By.xpath(CRConstants.SAVE);
	By rpUseAsEntBy = By.xpath(CRConstants.USE_AS_ENTERED);
	By rpCloseBy = By.xpath(CRConstants.CLOSE);
	By rpFinalCloseBy = By.xpath(CRConstants.FINAL_CLOSE);

	By BB_AA = By.xpath(CRConstants.BB_AA);
	By assistID = By.xpath(CRConstants.ASSIST_ID);
	
	
	
	public String  getAssitID(Map<String, String> data) {
		By assitidBy = By.xpath("//a[@id='aClientCaret']//span[contains(text(),'" + data.get("CLN").toUpperCase() + " "
				+ data.get("CFN").toUpperCase() + "')]");
		
		//a[@id='aClientCaret'], span[contains(text(), '" + data.get("CFN").toUpperCase() + "" + data.get("CLN").toUpperCase() + "')]");
		
		MaximizeWindow();
		//sleepTime(4);
		javaScriptClick(assitidBy);
		return readText(assistID);
		//System.out.println("AssistID============== " + assistID1);
	}

	
	public DemographicsPage doAddRPStep(Map<String, String> data) {
		// try {

		String rpFirstNameStr = data.get("RFN");
		String rpLastNameStr = data.get("RLN");
		String rpSelectBoxStr = data.get("RSB");
		//String rpHomeBoxStr = data.get("RHB");
		String rpAddlineoneStr = data.get("RA1");
		String rpAddlinetwoStr = data.get("RA2");
		String rpCityStr = data.get("RCTY");
		String rpStateStr = data.get("RS");
		String rpZipStr = data.get("RZ");
		String rpHomePhoneStr = data.get("RHP");
		
		
		//sleepTime(4);
		MaximizeWindow();
		writeText(rpFirstNameBy, rpFirstNameStr);
		writeText(rpLastNameBy, rpLastNameStr);
		sleepTime(2);
		javaScriptClick(rpCheckBoxListBy);
		//elementTobeClickFromList(rpCheckBoxListBy, rpSelectBoxStr);
		//sleepTime(4);
		//elementTobeClickFromList(rpHomeCheckBoxBy, rpHomeCheckBoxBy);
		sleepTime(4);
		writeText(rpAddLineOneBy, rpAddlineoneStr);
		writeText(rpAddLineTwoBy, rpAddlinetwoStr);
		writeText(rpCityBy, rpCityStr);
		selectByValue(rpStateBy, rpStateStr);
		writeText(rpZipBy, rpZipStr);
		writeText(rpHomePhoneBy, rpHomePhoneStr);
		//MaximizeWindow();
		//javaScriptClick(rpFooterScrollBy);
		sleepTime(4);
		scrollIntoView(rpStartDateBy);
		sleepTime(2);		
		//waitForElementToAppear(rpStartDateBy);		
		
		javaScriptClick(rpStartDateSelectBy);			
		
		//javaScriptClickWithoutWait(rpStartDateBy);
		//javaScriptClick(rpTodayDateBy);
		//sleepTime(4);
		//waitForElementToAppear(rpSaveBy);
		doubleClick(rpSaveBy);
		sleepTime(4);
		waitForElementToAppear(rpUseAsEntBy);
		sleepTime(2);
		javaScriptClick(rpUseAsEntBy);
		sleepTime(2);
		waitForElementToAppear(rpFinalCloseBy);
		sleepTime(2);
		javaScriptClick(rpFinalCloseBy);

		// }catch(Exception e) {
		// e.printStackTrace();
		// takeScreenShot(data);
		// }
		return new DemographicsPage(getDriver());
		
	}
}
