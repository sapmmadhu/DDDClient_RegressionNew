package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;
import Constants.ExcelColumns;
import dataProviders.ConfigFileReader;

public class LoginPage2 extends BasePage {

	public WebDriver driver;
	public static ConfigFileReader reader = new ConfigFileReader();

	By userNameBy = By.xpath(CRConstants.USER_NAME);
	By passwordBy = By.xpath(CRConstants.PASSWORD);
	By loginBy = By.xpath(CRConstants.LOGIN);

	public LoginPage2(WebDriver driver) {
		super(driver);
	}

	public ClientApplicationPage doLoginStep(Map<String, String> data) {

		String usernameStr = data.get(ExcelColumns.USER_NAME);
		String passwordStr = data.get(ExcelColumns.PASSWORD);
		writeText(userNameBy, usernameStr);
		writeText(passwordBy, passwordStr);
		click(loginBy);

		return new ClientApplicationPage(getDriver());

	}	
	}


