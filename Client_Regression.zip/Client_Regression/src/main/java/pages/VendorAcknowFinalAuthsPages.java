package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import Constants.CRConstants;
import Constants.CRConstants2;
import Constants.ExcelColumns;
import dataProviders.ConfigFileReader;

public class VendorAcknowFinalAuthsPages extends BasePage {

	public WebDriver driver;
	public static ConfigFileReader reader = new ConfigFileReader();

	
	By serAcknowledAuth = By.xpath(CRConstants2.SERVICE_ACKNAUTH);
	By serCheckBoxBy = By.xpath(CRConstants2.SERVICE_CHECKBOX);
	By serAcknowBy = By.xpath(CRConstants2.SERVICE_CHECKBOX);
	By serFinalAuthBy = By.xpath(CRConstants2.SERVICE_FINALAUTHS);
	By serTrackingBy = By.xpath(CRConstants2.SERVICE_TRACKINGID);
	By serAuthSearchBy = By.xpath(CRConstants2.SERVICE_AUTHSEARCH);
	
	
	
	public VendorAcknowFinalAuthsPages(WebDriver driver) {
		super(driver);
	}

	public VendorAcknowFinalAuthsPages doWeb2LoginStep(Map<String, String> data) {	
		
		waitForPageToLoad();
		sleepTime(2);
		javaScriptClick(serAcknowledAuth);
		sleepTime(2);
		// Match tracking number and then click on check box
		javaScriptClick(serCheckBoxBy);
		sleepTime(2);
		javaScriptClick(serAcknowBy);
	    sleepTime(2);
		javaScriptClick(serFinalAuthBy);
		sleepTime(2);
		// Fill tracking number in Vendor Call Tracking ID field 
	    
		
		sleepTime(2);
		javaScriptClick(serAuthSearchBy);
		sleepTime(2);
		
		
		
		return new VendorAcknowFinalAuthsPages(getDriver());
	}	
	
	}


