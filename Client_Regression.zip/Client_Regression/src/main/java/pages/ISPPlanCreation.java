package pages;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Constants.CRConstants;
import Constants.ExcelColumns;

public class ISPPlanCreation extends BasePage{

	public WebDriver driver;

	public ISPPlanCreation(WebDriver driver) {
		super(driver);
	}
	
	By consumerAdminBy = By.xpath(CRConstants.CONSUMER_ADMINISTRATION);
	By viewMyConsumerBy = By.xpath(CRConstants.VIEW_MY_CONSUMERS);
	By myConsumersBy = By.xpath(CRConstants.ELIGIMYCONSUMERS);
	By eligiStatusBy = By.xpath(CRConstants.ELIGISTATUS);	
	By consumerMainMenuBy= By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	By ispServicePlanBy = By.xpath(CRConstants.ISPSERVICE);
	By ispAnnualDateBy = By.xpath(CRConstants.ISPANNUALDATE);
	By ispCreateNewBy = By.xpath(CRConstants.ISPCREATENEW);
	By ispSuccessMsgBy = By.xpath(CRConstants.ISPSUCCESSFULMSG);
	

public ISPPlanCreation doISPSteps() {
		
	javaScriptClick(consumerAdminBy);
	javaScriptClick(viewMyConsumerBy);
	javaScriptClick(myConsumersBy);
	javaScriptClick(consumerMainMenuBy);
	javaScriptClick(ispServicePlanBy);
	sleepTime(2);
	javaScriptClick(ispAnnualDateBy);
	javaScriptClick(ispCreateNewBy);	
	
	return this;	
}





}