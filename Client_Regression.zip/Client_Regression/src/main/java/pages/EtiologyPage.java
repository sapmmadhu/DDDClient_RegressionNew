package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;
import Constants.ExcelColumns;


public class EtiologyPage extends BasePage {

	public WebDriver driver;

	public EtiologyPage(WebDriver driver) {
		super(driver);
	}
	
	
	By consumerMainMenuBy= By.xpath(CRConstants.CONSUMER_MAIN_MENU);
	By etiologyBy = By.xpath(CRConstants.ETI_ETIOLOGY);
	By ETAddBy = By.xpath(CRConstants.ETI_DROPDOWN);
	By ETSaveBy = By.xpath(CRConstants.ETI_SAVE);
	//By ETCancelBy = By.xpath(CRConstants.ETI_CANCEL);
	By ETDeleteBy = By.xpath(CRConstants.ETI_DELETEALL_SUM);
	By ETHistoryBy = By.xpath(CRConstants.ETI_HISTORY); // This will include after delete one Etiology
	
	
	By addSaveBy = By.xpath(CRConstants.DOCSAVE);	// Etiology screen - Save
	
	
	public EtiologyPage doEtiologySteps() {

		//sleepTime(3);
		javaScriptClick(consumerMainMenuBy);
		//sleepTime(2);
		javaScriptClick(etiologyBy);
		//sleepTime(2);
		javaScriptClick(addSaveBy);
			
			return this;
		}

}
