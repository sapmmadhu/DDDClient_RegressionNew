package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Constants.CRConstants;
import Constants.ExcelColumns;

public class LoginPage extends BasePage {

	public WebDriver driver;

	By userNameBy = By.xpath(CRConstants.USER_NAME);
	By passwordBy = By.xpath(CRConstants.PASSWORD);
	By loginBy = By.xpath(CRConstants.LOGIN);

	public LoginPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public ClientApplicationPage doLoginStep(Map<String, String> data) {
		writeText(userNameBy, data.get(ExcelColumns.USER_NAME));
		writeText(passwordBy, data.get(ExcelColumns.PASSWORD));
		click(loginBy);

		return new ClientApplicationPage(getDriver());
	}

}
