package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;
import Constants.ExcelColumns;

public class LoginPage extends BasePage {

	public WebDriver driver;

	By userNameBy = By.xpath(CRConstants.USER_NAME);
	By passwordBy = By.xpath(CRConstants.PASSWORD);
	By loginBy = By.xpath(CRConstants.LOGIN);

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	public ClientApplicationPage doLoginStep(Map<String, String> data) 
	//public ClientApplicationPage doLoginStep()
	{
		 writeText(userNameBy, data.get(ExcelColumns.USER_NAME));
		 writeText(passwordBy, data.get(ExcelColumns.PASSWORD));
		//writeText(userNameBy, System.getProperty("username"));
		//writeText(passwordBy, System.getProperty("password"));
		click(loginBy);

		return new ClientApplicationPage(getDriver());
	}

}
