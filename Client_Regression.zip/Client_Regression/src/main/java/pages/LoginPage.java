package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import drivers.CRConstants;

public class LoginPage extends BasePage {

	public WebDriver driver;

	By userNameBy = By.xpath(CRConstants.USER_NAME);
	By passwordBy = By.xpath(CRConstants.PASSWORD);
	By loginBy = By.xpath(CRConstants.LOGIN);

	public LoginPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public ClientApplicationPage loginStep(String userNameStr, String passwordStr) {

		writeText(userNameBy, userNameStr);
		writeText(passwordBy, passwordStr);
		click(loginBy);
		
		return new ClientApplicationPage(getDriver());
	}
	//public WebDriver getDriver() {
	//	return driver;
	//}
}
