package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;
import Constants.CRConstants2;
import Constants.ExcelColumns;
import dataProviders.ConfigFileReader;

public class LoginPage extends BasePage {

	public WebDriver driver;
	public static ConfigFileReader reader = new ConfigFileReader();

	By userNameBy = By.xpath(CRConstants.USER_NAME);
	By passwordBy = By.xpath(CRConstants.PASSWORD);
	By loginBy = By.xpath(CRConstants.LOGIN);
	
	
	By venuserNameBy = By.xpath(CRConstants2.USER_NAME2);
	By venpasswordBy = By.xpath(CRConstants2.PASSWORD2);
	By venloginBy = By.xpath(CRConstants2.LOGIN2);

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	public ClientApplicationPage doLoginStep(Map<String, String> data) {

		String usernameStr = data.get(ExcelColumns.USER_NAME);
		String passwordStr = data.get(ExcelColumns.PASSWORD);
		writeText(userNameBy, usernameStr);
		writeText(passwordBy, passwordStr);
		click(loginBy);

		return new ClientApplicationPage(getDriver());

	}

	public ClientApplicationPage doLoginStep(String serviceType) {

		String usernameStr = null;
		String passwordStr = null;

		if (serviceType.equalsIgnoreCase("SUPERVISOR")) {
			usernameStr = reader.getSupervisor_Username();
			passwordStr = reader.getSupervisor_Password();

		} else if (serviceType.equalsIgnoreCase("APM")) {
			usernameStr = reader.getAPM_Username();
			passwordStr = reader.getAPM_Password();

		} else if (serviceType.equalsIgnoreCase("DGMT")) {
			usernameStr = reader.getDGMT_Username();
			passwordStr = reader.getDGMT_Password();
			
		} else if (serviceType.equalsIgnoreCase("SC")) {
			usernameStr = reader.getSC_Username();
			passwordStr = reader.getSC_Password();
		}
		
		

		waitForPageToLoad();
		sleepTime(3);
		clear(userNameBy);
		writeText(userNameBy, usernameStr);
		writeText(passwordBy, passwordStr);
		click(loginBy);
		sleepTime(4);
		return new ClientApplicationPage(getDriver());
	}

	public WebDriver doSCLoginStep() {

		String scusernameStr = reader.getSC_Username();
		String scpasswordStr = reader.getSC_Password();
		clear(userNameBy);
		writeText(userNameBy, scusernameStr);
		writeText(passwordBy, scpasswordStr);
		click(loginBy);
		sleepTime(3);
		return getDriver();
	}
	
	
	
		
		public WebDriver doVendorLoginStep() {

		String venusernameStr = reader.getVendorUsername();
		String venpasswordStr = reader.getVendorPassword();
		clear(venuserNameBy);
		writeText(venuserNameBy, venusernameStr);
		writeText(venpasswordBy, venpasswordStr);
		click(venloginBy);
		sleepTime(3);
		
		return getDriver();
	
	}

}
