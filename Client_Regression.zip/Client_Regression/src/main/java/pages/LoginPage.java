package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;
import Constants.ExcelColumns;

public class LoginPage extends BasePage {

	public WebDriver driver;

	By userNameBy = By.xpath(CRConstants.USER_NAME);
	By passwordBy = By.xpath(CRConstants.PASSWORD);
	By loginBy = By.xpath(CRConstants.LOGIN);

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	public ClientApplicationPage doLoginStep(Map<String, String> data) {
		try {
			writeText(userNameBy, data.get(ExcelColumns.USER_NAME));
			writeText(passwordBy, data.get(ExcelColumns.PASSWORD));
			click(loginBy);

		} catch (Exception e) {
			e.printStackTrace();
			takeScreenShot(data);

		}
		return new ClientApplicationPage(getDriver());

	}

}
