package pages;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import Constants.CRConstants;
import Constants.ExcelColumns;
import dataProviders.ConfigFileReader;

public class LoginPage extends BasePage {

	
	//  Below is to fill user data profile for Chrome default profile login	
	
	
	/*
	 * C:\Users\C049604\AppData\Local\Google\Chrome\User Data\Default
	 * C:\Users\C049604\AppData\Local\Google\Chrome\User Data\Profile 1
	 */
	
	// Below is  to set the default driver path along with profile login for the user from local app data
	
	// System.setProperty("webdriver.chrome.driver", "P:\\Selenium\\chromedriver_win32");
	// ChromeOptions options = new ChromeOptions(); 
	// options.addArguments("Profile 1=C:\\Users\\C049604\\AppData\\Local\\Google\\Chrome\\User Data\\Profile 1");
	// options.addArguments("--start-maximized"); 
	// driver = new ChromeDriver(options);



	
	public WebDriver driver;
	public static ConfigFileReader reader= new ConfigFileReader();

	By userNameBy = By.xpath(CRConstants.USER_NAME);
	By passwordBy = By.xpath(CRConstants.PASSWORD);
	By loginBy = By.xpath(CRConstants.LOGIN);

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	public ClientApplicationPage doLoginStep(Map<String, String> data){
				//try {
			writeText(userNameBy, data.get(ExcelColumns.USER_NAME));
			writeText(passwordBy, data.get(ExcelColumns.PASSWORD));
			click(loginBy);

		//} catch (Exception e) {
			//e.printStackTrace();
			//takeScreenShot(data);
		//}
		return new ClientApplicationPage(getDriver());

	}

}
