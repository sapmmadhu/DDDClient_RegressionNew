package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Constants.CRConstants;
import Constants.ExcelColumns;
import dataProviders.ConfigFileReader;

public class LoginPage extends BasePage {

	public WebDriver driver;
	public static ConfigFileReader reader = new ConfigFileReader();

	By userNameBy = By.xpath(CRConstants.USER_NAME);
	By passwordBy = By.xpath(CRConstants.PASSWORD);
	By loginBy = By.xpath(CRConstants.LOGIN);

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	public ClientApplicationPage doLoginStep(Map<String, String> data) {

		String usernameStr = data.get(ExcelColumns.USER_NAME);
		String passwordStr = data.get(ExcelColumns.PASSWORD);
		writeText(userNameBy, usernameStr);
		writeText(passwordBy, passwordStr);
		click(loginBy);

		return new ClientApplicationPage(getDriver());

	}

	public ClientApplicationPage doLoginStep() {

		String usernameStr = reader.getSupervisor_Username();
		String passwordStr = reader.getSupervisor_Password();
		writeText(userNameBy, usernameStr);
		writeText(passwordBy, passwordStr);
		click(loginBy);
		sleepTime(4);
		return new ClientApplicationPage(getDriver());
	}
	
	
	public ClientApplicationPage doSCLoginStep() {

		String scusernameStr = reader.getSC_Username();
		String scpasswordStr = reader.getSC_Password();
		writeText(userNameBy, scusernameStr);
		writeText(passwordBy, scpasswordStr);
		click(loginBy);
		sleepTime(3);
		return new ClientApplicationPage(getDriver());
	}
	

}
