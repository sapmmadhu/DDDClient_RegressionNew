package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import dataProviders.ConfigFileReader;
import Constants.CRConstants2;

	public class VendorLoginPage extends BasePage {


		public VendorLoginPage(WebDriver driver) {
			super(driver);
	
		}


		public WebDriver driver;
		public static ConfigFileReader reader = new ConfigFileReader();
		
		
		By venuserNameBy = By.xpath(CRConstants2.USER_NAME2);
		By venpasswordBy = By.xpath(CRConstants2.PASSWORD2);
		By venloginBy = By.xpath(CRConstants2.LOGIN2);
		
		
		public VendorLoginPage doVendorLoginStep() {

			String venusernameStr = reader.getVendorUsername();
			String venpasswordStr = reader.getVendorPassword();
			clear(venuserNameBy);
			writeText(venuserNameBy, venusernameStr);
			writeText(venpasswordBy, venpasswordStr);
			click(venloginBy);
			sleepTime(3);
			return new VendorLoginPage(getDriver());
		}

	}


