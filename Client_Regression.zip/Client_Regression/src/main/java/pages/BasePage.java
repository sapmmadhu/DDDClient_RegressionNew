package pages;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import dataProviders.ConfigFileReader;

public class BasePage {
	public WebDriver driver;
	public WebDriverWait wait;
	public Select select;
	public Actions actions;
	public Alert alert;
	static final int TIMEOUT = 40;
	static final int POLLING =100;
	ConfigFileReader reader= new ConfigFileReader();

	// Constructor
	public BasePage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, TIMEOUT, POLLING);
		PageFactory.initElements(driver, this);
	}

	// Wait for element to appearhigh
	public void waitForElementToAppear(By elementBy) {
		waitForPageToLoad();
		wait.until(ExpectedConditions.visibilityOfElementLocated(elementBy));
		highLightElement(elementBy);
	};

	// Wait for element to be clickable
	public void waitForElementToClick(By elementBy) {
		waitForPageToLoad();
		wait.until(ExpectedConditions.elementToBeClickable(elementBy));
		highLightElement(elementBy);

	}
	
	public void MaximizeWindow() {
		driver.manage().window().maximize();
	}

	// Wait for alert to appear
	public void waitForAlertToAppear() {
		waitForPageToLoad();
		alert = wait.until(ExpectedConditions.alertIsPresent());
		if (alert != null) {
		isAlertPresent();
		}
	}

	// Check alert present
	public boolean isAlertPresent() {
		boolean presentFlag = false;
		try {
			alert = driver.switchTo().alert();
			presentFlag = true;
			alert.accept();
		} catch (NoAlertPresentException ex) {
			ex.printStackTrace();
		}
		return presentFlag;
	}
	public boolean checkAlert() {
		//WebDriverWait wait = new WebDriverWait(driver, 300 /*timeout in seconds*/);
		if(wait.until(ExpectedConditions.alertIsPresent())==null) {
		    System.out.println("alert was not present");
		return false;
		}else {
		    System.out.println("alert was present");
		return true;}
	}

	// click
	public void click(By elementBy) {
		waitForPageToLoad();
		//waitForElementToClick(elementBy);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].click();", driver.findElement(elementBy));
		//driver.findElement(elementBy).click();
	}
	
	public void clickwithoutWait(By elementBy) {
		//waitForElementToClick(elementBy);
		//JavascriptExecutor jse = (JavascriptExecutor) driver;
		//jse.executeScript("arguments[0].click();", driver.findElement(elementBy));
		driver.findElement(elementBy).click();
	}
	public void clear(By elementBy) {
		driver.findElement(elementBy).clear();
	}
	

	public void mouseClick(By elementBy) {
		actions = new Actions(driver);
		actions.moveToElement(driver.findElement(elementBy)).click().build().perform();
	}
	
	// Double click
	public void doubleClick(By elementBy) {
		waitForElementToAppear(elementBy);
		waitForElementToClick(elementBy);
		actions = new Actions(driver);
		actions.doubleClick(driver.findElement(elementBy)).perform();
	}

	// Write text
	public void writeText(By elementBy, String text) {
		waitForPageToLoad();
		//waitForElementToAppear(elementBy);
		//driver.findElement(elementBy).clear();
		highLightElement(elementBy);
		driver.findElement(elementBy).sendKeys(text);
	}

	// Read text
	public String readText(By elementBy) {
		waitForElementToAppear(elementBy);
		return driver.findElement(elementBy).getText();
	}
	
	public void navigateToBack() {
		waitForPageToLoad();
		JavascriptExecutor js = (JavascriptExecutor)driver;
	    js.executeScript("window.history.back();");
	}

	// Get element
	public WebElement getElement(By elementBy) {
		waitForElementToAppear(elementBy);
		return driver.findElement(elementBy);
	}

	// Get elements
	public List<WebElement> getElements(By elementBy) {
		waitForElementToAppear(elementBy);
		return driver.findElements(elementBy);
	}

	// Select by visible text
	public void selectByVisibleText(By elementBy, String value) {
		waitForElementToAppear(elementBy);
		select = new Select(driver.findElement(elementBy));
		select.selectByVisibleText(value);
	}

	// Select by value
	public void selectByValue(By elementBy, String value) {
		waitForElementToAppear(elementBy);
		select = new Select(driver.findElement(elementBy));
		select.selectByValue(value);
	}

	// Get select value
	public String getSelectedValue(By elementBy) {
		waitForElementToAppear(elementBy);
		Select select = new Select(driver.findElement(elementBy));
		return select.getFirstSelectedOption().getText();
	}

	// Element to be click from the list
	public void elementTobeClickFromList(By elementBy, String value) {
		List<WebElement> checkBoxes = getElements(elementBy);
		for (WebElement boxes : checkBoxes) {
			String textValues = boxes.getText();
			if (textValues.contains(value)) {
				boxes.click();
				break;
			} else
				throw new RuntimeException(value + " is not available in the list");
		}

	}

	// JavaScript click
	public void javaScriptClick(By elementBy) {
		waitForElementToAppear(elementBy);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].click();", driver.findElement(elementBy));
	}
	
	// JavaScript click
		public void javaScriptClick(WebElement ele) {
			//waitForElementToAppear(elementBy);
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].click();", ele);
		}

	public void javaScriptClickWithoutWait(By elementBy) {
		//waitForElementToAppear(elementBy);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].click();", driver.findElement(elementBy));
	}
	// Scroll into view
	public void scrollIntoView(By elementBy) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(elementBy));
	}

	// Scroll page
	public void scroll() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,450)", "");
	}

	
	public void keysEnter(By elementBy) {
	driver.findElement(elementBy).sendKeys(Keys.TAB);
	}
	
	
	
	// Thread wait
	public void sleepTime(int seconds) {
		try {
			Thread.sleep(1000 * seconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// Wait for page ro load
	public void waitForPageToLoad() {
		sleepTime(1);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String state = (String) js.executeScript("return document.readyState");

		while (!state.equals("complete")) {
			sleepTime(2);
			state = (String) js.executeScript("return document.readyState");
		}
	}

	// Convert date
	public String convertDate(String inputdate) {
		System.out.println("input date" + inputdate);
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		Date date = null;
		try {
			System.out.println("input date in concert date****" + inputdate);
			date = new SimpleDateFormat("MM/dd/yyyy").parse(inputdate);
			System.out.println("Date in concert date****" + date);
		} catch (Exception e) {
			e.getMessage();
		}
		return df.format(date);

	}

	// Get Screenshot
	public void takeScreenShot(Map<String,String> data ) {
		// Date d = new Date();
		// String screenshotFile = d.toString().replace(":", "_").replace(" ", "_") +
		// ".png";
		String data1= data.get("TCN");
		System.out.println("TCN Number "+ data1);
	 String filePath = reader.getScreenShotFilePath()+data1+".png";
	 //File file= new File(filePath);
	 
		// store screenshot in that file
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		try {
			//if(!file.exists()) {
			//	 file.createNewFile();
			// }
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void windowSwitch() {
		String currentHandle = driver.getWindowHandle();
		Set<String> handles = driver.getWindowHandles();
		for (String handle : handles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}
	}
	
	public void closeCurrentWindow() {
//		String homeWindow = driver.getWindowHandle();
//		Set<String> allWindows = driver.getWindowHandles();
//		Iterator<String> windowIterator =  allWindows.iterator();
//		 String childWindow=null;
//		while(windowIterator.hasNext())
//		{
//		     childWindow = windowIterator.next();
//		}
//
//		if (homeWindow.equals(childWindow))
//		{
//		    driver.switchTo().window(childWindow);
//		    driver.close();
//		}
//		else {
//			driver.switchTo().window(homeWindow);
//		}
		  Set<String> handlesSet = driver.getWindowHandles();
	        List<String> handlesList = new ArrayList<String>(handlesSet);
	        driver.switchTo().window(handlesList.get(1));
	        driver.close();
	        driver.switchTo().window(handlesList.get(0));
	}
	
	public  boolean isElementPresent(By elementBy) {
		WebElement element=driver.findElement(elementBy);
		boolean isPresent = false;
		//try {
			if(element.isEnabled()&&element.isDisplayed()) {
				isPresent = true;	
			}
			System.out.println(element+"...is present...>>>"+isPresent);
			return isPresent;
			
//		} catch (Exception e) {
//			e.printStackTrace();			
//			System.out.println(element+"...is present...>>>"+isPresent);
//			return isPresent;
//		}     
	}
	
	public String currentDate() {
		Date date= new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy"); 
		return formatter.format(date);
		
	}
	
	
	public void highLightElement(By elementBy) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement element = driver.findElement(elementBy);
     
        js.executeScript("arguments[0].setAttribute('style','border: 5px solid red;');", element);
        sleepTime(2);
        js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
        //js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
        //js.executeScript("arguments[0].setAttribute('style', 'background: yellow;');", element);
    }
	
	
	public WebDriver getDriver() {
		return driver;
	}
}
