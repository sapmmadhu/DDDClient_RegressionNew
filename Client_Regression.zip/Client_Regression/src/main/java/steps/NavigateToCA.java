package steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import dataProviders.ConfigFileReader;
import drivers.SetupDriver;
import pages.ClientApplication_Page;
import pages.Login_Page;

public class NavigateToCA {

	public WebDriver driver;
	
	//Below are to navigate to URL, Login Page, Client application page
	NavigateToURL nav_URL;
	Login_Page lp;
	ClientApplication_Page CAP;

	SetupDriver setupDriver;
	ConfigFileReader configFileReader;
	
	public NavigateToCA(WebDriver driver) {
		 this.driver=driver;
	 }
	
	
	// Add consumer screen details after login page into client application
	public WebDriver CASteps(String userName, String password, String firstName, String lastName, String gender, String dob) {
		nav_URL= new NavigateToURL(driver);
		driver=nav_URL.getAppURL();
		
		lp= new Login_Page(driver);
		driver=lp.loginStep(userName, password);
		
	//	CAP= new ClientApplication_Page(driver);
		//CAP.addConsumersStep(firstName, lastName, gender, dob);		
		return driver;		
	}
}
