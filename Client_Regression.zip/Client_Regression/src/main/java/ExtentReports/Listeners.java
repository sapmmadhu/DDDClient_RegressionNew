package ExtentReports;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import drivers.Screenshot;

public class Listeners implements ITestListener {
	ExtentReports extent = ExtentReporterNG.extentReportGenerator();
	ExtentTest test;
	private static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<ExtentTest>();

	@Override
	public void onFinish(ITestContext arg0) {
		// TODO Auto-generated method stub
		extent.flush();

	}

	@Override
	public void onStart(ITestContext arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestFailure(ITestResult result) {

		extentTest.get().fail(result.getThrowable());
		Object testObject = result.getInstance();
		Class clazz = result.getTestClass().getRealClass();
		WebDriver driver = null;
		try {
			// driver = (WebDriver) clazz.getDeclaredField("driver").get(testObject);
			driver = (WebDriver) result.getTestContext().getAttribute("WebDriver");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			extentTest.get().addScreenCaptureFromPath(
					Screenshot.captureScreen(driver, driver.getTitle(), result.getMethod().getMethodName(), "Email"),
					result.getMethod().getMethodName());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Override
	public void onTestSkipped(ITestResult arg0) {

	}

	@Override
	public void onTestStart(ITestResult result) {
		test = extent.createTest(
				result.getMethod().getMethodName() + " || Iteration - " + result.getTestContext().getAttribute("DataSet"));
		extentTest.set(test);
	}

	@Override
	public void onTestSuccess(ITestResult arg0) {
		extentTest.get().log(Status.PASS, "Success");
	}

	public static void info(String message) {
		extentTest.get().log(Status.INFO, message);
	}

	public static void warn(String message) {
		extentTest.get().log(Status.WARNING, message);
	}

	public static void error(String message) {
		extentTest.get().log(Status.ERROR, message);
	}

	public static void fatal(String message) {
		extentTest.get().log(Status.FATAL, message);
	}

	public static void debug(String message) {
		extentTest.get().log(Status.DEBUG, message);
	}

}
