package dataProviders;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ConfigFileReader {
	private Properties properties;
	private final String propertyFilePath = "src//test//resources//configs//Configuration.properties";

	public ConfigFileReader() {
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(propertyFilePath));
			properties = new Properties();
			try {
				properties.load(reader);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			throw new RuntimeException("Properties file not found at path : " + propertyFilePath);
		} finally {
			try {
				if (reader != null)
					reader.close();
			} catch (IOException ignore) {
			}
		}
	}

	public String getExcelSheetFilePath() {
		String excelFilePath = properties.getProperty("excelFilePath");
		if (excelFilePath != null)
			return excelFilePath;
		else
			throw new RuntimeException(
					"excel File Path not specified in the Configuration.properties file for the Key:driverPath");
	}

	public String getExcelSheetName() {
		String excelSheetName = properties.getProperty("sheetName");
		if (excelSheetName != null)
			return excelSheetName;
		else
			throw new RuntimeException(
					"eexcel Sheet Name not specified in the Configuration.properties file for the Key:driverPath");
	}

	public String getSupervisor_Username() {
		String excelFilePath = properties.getProperty("supervisor_username");
		if (excelFilePath != null)
			return excelFilePath;
		else
			throw new RuntimeException(
					"supervisor_username not specified in the Configuration.properties file for the Key:driverPath");
	}

	public String getSupervisor_Password() {
		String excelFilePath = properties.getProperty("supervisor_password");
		if (excelFilePath != null)
			return excelFilePath;
		else
			throw new RuntimeException(
					"supervisor_password not specified in the Configuration.properties file for the Key:driverPath");
	}

	
	// SC Worker
	public String getSC_Username() {
		String excelFilePath = properties.getProperty("SC_Username");
		if (excelFilePath != null)
			return excelFilePath;
		else
			throw new RuntimeException(
					"SC_Username not specified in the Configuration.properties file for the Key:driverPath");
	}

	public String getSC_Password() {
		String excelFilePath = properties.getProperty("SC_Password");
		if (excelFilePath != null)
			return excelFilePath;
		else
			throw new RuntimeException(
					"SC_Password not specified in the Configuration.properties file for the Key:driverPath");
	}
	
	
	
	// Vendor Login page
		public String getVendorUsername() {
			String excelFilePath = properties.getProperty("USER_NAME2");
			if (excelFilePath != null)
				return excelFilePath;
			else
				throw new RuntimeException(
						"USER_NAME2 not specified in the Configuration.properties file for the Key:driverPath");
		}

		public String getVendorPassword() {
			String excelFilePath = properties.getProperty("PASSWORD2");
			if (excelFilePath != null)
				return excelFilePath;
			else
				throw new RuntimeException(
						"PASSWORD2 not specified in the Configuration.properties file for the Key:driverPath");
		}
		
		
		
		
		

	// APM
	public String getAPM_Username() {
		String excelFilePath = properties.getProperty("APM_Username");
		if (excelFilePath != null)
			return excelFilePath;
		else
			throw new RuntimeException(
					"APM_Username not specified in the Configuration.properties file for the Key:driverPath");
	}

	public String getAPM_Password() {
		String excelFilePath = properties.getProperty("APM_Password");
		if (excelFilePath != null)
			return excelFilePath;
		else
			throw new RuntimeException(
					"APM_Password not specified in the Configuration.properties file for the Key:driverPath");
	}

	// DGMT
	public String getDGMT_Username() {
		String excelFilePath = properties.getProperty("DGMT_Username");
		if (excelFilePath != null)
			return excelFilePath;
		else
			throw new RuntimeException(
					"DGMT_Username not specified in the Configuration.properties file for the Key:driverPath");
	}

	public String getDGMT_Password() {
		String excelFilePath = properties.getProperty("DGMT_Password");
		if (excelFilePath != null)
			return excelFilePath;
		else
			throw new RuntimeException(
					"DGMT_Password not specified in the Configuration.properties file for the Key:driverPath");
	}

	public String getDriverPath() {
		String driverPath = properties.getProperty("driverPath");
		if (driverPath != null)
			return driverPath;
		else
			throw new RuntimeException(
					"Driver Path not specified in the Configuration.properties file for the Key:driverPath");
	}

	public long getImplicitlyWait() {
		String implicitlyWait = properties.getProperty("implicitlyWait");
		if (implicitlyWait != null) {
			try {
				return Long.parseLong(implicitlyWait);
			} catch (NumberFormatException e) {
				throw new RuntimeException("Not able to parse value : " + implicitlyWait + " in to Long");
			}
		}
		return 30;
	}

	public String getApplicationUrl() {
		String url = properties.getProperty("url");
		if (url != null)
			return url;
		else
			throw new RuntimeException(
					"Application Url not specified in the Configuration.properties file for the Key:url");
	}

	public String getScreenShotFilePath() {
		String url = properties.getProperty("screenShotFilePath");
		if (url != null)
			return url;
		else
			throw new RuntimeException(
					"screenShot file path not specified in the Configuration.properties file for the Key:url");
	}

	public String getBroswerName() {
		String browser = properties.getProperty("browser");
		return browser;
	}

	public Boolean getBrowserWindowSize() {
		String windowSize = properties.getProperty("windowMaximize");
		if (windowSize != null)
			return Boolean.valueOf(windowSize);
		return true;
	}

	public String getTestDataResourcePath() {
		String testDataResourcePath = properties.getProperty("testDataResourcePath");
		if (testDataResourcePath != null)
			return testDataResourcePath;
		else
			throw new RuntimeException(
					"Test Data Resource Path not specified in the Configuration.properties file for the Key:testDataResourcePath");
	}

	public String getReportConfigPath() {
		String reportConfigPath = properties.getProperty("reportConfigPath");
		if (reportConfigPath != null)
			return reportConfigPath;
		else
			throw new RuntimeException(
					"Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");
	}

}
