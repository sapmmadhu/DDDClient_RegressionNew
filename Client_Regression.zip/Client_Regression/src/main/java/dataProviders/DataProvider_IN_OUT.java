package dataProviders;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class DataProvider_IN_OUT {

	public int col_num;
	public static XSSFWorkbook workbook;
	public static Sheet worksheet;
	public static DataFormatter formatter = new DataFormatter();

	static ConfigFileReader reader = new ConfigFileReader();
	static String SheetFilePath = reader.getExcelSheetFilePath();
	// static String sheetName = reader.getExcelSheetName();

	@DataProvider
	public static Object[][] ReadVariant(Method m) throws IOException {
		FileInputStream fileInputStream = new FileInputStream(SheetFilePath);
		workbook = new XSSFWorkbook(fileInputStream);
		worksheet = workbook.getSheet(m.getName());
		Row row = worksheet.getRow(0);

		int RowNum = worksheet.getPhysicalNumberOfRows();
		int ColNum = row.getLastCellNum();

		Object Data[][] = new Object[RowNum - 1][ColNum];

		for (int i = 0; i < RowNum - 1; i++) {
			row = worksheet.getRow(i + 1);

			for (int j = 0; j < ColNum; j++) {
				if (row == null)
					Data[i][j] = "";
				else {
					Cell cell = row.getCell(j);
					if (cell == null)
						Data[i][j] = "";
					else {
						String value = formatter.formatCellValue(cell);
						Data[i][j] = value;
					}
				}
			}
		}

		return Data;
	}

	public void WriteVariant(String fileName, String sheetName, String Ress, String ColName, int DR) throws Exception {

		File file = new File(fileName);
		FileInputStream inputStream = new FileInputStream(file);
		Workbook workbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if (fileExtensionName.equals(".xlsx")) {
			workbook = new XSSFWorkbook(inputStream);
		} else if (fileExtensionName.equals(".xls")) {
			workbook = new HSSFWorkbook(inputStream);
		}
		Sheet sheet = workbook.getSheet(sheetName);
		Row row = sheet.getRow(0);

		int sheetIndex = workbook.getSheetIndex(sheetName);
		CellStyle style = workbook.createCellStyle();
		style.setAlignment(HorizontalAlignment.CENTER);
		style.setBorderBottom(BorderStyle.THIN);
		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		Font font = workbook.createFont();
		font.setBold(true);
		DataFormatter formatter = new DataFormatter();
		if (sheetIndex == -1) {
			System.out.println("No such sheet in file exists");
		} else {
			col_num = -1;
			for (int i = 0; i < row.getLastCellNum(); i++) {
				Cell cols = row.getCell(i);
				String colsval = formatter.formatCellValue(cols);
				if (colsval.trim().equalsIgnoreCase(ColName.trim())) {
					col_num = i;
					break;
				}

			}
			row = sheet.getRow(DR);
			try {
				Cell cell = sheet.getRow(DR).getCell(col_num);
				if (cell == null) {
					cell = row.createCell(col_num);
				}
				if (Ress.equals("Fail")) {
					style.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.getIndex());
					style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
					cell.setCellValue(Ress);
					cell.setCellStyle(style);

				} else if (Ress.equals("Pass")) {
					style.setFillForegroundColor(IndexedColors.GREEN.getIndex());
					style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
					cell.setCellValue(Ress);
					cell.setCellStyle(style);
				} else {
					style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
					style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
					cell.setCellValue(Ress);
					cell.setCellStyle(style);
				}
			} catch (Exception e) {
				new Throwable("cell value is null");
			}
		}
		FileOutputStream file_output_stream = new FileOutputStream(fileName);
		workbook.write(file_output_stream);
		file_output_stream.close();
		if (col_num == -1) {
			System.out.println("Column you are searching for does not exist");
		}
	}

}
