package dataProviders;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class DataProvider_IN_OUT {

	public int col_num;
	public static XSSFWorkbook workbook;
	public static Sheet worksheet;
	public static DataFormatter formatter = new DataFormatter();

	static ConfigFileReader reader = new ConfigFileReader();
	static String SheetFilePath = reader.getExcelSheetFilePath();
	 //static String sheetName = reader.getExcelSheetName();

	@DataProvider
	public static Object[][] ReadVariant(Method m) throws IOException {
		  Workbook workbook = WorkbookFactory.create(new File(SheetFilePath));
		    Sheet sheet = workbook.getSheet(m.getName());
		    Iterable<Row> rows = sheet::rowIterator;
		    List<Map<String, String>> results = new ArrayList<>();
		    boolean header = true;
		    List<String> keys = null;
		    for (Row row : rows) {
		      List<String> values = getValuesInEachRow(row);
		      if (header) {
		        header = false;
		        keys = values;
		        continue;
		      }
		      results.add(transform(keys, values));
		    }
		    return asTwoDimensionalArray(results);
		  }

		  private static Object[][] asTwoDimensionalArray(List<Map<String, String>> interimResults) {
		    Object[][] results = new Object[interimResults.size()][1];
		    int index = 0;
		    for (Map<String, String> interimResult : interimResults) {
		      results[index++] = new Object[] {interimResult};
		    }
		    return results;
		  }

		  private static Map<String, String> transform(List<String> names, List<String> values) {
		    Map<String, String> results = new HashMap<>();
		    for (int i = 0; i <names.size(); i++) {
		      String key = names.get(i);
		      String value = values.get(i);
		      results.put(key, value);
		    }
		    return results;
		  }

		  private static List<String> getValuesInEachRow(Row row) {
		    List<String> data = new ArrayList<>();
		    Iterable<Cell> columns = row::cellIterator;
		    for (Cell column : columns) {
		      data.add(formatter.formatCellValue(column));
		    }
		    return data;
		  }
		
	

}
