package drivers;

import org.openqa.selenium.By;

public class CRConstants {

	
	//LoginPage
	public static final String USER_NAME = "//input[@id='MainContent_txtUserName']";
	public static final String PASSWORD = "//input[@id='MainContent_txtPassword']";
	public static final String LOGIN = "//input[@id='MainContent_btnLogin']";

	// Client Application

	public static final String CLIENT_APPLICATION = "//a[contains(text(),'CLIENT APPLICATION')]";
	
	

	// Dashboard Page
	public static final String CONSUMER_ADMINISTRATION = "//a[contains(@href,'#]";
	public static final String ADD_CONSUMER = "//input[@id='lnkAddConsumer']";
	public static final String LAST_NAME = "//input[@id='ContentPrimary_txtLastName']";
	public static final String FIRST_NAME = "//input[@id='ContentPrimary_txtFirstName']";
	public static final String GENDER = "//*[contains(text(),'United Kingdom')]";
	public static final String DATE_OF_BIRTH = "//input[@id='ContentPrimary_txtDOB']";
	public static final String CONTINUE = "//input[@id='ContentPrimary_btnAddAndContinue']";
	public static final String ADD_AND_CONTINUE = "//input[@id='ContentPrimary_dgNewAdd_Linkbutton2_0']";
	public static final String POPUP="";
	

	// Responsible party screen
	public static final String RES_FIRST_NAME = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtContactFN']";
	public static final String RES_LAST_NAME = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtContactLN']";
	public static final String CHECK_BOX_LIST="//*[@id='ContentPrimary_ctrl_ContactAddress_chkAddNewAddr']/tbody/tr/td";
	public static final String HOME_CHECK_BOX = "//input[@id='ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0']";
	public static final String ADD_LINE_ONE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressLine1']";
	public static final String ADD_LINE_TWO = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressLine2']";
	public static final String CITY = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtCity']";
	public static final String STATE = "//input[@id='ContentPrimary_ctrl_ContactAddress_ddlState']";
	public static final String ZIP = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtZip5']";
	public static final String HOME_PHONE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtHomePhonePrefixSuffix']";
	public static final String FOOTER_SCROLL="//*[@id='footerInj']/div[1]";
	public static final String START_DATE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressStDate']";
	public static final String TODAY_DATE="(//div[@class='datetimepicker-days']//th[contains(text(),'Today')])[1]";
	public static final String SAVE = "//input[@id='ContentPrimary_ctrl_ContactAddress_btnSave']";
	
	// Address validation
	public static final String USE_AS_ENTERED = "//*[text()='Use as Entered']";
	public static final String CLOSE = "//input[contains(@type,'button')]";
	
	// Consumer address book
	public static final String CONSUMER_MAIN_MENU = "//li[@id='liConsumerMenu']//a[contains(text(),'Consumer Main Menu')]";
	public static final String DOCUMENTED_DISABILITIES = "//input[@id='lnkDocumentedDiabilities']";
	public static final String CONSUMER_MENU_LIST="//ul[@class='dropdown-menu mega-dropdown-menu']/li/ul/li";
	public static final String DISABILITIES_TYPE_DROPDOWN = "//input[@id='ContentPrimary_DropDownList1']";
	
	// Functional limitations 
	public static final String FUNCTIONAL_LIMITATIONS = "//input[@id='ContentPrimary_lbFuncLimit1']";
	public static final String FUNCTIONAL_LIMITATIONS_ROWS="//*[@id=\"Table11\"]/tbody/tr";
	public static final String ASSIGN_TO_DIAGNOSIS = "//input[@id='ContentPrimary_btnAssignFuncLimitations']";
	
	// Evaluation/ Report
	public static final String EVALUATION_REPORT = "//input[@id='ContentPrimary_lbDisablityPrioirty1']";
	public static final String ER_FIRSTNAME = "//input[@id='ContentPrimary_txtProfessionalName']";
	public static final String ER_TITLE = "//input[@id='ContentPrimary_txtProfessionalTitle']";
	public static final String ER_TITLE_DROPDOWN = "//input[@id='ContentPrimary_ddlProfessionalReportType']";
	public static final String ER_TITLE_DATEREPORT = "//input[@id='ContentPrimary_txtProfessionalDateofReport']";
	public static final String ER_TODAY="//div[@class='datetimepicker-days']//th[contains(text(),'Today')]";
	public static final String ER_SAVE = "//input[@id='ContentPrimary_btnAssignProfessionalDetails']";
	
	
	// Etiology
	public static final String ETIOLOGY = "//input[@id='ContentPrimary_btnConcerns']";
	public static final String ETIOLOGY_SELECT = "//input[@value='Select Etiology']";
	public static final String ETIOLOGY_TYPE = "//*[@id=\"CheckBoxList1\"]";
	public static final String EIOLOGY_ASSIGN = "//input[@value='Assign']";
	public static final String EIOLOGY_FINALSAVE = "//input[@value='Save']";
	

	// Demographics
	public static final String DEMOGRAPHICS_LINK = "//a[contains(text(),'Demographics')]";
	public static final String LANGUAGE_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlConsumerLanguage']";
	public static final String ETHNICITY_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlEthnicity']";
	public static final String TRIBE_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlTribe']";
	public static final String INCONTINENT_DROPDOWN = "//button[@data-id='ContentPrimary_Incontinent_Dropdownlist']";
	public static final String EMERGENCY_PLAN_DROPDOWN = "//select[@name='ctl00$ContentPrimary$PowerDependent_Dropdownlist']";
	public static final String COMMENTS = "//textarea[@name='ctl00$ContentPrimary$txtDisabilityDescription']";
	public static final String REASON = "//select[@name='ctl00$ContentPrimary$ddlICAPReason']";
	public static final String DEMO_SAVE = "//input[@value='Save']";
	
	
	// Eligibility 
	public static final String DDD_ELIGIBILITY_BUTTON = "//input[@name='ctl00$btnDetermineEligibility']";
	public static final String ELIGIDDDBUTTON = "//input[@name='ctl00$btnDetermineEligibility']";
	public static final String CONSUMNER_ADMIN= "//a[contains(text(),'Consumer Administration ')]";
	public static final String ELIGIDETERREDETER = "//a[contains(text(),'Eligibility Determination/Redetermination')]";
	public static final String ELIGIYESBUTTON = "//input[@id='ContentPrimary_RadioButton1']";
	public static final String ELIGINOBUTTON = "//input[@id='ContentPrimary_RadioButton2']";
	public static final String ELIGIDETERNOTES = "//textarea[@name='ctl00$ContentPrimary$txtNotes']";
	public static final String ELIGIFINALSAVE =  "//input[@value='Save']";
	public static final String ELIGISUCCESSMSG = "//span[contains(text(),'Save Successful')]";
	public static final String ELIGIVIEWMYCONSUMERS = "//a[contains(text(),'View My Consumers')]";	
	By EligiWorkerDropDown = By.xpath("//div[contains(text(),'PRIMARY')]");
	By EligiClientDropDown = By.xpath("//div[contains(text(),'--SELECT--')]");
	By EligiMyConsumers = By.xpath("(//a[@data-toggle='collapse'])[1]");
	By EligiStatus = By.xpath("//*[text()='APPROVED']");
	By EligiSelect = By.xpath("//a[contains(text(),'Select')]");	
}



