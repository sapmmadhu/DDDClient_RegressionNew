package drivers;

import org.openqa.selenium.By;

public class CRConstantsNew {
	
	//LoginPage
	public static final String USER_NAME = "//input[@id='MainContent_txtUserName']";
	public static final String PASSWORD = "//input[@id='MainContent_txtPassword']";
	public static final String LOGIN = "//input[@id='MainContent_btnLogin']";

	// Client Application

	public static final String CLIENT_APPLICATION = "//a[contains(text(),'CLIENT APPLICATION')]";	

	// Dashboard Page
	public static final String CONSUMER_ADMINISTRATION = "//a[contains(@href,'#]";
	public static final String ADD_CONSUMER = "//input[@id='lnkAddConsumer']";
	public static final String LAST_NAME = "//input[@id='ContentPrimary_txtLastName']";
	public static final String FIRST_NAME = "//input[@id='ContentPrimary_txtFirstName']";
	public static final String GENDER = "//*[contains(text(),'United Kingdom')]";
	public static final String DATE_OF_BIRTH = "//input[@id='ContentPrimary_txtDOB']";
	public static final String CONTINUE = "//input[@id='ContentPrimary_btnAddAndContinue']";
	public static final String ADD_AND_CONTINUE = "//input[@id='ContentPrimary_dgNewAdd_Linkbutton2_0']";
	public static final String POPUP="";	

	// Responsible party screen
	public static final String RES_FIRST_NAME = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtContactFN']";
	public static final String RES_LAST_NAME = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtContactLN']";
	public static final String CHECK_BOX_LIST="//*[@id='ContentPrimary_ctrl_ContactAddress_chkAddNewAddr']/tbody/tr/td";
	public static final String HOME_CHECK_BOX = "//input[@id='ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0']";
	public static final String ADD_LINE_ONE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressLine1']";
	public static final String ADD_LINE_TWO = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressLine2']";
	public static final String CITY = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtCity']";
	public static final String STATE = "//input[@id='ContentPrimary_ctrl_ContactAddress_ddlState']";
	public static final String ZIP = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtZip5']";
	public static final String HOME_PHONE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtHomePhonePrefixSuffix']";
	public static final String FOOTER_SCROLL="//*[@id='footerInj']/div[1]";
	public static final String START_DATE = "//input[@id='ContentPrimary_ctrl_ContactAddress_txtAddressStDate']";
	public static final String TODAY_DATE="(//div[@class='datetimepicker-days']//th[contains(text(),'Today')])[1]";
	public static final String RES_SAVE = "//input[@id='ContentPrimary_ctrl_ContactAddress_btnSave']";
	
	// Address validation
	public static final String USE_AS_ENTERED = "//*[text()='Use as Entered']";
	public static final String CLOSE = "//input[contains(@type,'button')]";
	
	// Consumer address book
	public static final String CONSUMER_MAIN_MENU = "//li[@id='liConsumerMenu']//a[contains(text(),'Consumer Main Menu')]";
	public static final String DOCUMENTED_DISABILITIES = "//input[@id='lnkDocumentedDiabilities']";
	public static final String CONSUMER_MENU_LIST="//ul[@class='dropdown-menu mega-dropdown-menu']/li/ul/li";
	public static final String DISABILITIES_TYPE_DROPDOWN = "//input[@id='ContentPrimary_DropDownList1']"; // Type of disabilities selection
	
	
	
	
	
	
	//
	
	//New Documented disabilities screen for to add Disability name, Functional limitations, Evaluation report, No need to add Etiology details
	
	
	//Diagnosis
	public static final String DIAGDISasCLIENTDIAG="//*[@id='ctl00_lnkDiagnosis']/div[1]";
	public static final String DIAGNOSIS_DROPDOWN= "";
	public static final String DIAGNOSIS_VIEWEDIT= "//input[@id='lnkEdit']";
	public static final String DIAGNOSIS_DELETE= "//input[@id='lnkDelete']";	
	
	//Functional Limitations
	public static final String ADDFL= "//input[@id='txtFLEconomic']";
	public static final String ADDFLONE= "//input[@id='txtFLCapacity']";
	public static final String ADDFLTWO= "//input[@id='txtFLLearning']";
	
	// Evaluation Report
	public static final String ERNAME= "//input[@id='txtEvalName']";
	public static final String ERTITLE= "//input[@id='txtEvalTitle']";
	public static final String ERPHONE= "//input[@id='txtEvalPhoneNo']";
	public static final String ERTYPEDROPDOWN= "//input[@id='ctl00_ContentPrimary_ddlEvalType']";
	public static final String ERDOR= "//input[@id='txtEVReportDate']"; // No Calendar
	public static final String ERCOMMENTS= "//input[@id='txtEVComments']";
	public static final String ERSAVE= "//input[@id='btnSave']";	
	
	
	// Below are button validations
	public static final String PRINT= "//*[text()='Print Summary']";
	public static final String SAVE= "//*[text()='Save']";
	public static final String CANCEL= "//*[text()='Cancel']";
	
	
	// Below are tab validations	
	public static final String QUALIFYING_DIAGNOSIS= "//*[text()='Qualifying Diagnosis']";
	public static final String AUG_COMM_DIAGNOSIS= "//*[text()='Aug Comm Diagnosis']";
	public static final String ETIOLOGYCANCEL= "//*[text()='Etiology']";
	public static final String SUMMARY= "//*[text()='Summary']";
	public static final String ADD= "//*[text()='Add']";
	public static final String DIAGNOSIS= "//*[text()='Diagnosis']";
	public static final String FUNCTIONALLIMITATIONS= "//*[text()='Functional Limitations']";
	public static final String EVALUATIONREPORT= "//*[text()='Evaluation/Report']";
	public static final String CONSUMERHEADING= "//*[text()='Consumer Documented Disabilities']";
	
	
	
	
	//********************************************************
	
	
	// Demographics
	public static final String DEMO_LINK = "//a[contains(text(),'Demographics')]";
	public static final String DEMO_LANGUAGE_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlConsumerLanguage']";// Language selection
	public static final String DEMO_ETHNICITY_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlEthnicity']";
	public static final String DEMO_TRIBE_DROPDOWN = "//select[@name='ctl00$ContentPrimary$ddlTribe']";
	public static final String DEMO_INCONT_DROPDOWN = "//button[@data-id='ContentPrimary_Incontinent_Dropdownlist']";
	public static final String DEMO_EMERGENCY_PLAN_DROPDOWN = "//select[@name='ctl00$ContentPrimary$PowerDependent_Dropdownlist']";
	public static final String DEMO_COMMENTS = "//textarea[@name='ctl00$ContentPrimary$txtDisabilityDescription']";
	public static final String DEMO_REASON = "//select[@name='ctl00$ContentPrimary$ddlICAPReason']";
	public static final String DEMO_SAVE = "//input[@value='Save']";	
	
	// Eligibility 
	
	public static final String ELIGIDDDBUTTON = "//input[@name='ctl00$btnDetermineEligibility']";// Request DDD button
	public static final String ELIGIDETERREDETER = "//a[contains(text(),'Eligibility Determination/Redetermination')]";
	public static final String ELIGIYESBUTTON = "//input[@id='ContentPrimary_RadioButton1']";
	public static final String ELIGINOBUTTON = "//input[@id='ContentPrimary_RadioButton2']";
	public static final String ELIGIDETERNOTES = "//textarea[@name='ctl00$ContentPrimary$txtNotes']"; // Determination notes
	public static final String ELIGIFINALSAVE =  "//input[@value='Save']";
	public static final String ELIGISUCCESSMSG = "//span[contains(text(),'Save Successful')]";// Successful message validation
	public static final String ELIGIVIEWMYCONSUMERS = "//a[contains(text(),'View My Consumers')]";	
	public static final String ELIGIWORKERDROPDOWN = "//div[contains(text(),'PRIMARY')]"; // Worker drop down
	public static final String ELIGICLIENTDROPDOWN = "//div[contains(text(),'--SELECT--')]"; // Client drop down 
	public static final String ELIGIMYCONSUMERS = "(//a[@data-toggle='collapse'])[1]";
	public static final String ELIGISTATUS = "//*[text()='APPROVED']";
	public static final String ELIGISELECT = "//a[contains(text(),'Select')]";	
	
		
}

