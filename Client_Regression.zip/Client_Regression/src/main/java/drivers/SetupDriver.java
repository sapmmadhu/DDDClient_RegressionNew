package drivers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SetupDriver {

	public WebDriver driver;

	public SetupDriver(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "P:\\Selenium\\chromedriver_win32 (1)\\chromedriver.exe");
		DesiredCapabilities dc;
		dc = DesiredCapabilities.chrome();
		System.setProperty("http.proxyHost", "127.0.0.1");
		System.setProperty("http.proxyPort", "9090");
		System.setProperty("https.proxyHost", "127.0.0.1");
		System.setProperty("https.proxyPort", "9090");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("start-maximized");
		options.addArguments("--disable-extensions");
		dc.setCapability(ChromeOptions.CAPABILITY, options);
		WebDriver driver = new ChromeDriver(dc);
	}

	

	@BeforeMethod
	   void setUp() {
	   }

	@BeforeMethod
	   void tearDown() {
	   }

	public WebDriver getDriver(String driverType) {

		if (driverType == null || driverType.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			// System.setProperty("webdriver.chrome.driver","P:\\Selenium\\ChromeDriver\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			return driver;
		}

		else if (driverType.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			return driver;

		} else if (driverType.equals("iexplorer")) {
			WebDriverManager.iedriver().setup();
			driver.manage().window().maximize();
			return driver;
		}

		else
			throw new RuntimeException(
					"Browser Name Key value in Configuration.properties is not matched : " + driverType);
	}
}

/*
 * ChromeDriverService chSvc = new ChromeDriverService.Builder().
 * usingDriverExecutable(new File("P:\\Selenium\\ChromeDriver78\\chromedriver.exe")).usingAnyFreePort().build();
 * ChromeOptions chOption = new ChromeOptions();
 * chOption.addArguments("--profile-directory= C:\\Users\\C049604\\AppData\\Roaming\\Google\\Chrome\\User Data");
 * chOption.addArguments("--profile-directory= C:\\Users\\C049604\\AppData\\Local\\Google\\Chrome\\User Data\\Profile 6");
 * chOption.addArguments("--start-maximized");
 * chOption.addArguments("--disable-extensions"); 
 * driver = new ChromeDriver(chSvc, chOption);
 * return driver;
 * 
 * capabilities.setCapability("network.proxy.http", "IP here");
 * capabilities.setCapability("network.proxy.http_port", "Port here");
 * 
 * }
 * 
 * 
 * } }
 */
