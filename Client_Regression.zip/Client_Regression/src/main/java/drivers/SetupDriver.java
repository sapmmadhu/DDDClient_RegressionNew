package drivers;

import java.io.File;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import io.github.bonigarcia.wdm.WebDriverManager;

public class SetupDriver {

	public WebDriver driver;

	public SetupDriver(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	

	// To give Gecko Driver path for Firefox browser

	/*
	 * @SuppressWarnings("deprecation") public static void main(String[] args)
	 * throws InterruptedException {	 * 
	 * System.setProperty("webdriver.gecko.driver", 	"P:\\Selenium\\geckodriver-v0.26.0-win64\\geckodriver.exe");
	 * DesiredCapabilities capabilities = DesiredCapabilities.firefox();
	 * capabilities.setCapability("marionette", true); 
	 * WebDriver driver = new FirefoxDriver(capabilities); 
	 * WebDriver driver = new FirefoxDriver();
	 * driver.get("http://ddqaweb1.preprod.des:8080/organization/ddd/focusdd/frm_Login.aspx");
	 * Thread.sleep(5000); driver.quit(); }
	 */

	
    
	
	public static void main(String[] args) throws InterruptedException {

		
		 System.setProperty("webdriver.chrome.driver", "P:\\Selenium\\chromedriver_win32 (1)\\chromedriver.exe"); 
		// System.setProperty("webdriver.chrome.driver", "C:\\Users\\C049604\\chromedriver_win32\\chromedriver.exe");
		 ChromeOptions options = new ChromeOptions(); 
		 options.addArguments("--user-data-dir=C:\\Users\\C049604\\AppData\\Local\\Google\\Chrome\\User Data"); 
		 //options.addArguments("--user-data-dir=C:/Users/C049604/AppData/Local/Google/ChromeUser Data"); 
		 //options.addArguments("--profile-directory=Profile 2");
		 options.addArguments("--start-maximized"); 
		 WebDriver driver = new ChromeDriver(options);
		 
		
		 
		 // driver = new ChromeDriver(options);
		// options.addArguments("--user-data-dir=C:\\Users\\C049604\\AppData\\Local\\Google\\Chrome\\User Data\\Profile 6"); 
		//System.setProperty("webdriver.chrome.driver",  "P:\\Selenium\\chromedriver_win32(1)\\chromedriver.exe");
		//WebDriver driver = new ChromeDriver();
		//driver.get("http://ddqaweb1.preprod.des:8080/organization/ddd/focusdd/frm_Login.aspx/");
		//System.out.println("ClientApplication");
		//driver.close();
	}
	
	
	

	public WebDriver getDriver(String driverType) {

		if (driverType == null || driverType.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			return driver;
		}

		else if (driverType.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			return driver;
			
		} else if (driverType.equals("iexplorer")) {
			WebDriverManager.iedriver().setup();
			driver.manage().window().maximize();
			return driver;
		}

		else
			throw new RuntimeException(
					"Browser Name Key value in Configuration.properties is not matched : " + driverType);
	}
}







/*
 * * ChromeDriverService chSvc = new ChromeDriverService.Builder().
 * usingDriverExecutable(new
 * File("P:\\Selenium\\ChromeDriver78\\chromedriver.exe")).
 * usingAnyFreePort().build(); ChromeOptions chOption = new ChromeOptions();
 * chOption.
 * addArguments("--profile-directory= C:\\Users\\C049604\\AppData\\Roaming\\Google\\Chrome\\User Data"
 * ); chOption.
 * addArguments("--profile-directory= C:\\Users\\C049604\\AppData\\Local\\Google\\Chrome\\User Data\\Profile 6"
 * ); chOption.addArguments("--start-maximized");
 * chOption.addArguments("--disable-extensions"); driver = new
 * ChromeDriver(chSvc, chOption);
 * 
 * return driver;
 * 
 * // //capabilities.setCapability("network.proxy.http", "IP here");
 * //capabilities.setCapability("network.proxy.http_port", "Port here");
 * 
 * }
 * 
 * 
 * } }
 */
