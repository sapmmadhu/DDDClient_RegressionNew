package drivers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SetupDriver {

	public WebDriver driver;
	 
	public SetupDriver(WebDriver driver) {
		 this.driver=driver;
		 PageFactory.initElements(driver, this);
	 }
	

	public WebDriver getDriver(String driverType) {
		
		if(driverType == null || driverType.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			return driver;
		}
		
		else if(driverType.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			return driver;
		}
		else if(driverType.equals("iexplorer")) {
			WebDriverManager.iedriver().setup();
			driver.manage().window().maximize();
			return driver;
		}
		else throw new RuntimeException("Browser Name Key value in Configuration.properties is not matched : " + driverType);
			
			

	}
}
