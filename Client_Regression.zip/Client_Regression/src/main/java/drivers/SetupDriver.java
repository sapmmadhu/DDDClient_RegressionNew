package drivers;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SetupDriver {

	public WebDriver driver = null;

	public SetupDriver(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebDriver getDriver(String driverType) throws IOException {

		if (driverType == null || driverType.equalsIgnoreCase("chrome")) {

			// Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe /T");
			// Runtime.getRuntime().exec("C:\\Program Files
			// (x86)\\Google\\Chrome\\Application\\chrome.exe", null, new File("c:\\program
			// files\\test\\"));
			ChromeOptions chOption = new ChromeOptions();

			chOption.addArguments("--user-data-dir=C:\\Users\\C049604\\AppData\\Local\\Google\\Chrome\\User Data");
			chOption.setExperimentalOption("useAutomationExtension", false);
			System.setProperty("webdriver.chrome.driver",
			System.getProperty("user.dir") + "\\ChromeDriver\\chromedriver.exe");
			chOption.addArguments("--start-maximized");

			driver = new ChromeDriver(chOption);
			return driver;
		}

		else if (driverType.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			return driver;

		} else if (driverType.equals("iexplorer")) {
			WebDriverManager.iedriver().setup();
			driver.manage().window().maximize();
			return driver;
		}

		else
			throw new RuntimeException(
					"Browser Name Key value in Configuration.properties is not matched : " + driverType);
	}
}
