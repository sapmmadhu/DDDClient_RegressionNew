package drivers;

import java.io.File;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;



import io.github.bonigarcia.wdm.WebDriverManager;

public class SetupDriver {

	public WebDriver driver;
	 
	public SetupDriver(WebDriver driver) {
		 this.driver=driver;
		 PageFactory.initElements(driver, this);		 
	 }
		
	
	// To give Gecko Driver path
		 
		 @SuppressWarnings("deprecation")
		public static void main(String[] args) throws InterruptedException {
			 
			 System.setProperty("webdriver.gecko.driver", "P:\\Selenium\\geckodriver-v0.26.0-win64\\geckodriver.exe");	 
		 DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		 capabilities.setCapability("marionette", true);
		// WebDriver driver = new FirefoxDriver(capabilities);
		 WebDriver driver = new FirefoxDriver();
		 driver.get("http://ddqaweb1.preprod.des:8080/organization/ddd/focusdd/frm_Login.aspx");
		 
		 Thread.sleep(5000);
		 driver.quit();
		 }


		public WebDriver getDriver(String broswerName) {
			// TODO Auto-generated method stub
			return null;
		}
		}

	
	
	
	
/*
 * if(driverType == null || driverType.equalsIgnoreCase("chrome")) { //
 * System.setProperty("webdriver.chrome.driver",
 * "P:\\Selenium\\ChromeDriver78\\chromedriver.exe"); // ChromeOptions options =
 * new ChromeOptions(); // options.
 * addArguments("chrome.exe --user-data-dir=C:\\Users\\C049604\\AppData\\Local\\Google\\Chrome\\User Data\\Profile 1"
 * ); // options.addArguments("--start-maximized"); // driver = new
 * ChromeDriver(options);
 * 
 * 
 * // System.setProperty("webdriver.chrome.driver",
 * "P:\\Selenium\\ChromeDriver78\\chromedriver.exe"); // String userProfile=
 * "C:\\Users\\C049604\\AppData\\Local\\Google\\Chrome\\User Data\\Profile 1\\";
 * // ChromeOptions options = new ChromeOptions(); //
 * options.addArguments("user-data-dir="+userProfile); //
 * options.addArguments("--start-maximized"); // driver = new
 * ChromeDriver(options);
 * 
 * 
 * 
 * // String downloadFilepath =
 * "P:\\\\Selenium\\\\ChromeDriver78\\\\chromedriver.exe"; // HashMap<String,
 * Object> chromePrefs = new HashMap<String, Object>(); //
 * chromePrefs.put("profile.default_content_settings.popups", 0); //
 * chromePrefs.put("download.default_directory", downloadFilepath); //
 * ChromeOptions options = new ChromeOptions(); //
 * options.setExperimentalOption("prefs", chromePrefs); // DesiredCapabilities
 * cap = DesiredCapabilities.chrome(); //
 * cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true); //
 * cap.setCapability(ChromeOptions.CAPABILITY, options); // driver = new
 * ChromeDriver(options); //System.setProperty("webdriver.chrome.driver",
 * "./chromedriver.exe");
 * 
 * 
 * ChromeDriverService chSvc = new ChromeDriverService.Builder()
 * .usingDriverExecutable(new
 * File("P:\\Selenium\\ChromeDriver78\\chromedriver.exe")).usingAnyFreePort().
 * build(); ChromeOptions chOption = new ChromeOptions(); //chOption.
 * addArguments("--profile-directory= C:\\Users\\C049604\\AppData\\Roaming\\Google\\Chrome\\User Data"
 * ); chOption.
 * addArguments("--profile-directory= C:\\Users\\C049604\\AppData\\Local\\Google\\Chrome\\User Data\\Profile 6"
 * ); chOption.addArguments("--start-maximized");
 * chOption.addArguments("--disable-extensions"); driver = new
 * ChromeDriver(chSvc, chOption);
 * 
 * return driver;
 * 
 * // //capabilities.setCapability("network.proxy.http", "IP here");
 * //capabilities.setCapability("network.proxy.http_port", "Port here");
 * 
 * }
 * 
 * 
 * 
 * else if(driverType.equalsIgnoreCase("firefox")) {
 * WebDriverManager.firefoxdriver().setup(); driver = new FirefoxDriver();
 * driver.manage().window().maximize(); return driver; } else
 * if(driverType.equals("iexplorer")) { WebDriverManager.iedriver().setup();
 * driver.manage().window().maximize(); return driver; } else throw new
 * RuntimeException("Browser Name Key value in Configuration.properties is not matched : "
 * + driverType);
 * 
 * 
 * 
 * } }
 */
