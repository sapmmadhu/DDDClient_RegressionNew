package drivers;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import dataProviders.ConfigFileReader;

public class Screenshot {
	static Date date = new Date();
	  static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
	  static SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
	public WebDriver driver;
	ConfigFileReader reader= new ConfigFileReader();
	public Screenshot(WebDriver driver) {
		this.driver= driver;
	}

	public void takeScreenShot(String Number) {
		// Date d = new Date();
		// String screenshotFile = d.toString().replace(":", "_").replace(" ", "_") +
		// ".png";
	 String filePath = reader.getScreenShotFilePath()+"//Screenshots//"+Number+".png";
	 //File file= new File(filePath);
	 
		// store screenshot in that file
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		try {
			//if(!file.exists()) {
			//	 file.createNewFile();
			// }
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static  String captureScreen(WebDriver driver, String title, String testName, String fileData) {
	    String path;
	    try {
	      File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	      path = System.getProperty("user.dir") + "/target/screenshots/" + dateFormat2.format(date) + "/" + testName
	          + "/" + fileData + "/" + title + "_" + dateFormat.format(date) + "_" + source.getName();
	      FileUtils.copyFile(source, new File(path));
	      Thread.sleep(1000);
	    } catch (Exception e) {
	      path = "Failed to capture screenshot: " + e.getMessage();
	    }
	    return path;
	  }
}
