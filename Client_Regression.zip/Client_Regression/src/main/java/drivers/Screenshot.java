package drivers;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import dataProviders.ConfigFileReader;

public class Screenshot {
	public WebDriver driver;
	ConfigFileReader reader= new ConfigFileReader();
	public Screenshot(WebDriver driver) {
		this.driver= driver;
	}

	public void takeScreenShot(String Number) {
		// Date d = new Date();
		// String screenshotFile = d.toString().replace(":", "_").replace(" ", "_") +
		// ".png";
	 String filePath = reader.getScreenShotFilePath()+"//Screenshots//"+Number+".png";
	 //File file= new File(filePath);
	 
		// store screenshot in that file
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		try {
			//if(!file.exists()) {
			//	 file.createNewFile();
			// }
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
